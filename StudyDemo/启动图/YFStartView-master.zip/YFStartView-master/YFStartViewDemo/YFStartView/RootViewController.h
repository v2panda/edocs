//
//  RootViewController.h
//  YFStartView
//
//  Created by 叶帆 on 15/10/19.
//  Copyright © 2015年 Suzhou Coryphaei Information&Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
