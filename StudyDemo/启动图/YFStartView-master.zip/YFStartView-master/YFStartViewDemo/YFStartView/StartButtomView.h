//
//  StartButtomView.h
//  YFStartView
//
//  Created by 叶帆 on 15/10/20.
//  Copyright © 2015年 Suzhou Coryphaei Information&Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartButtomView : UIView

@end
