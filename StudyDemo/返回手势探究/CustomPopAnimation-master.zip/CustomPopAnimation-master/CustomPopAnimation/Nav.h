//
//  Nav.h
//  CustomPopAnimation
//
//  Created by Jazys on 15/3/30.
//  Copyright (c) 2015年 Jazys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Nav : UINavigationController

@end
