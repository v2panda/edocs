# CustomPopAnimation

runtime实现自定义Pop手势动画。

博客配套demo  <http://www.jianshu.com/p/d39f7d22db6c>