//
//  main.m
//  FDFullscreenPopGestureDemo
//
//  Created by sunnyxx on 15/5/29.
//  Copyright (c) 2015年 forkingdog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
