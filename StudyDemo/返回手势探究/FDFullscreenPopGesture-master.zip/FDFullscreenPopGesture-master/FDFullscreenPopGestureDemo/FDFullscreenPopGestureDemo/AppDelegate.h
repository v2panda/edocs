//
//  AppDelegate.h
//  FDFullscreenPopGestureDemo
//
//  Created by sunnyxx on 15/5/29.
//  Copyright (c) 2015年 forkingdog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
