//
//  TextTableViewController.h
//  M80AttributedLabel
//
//  Created by amao on 7/10/14.
//  Copyright (c) 2014 www.xiangwangfeng.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextTableViewController : UITableViewController

@end
