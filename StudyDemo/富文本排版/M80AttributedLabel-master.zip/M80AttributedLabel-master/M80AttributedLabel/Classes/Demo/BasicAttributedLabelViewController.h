//
//  BasicAttributedLabelViewController.h
//  M80AttributedLabel
//
//  Created by amao on 5/21/14.
//  Copyright (c) 2014 www.xiangwangfeng.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseLabelViewController.h"

@interface BasicAttributedLabelViewController : BaseLabelViewController

@end
