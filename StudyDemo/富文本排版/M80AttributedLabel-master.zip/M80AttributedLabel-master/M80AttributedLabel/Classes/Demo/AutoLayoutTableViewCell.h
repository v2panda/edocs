//
//  AutoLayoutTableViewCell.h
//  M80AttributedLabel
//
//  Created by amao on 9/17/14.
//  Copyright (c) 2014 www.xiangwangfeng.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "M80AttributedLabel.h"

@interface AutoLayoutTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet M80AttributedLabel *autoLayoutLabel;

@end
