//
//  AutoLayoutTableViewCell.m
//  M80AttributedLabel
//
//  Created by amao on 9/17/14.
//  Copyright (c) 2014 www.xiangwangfeng.com. All rights reserved.
//

#import "AutoLayoutTableViewCell.h"

@implementation AutoLayoutTableViewCell

- (void)awakeFromNib {
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
