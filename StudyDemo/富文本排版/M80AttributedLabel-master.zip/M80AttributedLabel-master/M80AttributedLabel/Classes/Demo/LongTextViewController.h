//
//  LongTextViewController.h
//  M80AttributedLabel
//
//  Created by amao on 5/21/14.
//  Copyright (c) 2014 www.xiangwangfeng.com. All rights reserved.
//

#import "BaseLabelViewController.h"

@interface LongTextViewController : BaseLabelViewController

@end
