//
//  FangTableViewRow.m
//  FangTableViewDemo
//
//  Created by 邱育良 on 16/6/4.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTableViewRow.h"

@implementation FangTableViewRow


#pragma mark - Lifecycle

- (void)dealloc
{
//    NSLog(@"%s", __FUNCTION__);
}

+ (instancetype)row {
    return [[self alloc] init];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _rowHeight = UITableViewAutomaticDimension;
        _accessoryType = UITableViewCellAccessoryNone;
        _selectionStyle = UITableViewCellSelectionStyleDefault;
    }
    return self;
}

@end
