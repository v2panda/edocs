//
//  FangTableViewSection.m
//  FangTableViewDemo
//
//  Created by 邱育良 on 16/6/4.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTableViewSection.h"

@interface FangTableViewSection ()

@property (nonatomic, strong) NSMutableArray *mutableRows;

@end

@implementation FangTableViewSection


#pragma mark - Lifecycle

- (void)dealloc
{
//    NSLog(@"%s", __FUNCTION__);
}

+ (instancetype)section
{
    return [[self alloc] init];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _headerHeight = UITableViewAutomaticDimension;
        _footerHeight = UITableViewAutomaticDimension;
    }
    return self;
}


#pragma mark - Custom Accessors

- (NSMutableArray *)mutableRows {
    if (!_mutableRows) {
        _mutableRows = [NSMutableArray array];
    }
    return _mutableRows;
}


#pragma mark - Public

- (void)addRow:(FangTableViewRow *)row {
    [self.mutableRows addObject:row];
}

- (void)insertRow:(FangTableViewRow *)row atIndex:(NSInteger)index {
    [self.mutableRows insertObject:row atIndex:index];
}

- (void)replaceRow:(FangTableViewRow *)row atIndex:(NSInteger)index {
    [self.mutableRows replaceObjectAtIndex:index withObject:row];
}

- (void)removeRowAtIndex:(NSInteger)index {
    [self.mutableRows removeObjectAtIndex:index];
}

- (NSArray *)rows {
    return self.mutableRows;
}

@end
