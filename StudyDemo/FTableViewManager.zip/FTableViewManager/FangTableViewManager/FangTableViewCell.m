//
//  FangTableViewCell.m
//  FangTableViewDemo
//
//  Created by 邱育良 on 16/6/4.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTableViewCell.h"
#import "FangTableViewRow.h"

@interface FangTableViewCell ()

@property (nonatomic, strong) UIImageView *detailArrowImage;

@end

@implementation FangTableViewCell

#pragma mark - Lifecycle

- (void)dealloc
{
//    NSLog(@"%s", __FUNCTION__);
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self cellDidLoad];
    }
    return self;
}


#pragma mark - Public

- (void)cellDidLoad {
    [self.contentView addSubview:self.detailArrowImage];
}

- (void)cellWillAppear {
    self.detailArrowImage.hidden = !self.row.accessoryArrow;
}


- (UIImageView *)detailArrowImage {
    if (!_detailArrowImage) {
        _detailArrowImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"detailArrow.png"]];
        _detailArrowImage.frame = CGRectMake(CGRectGetWidth(self.contentView.bounds) - 8 - 10, (CGRectGetHeight(self.contentView.bounds) - 14)/2.0, 8, 14);
        _detailArrowImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    }
    return _detailArrowImage;
}

@end
