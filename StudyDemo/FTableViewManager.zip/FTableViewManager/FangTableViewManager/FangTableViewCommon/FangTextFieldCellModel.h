//
//  FangTextFieldCellModel.h
//  SouFunBang
//
//  Created by 邱育良 on 16/8/15.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTableViewRow.h"

@interface FangTextFieldCellModel : FangTableViewRow

@property (nonatomic, copy) NSString *text;

@property (nonatomic, copy) NSString *placeholder;

@property (nonatomic, assign) UIKeyboardType keyboardType;

@property (nonatomic, assign) BOOL secureTextEntry;

@property (nonatomic, copy) BOOL (^ShouldBeginEditing)(FangTextFieldCellModel *textField);
@property (nonatomic, copy) void (^DidBeginEditing)(FangTextFieldCellModel *textField);
@property (nonatomic, copy) BOOL (^ShouldEndEditing)(FangTextFieldCellModel *textField);
@property (nonatomic, copy) void (^DidEndEditing)(FangTextFieldCellModel *textField);
@property (nonatomic, copy) BOOL (^shouldChangeCharactersInRange)(FangTextFieldCellModel *textField, NSRange range, NSString *replacementString);

@end
