//
//  UIColor+FangColor.h
//  RHRefactoring
//
//  Created by Panda on 16/8/30.
//  Copyright © 2016年 v2panda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (FangColor)

+ (UIColor *)fangBlackColor;

+ (UIColor *)fangLightGrayColor;

@end
