//
//  FangTextFieldCell.h
//  SouFunBang
//
//  Created by 邱育良 on 16/8/15.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTableViewCell.h"
#import "FangTextFieldCellModel.h"

@interface FangTextFieldCell : FangTableViewCell

@property (nonatomic, strong) UITextField *textField;

@property (nonatomic, strong) FangTextFieldCellModel *row;

@end
