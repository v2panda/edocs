//
//  UIColor+FangColor.m
//  RHRefactoring
//
//  Created by Panda on 16/8/30.
//  Copyright © 2016年 v2panda. All rights reserved.
//

#import "UIColor+FangColor.h"

@implementation UIColor (FangColor)

+ (UIColor *)fangBlackColor {
    return [UIColor blackColor];
}

+ (UIColor *)fangLightGrayColor {
    return [UIColor lightGrayColor];
}

@end
