//
//  UITextField+FangTextField.h
//  RHRefactoring
//
//  Created by Panda on 16/8/30.
//  Copyright © 2016年 v2panda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (FangTextField)

+ (UITextField *)textFieldWithFrame:(CGRect)frame text:(NSString *)text textColor:(UIColor*)textColor  placeholder:(NSString *)placeholder placeholderColor:(UIColor*)placeholderColor fontOfSize:(CGFloat)fontOfSize textAlignment:(NSTextAlignment)textAlignment;

@end
