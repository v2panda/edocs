//
//  FangTextFieldCell.m
//  SouFunBang
//
//  Created by 邱育良 on 16/8/15.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTextFieldCell.h"
#import "UIColor+FangColor.h"
#import "UITextField+FangTextField.h"

@interface FangTextFieldCell ()<UITextFieldDelegate>



@end

@implementation FangTextFieldCell
@synthesize row;

#pragma mark - Lifecycle

- (void)cellDidLoad {
    [super cellDidLoad];
    [self addSubview:self.textField];
}

- (void)cellWillAppear {
    [super cellWillAppear];
    
    self.textField.text = self.row.text;
    self.textField.placeholder = self.row.placeholder;
    self.textField.secureTextEntry = self.row.secureTextEntry;
    self.textField.keyboardType = self.row.keyboardType;
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (self.row.ShouldBeginEditing) {
        return self.row.ShouldBeginEditing(self.row);
    } else {
        return YES;
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (self.row.DidBeginEditing) {
        self.row.DidBeginEditing(self.row);
    }
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    if (self.row.ShouldEndEditing) {
        return self.row.ShouldEndEditing(self.row);
    } else {
        return YES;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    self.row.text = textField.text;
    if (self.row.DidEndEditing) {
        self.row.DidEndEditing(self.row);
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    self.row.text = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (self.row.shouldChangeCharactersInRange) {
        return self.row.shouldChangeCharactersInRange(self.row, range, string);
    } else {
        return YES;
    }
    
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return YES;
}


#pragma mark - Custom Accessors

- (UITextField *)textField {
    if (!_textField) {
        
        _textField = [UITextField textFieldWithFrame:CGRectZero text:@"" textColor:[UIColor fangBlackColor] placeholder:@"请输入楼盘名称" placeholderColor:[UIColor fangLightGrayColor] fontOfSize:15 textAlignment:NSTextAlignmentLeft];
        _textField.delegate =self;
        _textField.clearButtonMode = UITextFieldViewModeNever;

    }
    return _textField;
}

@end
