//
//  FangTextFieldCellModel.m
//  SouFunBang
//
//  Created by 邱育良 on 16/8/15.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import "FangTextFieldCellModel.h"

@implementation FangTextFieldCellModel

@end
