//
//  FangTableViewRow.h
//  FangTableViewDemo
//
//  Created by 邱育良 on 16/6/4.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FangTableViewSection;

@interface FangTableViewRow : NSObject

/** 当前行复用标识 */
@property (nonatomic, copy) NSString *reuseIdentifier;

/** 行高 */
@property (nonatomic, assign) CGFloat rowHeight;

/** 行附属类型 */
@property (nonatomic, assign) UITableViewCellAccessoryType accessoryType;

/** 是否有附属箭头 */
@property (nonatomic, assign) BOOL accessoryArrow;

/** 选中样式 */
@property (nonatomic, assign) UITableViewCellSelectionStyle selectionStyle;

/** 通用模型 */
@property (nonatomic, strong) id commonModel;

/** 获取当前row所在section模型 */
@property (nonatomic, weak) FangTableViewSection *section;

/** 选中某一行回调 */
@property (nonatomic, copy) void (^didSelectRowAtIndexPath) (FangTableViewRow *row, NSIndexPath *indexPath);

/** 根据索引点击某个按钮回调 */
@property (nonatomic, copy) void (^clickedButtonAtIndex) (FangTableViewRow *row, NSIndexPath *indexPath, NSInteger buttonIndex);

/** 初始化类方法 */
+ (instancetype)row;

@end
