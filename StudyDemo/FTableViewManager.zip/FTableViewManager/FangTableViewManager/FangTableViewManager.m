//
//  FangTableViewManager.m
//  SouFun
//
//  Created by 邱 育良 on 16/6/29.
//
//

#import "FangTableViewManager.h"

@interface FangTableViewManager ()<UITableViewDataSource, UITableViewDelegate>

/** 所有的section模型可变数组,可读可写 */
@property (nonatomic, strong) NSMutableArray *mutableSections;

@end

@implementation FangTableViewManager


#pragma mark - Lifecycle

- (void)dealloc
{
    //    NSLog(@"%s", __FUNCTION__);
}

- (instancetype)initWithTableView:(UITableView *)tableView
{
    self = [super init];
    if (self) {
        _tableView = tableView;
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _mutableSections = [NSMutableArray array];
        
    }
    return self;
}

- (instancetype)initWithTableView:(UITableView *)tableView
                         delegate:(id<FangTableViewManagerDelegate>)delegate
{
    self = [self initWithTableView:tableView];
    if (self) {
        _otherDelegate = delegate;
    }
    return self;
}


#pragma mark - Custom Accessors

- (NSMutableArray *)mutableSections {
    if (!_mutableSections) {
        _mutableSections = [NSMutableArray array];
    }
    return _mutableSections;
}


#pragma mark - Public

- (void)reloadTableView {
    if ([self.otherDelegate respondsToSelector:@selector(tableViewDataSource)]) {
        [self.otherDelegate tableViewDataSource];
    }
    [self.tableView reloadData];
}

- (NSArray *)sections {
    return self.mutableSections;
}

- (void)addSection:(FangTableViewSection *)section {
    [self.mutableSections addObject:section];
}

- (void)removeAllSections {
    [self.mutableSections removeAllObjects];
}

- (void)reloadAnimationRow:(FangTableViewRow *)row atIndexPath:(NSIndexPath *)indexPath {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[indexPath.section];
    [eachSection replaceRow:row atIndex:indexPath.row];
    
    [self.tableView beginUpdates];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
    [self.tableView endUpdates];
}

- (void)insertAnimationRow:(FangTableViewRow *)row atIndexPath:(NSIndexPath *)indexPath {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[indexPath.section];
    [eachSection insertRow:row atIndex:indexPath.row];
    
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView endUpdates];
}

- (void)deleteAnimationRowAtIndexPath:(NSIndexPath *)indexPath {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[indexPath.section];
    [eachSection removeRowAtIndex:indexPath.row];
    
    [self.tableView beginUpdates];
    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView endUpdates];
}


#pragma mark - Private


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    eachSection.tableView = self.tableView;
    eachSection.sectionIndex = section;
    return eachSection.rows.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[indexPath.section];
    FangTableViewRow *eachRow = (FangTableViewRow *)eachSection.rows[indexPath.row];
    eachRow.section = eachSection;
    FangTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:eachRow.reuseIdentifier forIndexPath:indexPath];
    
    cell.rowIndexPath = indexPath;
    cell.row = eachRow;
    cell.accessoryType = eachRow.accessoryType;
    cell.selectionStyle = eachRow.selectionStyle;
    [cell cellWillAppear];
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.mutableSections.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    return eachSection.headerTitle;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    return eachSection.footerTitle;
}


#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[indexPath.section];
    FangTableViewRow *eachRow = (FangTableViewRow *)eachSection.rows[indexPath.row];
    
    return eachRow.rowHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    return eachSection.headerHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    return eachSection.footerHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    return eachSection.headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[section];
    return eachSection.footerView;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    FangTableViewSection *eachSection = (FangTableViewSection *)self.mutableSections[indexPath.section];
    FangTableViewRow *eachRow = (FangTableViewRow *)eachSection.rows[indexPath.row];
    if (eachRow.didSelectRowAtIndexPath) {
        eachRow.didSelectRowAtIndexPath(eachRow, indexPath);
    }
    
    if ([self.otherDelegate respondsToSelector:@selector(didSelectRow:atIndexPath:)]) {
        [self.otherDelegate didSelectRow:eachRow atIndexPath:indexPath];
    }
}

@end
