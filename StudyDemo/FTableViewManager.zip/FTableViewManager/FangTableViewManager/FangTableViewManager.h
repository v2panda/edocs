//
//  FangTableViewManager.h
//  SouFun
//
//  Created by 邱 育良 on 16/6/29.
//
//

#import <Foundation/Foundation.h>
#import "FangTableViewSection.h"
#import "FangTableViewRow.h"
#import "FangTableViewCell.h"

@protocol FangTableViewManagerDelegate <NSObject>

@optional
- (void)tableViewDataSource;
- (void)didSelectRow:(FangTableViewRow *)row atIndexPath:(NSIndexPath *)indexPath;

@end

@interface FangTableViewManager : NSObject

@property (nonatomic, weak) UITableView *tableView;

/** 其他delegate,根据需要可以扩展tableView和scrollView的其他代理方法 */
@property (nonatomic, weak) id <FangTableViewManagerDelegate> otherDelegate;

/** 所有的section模型数组,只读 */
@property (nonatomic, strong, readonly) NSArray *sections;

/** 初始化方法 */
- (instancetype)initWithTableView:(UITableView *)tableView;

- (instancetype)initWithTableView:(UITableView *)tableView
                         delegate:(id<FangTableViewManagerDelegate>)delegate;

- (void)reloadTableView;

/** 往tableView添加section模型 */
- (void)addSection:(FangTableViewSection *)section;

/** 移除所有的section模型 */
- (void)removeAllSections;

/** 往tableView插入一行 */
- (void)insertAnimationRow:(FangTableViewRow *)row atIndexPath:(NSIndexPath *)indexPath;

/** 从tableView删除一行 */
- (void)deleteAnimationRowAtIndexPath:(NSIndexPath *)indexPath;

/** 刷新tableView某一行 **/
- (void)reloadAnimationRow:(FangTableViewRow *)row atIndexPath:(NSIndexPath *)indexPath;

@end
