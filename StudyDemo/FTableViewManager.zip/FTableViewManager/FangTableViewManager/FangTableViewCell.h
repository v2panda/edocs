//
//  FangTableViewCell.h
//  FangTableViewDemo
//
//  Created by 邱育良 on 16/6/4.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FangTableViewSection;
@class FangTableViewRow;

@interface FangTableViewCell : UITableViewCell

/** 当前cell索引 */
@property (nonatomic, strong) NSIndexPath *rowIndexPath;

/** 当前cell的section模型 */
@property (nonatomic, weak) FangTableViewSection *section;

/** 当前cell的row模型 */
@property (nonatomic, strong) FangTableViewRow *row;

/** 控件初始化和布局 */
- (void)cellDidLoad;

/** 控件赋值 */
- (void)cellWillAppear;

@end
