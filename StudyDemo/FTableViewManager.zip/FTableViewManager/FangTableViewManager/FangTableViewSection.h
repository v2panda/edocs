//
//  FangTableViewSection.h
//  FangTableViewDemo
//
//  Created by 邱育良 on 16/6/4.
//  Copyright © 2016年 www.fang.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FangTableViewRow;

@interface FangTableViewSection : NSObject

/** 所有的row模型数组,只读 */
@property (nonatomic, strong, readonly) NSArray *rows;

/** 当前section头部高度 */
@property (nonatomic, assign) CGFloat headerHeight;

/** 当前section尾部高度 */
@property (nonatomic, assign) CGFloat footerHeight;

/** 当前section头部文字 */
@property (nonatomic, copy) NSString *headerTitle;

/** 当前section尾部文字 */
@property (nonatomic, copy) NSString *footerTitle;

/** 当前section自定义头部视图 */
@property (nonatomic, strong) UIView *headerView;

/** 当前section自定义尾部视图 */
@property (nonatomic, strong) UIView *footerView;

/** 当前tableView */
@property (nonatomic, weak) UITableView *tableView;

/** 当前section索引 */
@property (nonatomic, assign) NSInteger sectionIndex;

/** 初始化类方法 */
+ (instancetype)section;

/** 往section模型数组添加row模型 */
- (void)addRow:(FangTableViewRow *)row;

- (void)insertRow:(FangTableViewRow *)row atIndex:(NSInteger)index;

- (void)replaceRow:(FangTableViewRow *)row atIndex:(NSInteger)index;

- (void)removeRowAtIndex:(NSInteger)index;

@end
