//
//  ViewController.m
//  UIKitTest
//
//  Created by 单鹏涛 on 15/7/17.
//  Copyright (c) 2015年 单鹏涛. All rights reserved.
//

#import "ViewController.h"
#import "NewtonsCradleView.h"
#import "VVSpringCollectionViewFlowLayout.h"

#define TOP 30
#define CONTROL_HEIGHT 120

@interface ViewController () <UIDynamicAnimatorDelegate,UICollisionBehaviorDelegate,UICollectionViewDataSource,UICollectionViewDelegate>


@property (nonatomic, strong)UIDynamicAnimator *animator;
@property (nonatomic, strong)UIAttachmentBehavior *attachmentBehavior;

@property (nonatomic, strong)UIView *boxView;

@property (nonatomic, strong)UIView *defaultView;
@property (nonatomic)CGAffineTransform defaultTransform;

@property (nonatomic)NewtonsCradleView *cradleView;


@property (nonatomic)UIGravityBehavior *gravity;
@property (nonatomic)UICollisionBehavior *ground;

@property (nonatomic, strong)UIPanGestureRecognizer *panGesture;

@property (nonatomic,strong)VVSpringCollectionViewFlowLayout *layout;


@property (nonatomic,strong)UIGravityBehavior *gravityBeahviorTest;


@end

static NSString *reuseId = @"collectionViewCellReuseId";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addDefaultView];
    [self addControlBtn];
    
//    self.layout = [[VVSpringCollectionViewFlowLayout alloc]init];
//    self.layout.itemSize = CGSizeMake(self.view.frame.size.width, 44);
//    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:self.view.frame collectionViewLayout:self.layout];
//    collectionView.backgroundColor = [UIColor clearColor];
//    [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseId];
//    
//    collectionView.dataSource = self;
//    [self.view insertSubview:collectionView atIndex:0];
}
/**
 *  添加小组件
 */
- (void)addDefaultView {
    
    
    self.boxView = [[UIView alloc]initWithFrame:CGRectMake(10, 100, 300, 400)];
    self.boxView.backgroundColor = [UIColor yellowColor];
//    [self.view addSubview:self.boxView];
    
    
    self.defaultView = [[UIView alloc]init];
    self.defaultView.backgroundColor = [UIColor orangeColor];
    
//    [self.boxView addSubview:self.defaultView];
    
    [self.view addSubview:self.defaultView];
    
    
    self.defaultTransform = self.defaultView.transform;
    [self resetView];
    
    self.panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handleAttachmentGesture:)];
    self.panGesture.minimumNumberOfTouches = 1;
    self.panGesture.maximumNumberOfTouches = 1;
    [self.defaultView addGestureRecognizer:self.panGesture];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 50;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseId forIndexPath:indexPath];
    cell.contentView.backgroundColor = [self randomColor];
    
    
    return cell;
}

-(UIColor *) randomColor
{
    CGFloat hue = ( arc4random() % 256 / 256.0 ); //0.0 to 1.0
    CGFloat saturation = ( arc4random() % 128 / 256.0 ) + 0.5; // 0.5 to 1.0,away from white
    CGFloat brightness = ( arc4random() % 128 / 256.0 ) + 0.5; //0.5 to 1.0,away from black
    return [UIColor colorWithHue:hue saturation:saturation brightness:brightness alpha:1];
}

/**
 *  添加控制按钮
 */
- (void)addControlBtn {
    
    // 还原
    [self.view addSubview:[self addButtonByName:@"还原" andFrame:CGRectMake(10, 150, 60, 50) andTag:7]];

    //第一栏按钮
    [self.view addSubview:[self addButtonByName:@"添加重力" andFrame:CGRectMake(10, TOP, 60, 50) andTag:8]];
    [self.view addSubview:[self addButtonByName:@"重力碰撞" andFrame:CGRectMake(80, TOP, 60, 50) andTag:9]];
    [self.view addSubview:[self addButtonByName:@"重力碰撞2" andFrame:CGRectMake(150, TOP, 60, 50) andTag:91]];
    [self.view addSubview:[self addButtonByName:@"重力碰撞3" andFrame:CGRectMake(220, TOP, 60, 50) andTag:92]];
    

    //进入第二栏
    [self.view addSubview:[self addButtonByName:@"迅速移动" andFrame:CGRectMake(10, 90, 60, 50) andTag:10]];
    [self.view addSubview:[self addButtonByName:@"迅速移动1" andFrame:CGRectMake(80, 90, 60, 50) andTag:11]];
    [self.view addSubview:[self addButtonByName:@"吸附重力" andFrame:CGRectMake(150, 90, 60, 50) andTag:12]];
    [self.view addSubview:[self addButtonByName:@"牛顿摆" andFrame:CGRectMake(220, 90, 60, 50) andTag:13]];
    
//    [self.view addSubview:[self addButtonByName:@"碰撞" andFrame:CGRectMake(190, 90, 80, 50) andTag:14]];
    
    
}

/**
 *  添加回来
 */
- (void)addBehavior {
    [self.animator addBehavior:self.gravityBeahviorTest];
}

/**
 *  重置视图
 */
- (void)resetView {
    [self.animator removeAllBehaviors];
    
    
    
    self.defaultView.frame = CGRectMake(100, CONTROL_HEIGHT+TOP, 50, 50);
    self.defaultView.transform = self.defaultTransform;
    
    if(self.cradleView)
    {
        self.cradleView.hidden = YES;
    }
        
}
/**
 *  添加按钮
 *
 *  @param btnName <#btnName description#>
 *  @param rect    <#rect description#>
 *  @param tag     <#tag description#>
 *
 *  @return <#return value description#>
 */
-(UIButton *)addButtonByName:(NSString *)btnName andFrame:(CGRect)rect andTag:(NSInteger)tag {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.backgroundColor = [UIColor blackColor];
    btn.frame = rect;
    btn.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    [btn setTitle:btnName forState:UIControlStateNormal];
    [btn setTitle:btnName forState:UIControlStateHighlighted];
    btn.tag = tag;
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

/**
 *  添加重力
 */
- (void)addGravity {
    UIGravityBehavior *gravityBeahvior = [[UIGravityBehavior alloc]initWithItems:@[self.defaultView]];
    
    UIDynamicAnimator *animator = [[UIDynamicAnimator alloc]initWithReferenceView:self.view];
   
    self.animator.delegate = self;
    
    self.gravityBeahviorTest = gravityBeahvior;
    
    self.animator = animator;//这行的作用
    
    [self.animator addBehavior:gravityBeahvior];
}

- (void)dynamicAnimatorWillResume:(UIDynamicAnimator*)animator {
    NSLog(@"dynamicAnimatorWillResume");
}
- (void)dynamicAnimatorDidPause:(UIDynamicAnimator*)animator {
    NSLog(@"dynamicAnimatorDidPause");
}


/**
 *  重力碰撞
 */
- (void)addGravity1 {
    
    
    
    UIGravityBehavior *gravityBeahvior = [[UIGravityBehavior alloc]initWithItems:@[self.defaultView]];
    UIDynamicAnimator *animator = [[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    
    gravityBeahvior.magnitude = 0.1;//重力加速度，1代表加速度是（每秒100个点）
    gravityBeahvior.gravityDirection = CGVectorMake(0, 1);  //航行的方向,趋势(范围是(0.0, 1.0)
    gravityBeahvior.angle = M_PI*0.5;  //角度   angle的值为0时，方块会水平向右移动，随着值的增大，方块会顺时针改变角度

    
    UICollisionBehavior *collisionBehavior = [[UICollisionBehavior alloc]initWithItems:@[self.defaultView]];
    collisionBehavior.translatesReferenceBoundsIntoBoundary = YES;
    
    
    self.animator = animator;
    
    [animator addBehavior:gravityBeahvior];
    [animator addBehavior:collisionBehavior];
}

/**
 *  重力碰撞2
 */
- (void)addGravity2 {
    self.defaultView.transform = CGAffineTransformRotate(self.defaultView.transform, 45);
    
    UIDynamicAnimator *animator = [[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    UIGravityBehavior *gravityBeahvior = [[UIGravityBehavior alloc]initWithItems:@[self.defaultView]];
    [animator addBehavior:gravityBeahvior];
    
    UICollisionBehavior *collisionBehavior = [[UICollisionBehavior alloc]initWithItems:@[self.defaultView]];
    collisionBehavior.translatesReferenceBoundsIntoBoundary = YES;
    [animator addBehavior:collisionBehavior];
    
    self.animator = animator;
}

/**
 *  重力碰撞3
 */
- (void)addGravity3 {
    self.defaultView.transform = CGAffineTransformRotate(self.defaultView.transform, 10);
    
    UIDynamicAnimator *animator = [[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    UIGravityBehavior *gravityBeahvior = [[UIGravityBehavior alloc]initWithItems:@[self.defaultView]];
    
    
    UICollisionBehavior *collisionBehavior = [[UICollisionBehavior alloc]initWithItems:@[self.defaultView]];
    collisionBehavior.translatesReferenceBoundsIntoBoundary = YES;

    
    UIDynamicItemBehavior *itemBehavior = [[UIDynamicItemBehavior alloc]initWithItems:@[self.defaultView]];
    itemBehavior.elasticity = 1;//两个物体之间发生碰撞后的弹性。浮点值，范围0~1
//
//    itemBehavior.resistance = 0;// 线性阻力系数。（0--CGFLOAT_MAX）
//        itemBehavior.friction = 0;// 两个物体之间的线性滑动摩擦力。浮点值，范围0~1。
//    itemBehavior.density =  1;// 物体的密度。这个主要影响在惯性上。也就是力改变这个物体运动的难易程度。浮点值，范围0~1
    

    itemBehavior.allowsRotation = YES;//默认是YES 设置行为中的dynamic item是否可以循环

    
    
    [animator addBehavior:collisionBehavior];
    [animator addBehavior:gravityBeahvior];
    [animator addBehavior:itemBehavior];
    
    self.animator = animator;
}

-(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from + 1)));
}

/**
 *  迅速移动
 */
- (void)addMoveQuickly {
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGFloat x = [self getRandomNumber:10 to:rect.size.width - self.defaultView.bounds.size.width];
    CGFloat y = [self getRandomNumber:160 to:rect.size.height - self.defaultView.bounds.size.height];
    
    CGPoint point = CGPointMake(x, y);
    
    
    UISnapBehavior *snap = [[UISnapBehavior alloc]initWithItem:self.defaultView snapToPoint:point];
    snap.damping = 0.1;//设置反弹系数（反弹幅度越大，值越大，反弹幅度越小）
    
    UIDynamicAnimator* animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    [animator addBehavior:snap];
    

    self.animator = animator;
}

/**
 *  迅速移动1
 */
- (void)addMoveQuickly1 {
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGFloat x = [self getRandomNumber:10 to:rect.size.width - self.defaultView.bounds.size.width];
    CGFloat y = [self getRandomNumber:160 to:rect.size.height - self.defaultView.bounds.size.height];
    
    CGPoint point = CGPointMake(x, y);
    UISnapBehavior *snap = [[UISnapBehavior alloc]initWithItem:self.defaultView snapToPoint:point];
    snap.damping = 1;//设置反弹系数（反弹幅度越大，值越大，反弹幅度越小）
    
    UIDynamicAnimator* animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    [animator addBehavior:snap];
    
    
    self.animator = animator;
}

/**
 *  添加吸附重力
 */
- (void)addDragGravity {
    UIDynamicAnimator* animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    
    UICollisionBehavior *collisionBehavior = [[UICollisionBehavior alloc]initWithItems:@[self.defaultView]];
    collisionBehavior.translatesReferenceBoundsIntoBoundary = YES;
    [animator addBehavior:collisionBehavior];
    
    UIGravityBehavior *g = [[UIGravityBehavior alloc] initWithItems:@[self.defaultView]];
    [animator addBehavior:g];
    
    self.animator = animator;
}

//拖拽过程中添加吸附
- (IBAction)handleAttachmentGesture:(UIPanGestureRecognizer*)gesture {
    if (gesture.state == UIGestureRecognizerStateBegan) {
        CGPoint squareCenterPoint = CGPointMake(self.defaultView.center.x, self.defaultView.center.y-100);
        
        NSLog(@"squareCenterPoint.x = %f",squareCenterPoint.x);
        NSLog(@"squareCenterPoint.y = %f",squareCenterPoint.y);
        
        UIAttachmentBehavior *attachmentBehavior = [[UIAttachmentBehavior alloc]initWithItem:self.defaultView attachedToAnchor:squareCenterPoint];
        self.attachmentBehavior = attachmentBehavior;
        [self.animator addBehavior:attachmentBehavior];
    }
    else if(gesture.state == UIGestureRecognizerStateChanged)
    {
        NSLog(@"squareCenterPoint.x = %f",self.defaultView.center.x);
        NSLog(@"squareCenterPoint.y = %f",self.defaultView.center.y);
        [self.attachmentBehavior setAnchorPoint:[gesture locationInView:self.view]];
    }
    else if(gesture.state == UIGestureRecognizerStateEnded)
    {
        [self.animator removeBehavior:self.attachmentBehavior];
    }
    else
    {
        NSLog(@"111");
    }
}
//牛顿摆
- (void)addCradle {
    
//    1. 重力(UIGravityBehavior)
//    2. 球和锚点之间的牵引力（UIAttachmentBehavior）
//    3. 球与球之间的碰撞（UICollisionBehavior）
//    4. 空气阻力，摩擦力等（UIDynamicItemBehavior）
//    5. 手移动球时的推动力（UIPushBehavior）
    
    if(self.cradleView)
    {
        self.cradleView.hidden = NO;
    }
    else
    {
        self.cradleView = [[NewtonsCradleView alloc] initWithFrame:CGRectMake(0, TOP+CONTROL_HEIGHT+10, self.view.bounds.size.width, self.view.bounds.size.height - TOP - CONTROL_HEIGHT - 10)];
        [self.view addSubview:self.cradleView];
    }
}

- (void)addCollision {
    UIView * apple = [[UIView alloc] initWithFrame:CGRectMake(40,40, 40, 40)];
    apple.backgroundColor = [UIColor redColor];
    [self.view addSubview:apple];
    
    UIDynamicAnimator* animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    _gravity = [[UIGravityBehavior alloc]initWithItems:@[apple]];
    [animator addBehavior:_gravity];
    
    _ground = [[UICollisionBehavior alloc]initWithItems:@[apple]];
    _ground.translatesReferenceBoundsIntoBoundary = YES;
    _ground.action = ^{
        NSLog(@"%@, %@",
              
              NSStringFromCGAffineTransform(apple.transform), NSStringFromCGPoint(apple.center));
    };
    
    [_ground addBoundaryWithIdentifier:@"apple" fromPoint:CGPointMake(10, 10) toPoint:CGPointMake(320, 568)];
    [animator addBehavior:_ground];
    
    _ground.collisionDelegate = self;
    
    self.animator = animator;
}

- (void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier atPoint:(CGPoint)p {
    NSLog(@"好疼，我撞在%f,%f,%@", p.x, p.y, identifier);
}

- (void)btnClick:(UIButton *)sender {
    switch (sender.tag) {
        case 6:
            [self resetView];
            break;
        case 7:
            [self resetView];
            break;
        case 8:
            [self addGravity];
            break;
        case 9:
            [self addGravity1];
            break;
        case 91:
            [self addGravity2];
            break;
        case 92:
            [self addGravity3];
            break;
        case 10:
            [self addMoveQuickly];
            break;
        case 11:
            [self addMoveQuickly1];
            break;
        case 12:
            [self addDragGravity];
            break;
        case 13:
            [self addCradle];
            break;
        case 14:
            [self addCollision];
            break;

        default:
            break;
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
