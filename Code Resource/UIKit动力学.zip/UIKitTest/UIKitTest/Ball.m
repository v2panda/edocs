//
//  Ball.m
//  UIKitTest
//
//  Created by 单鹏涛 on 15/7/20.
//  Copyright (c) 2015年 单鹏涛. All rights reserved.
//

#import "Ball.h"

@implementation Ball

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor redColor];
        self.layer.cornerRadius = self.frame.size.width / 2;
        
//        self.layer.borderColor = [UIColor redColor].CGColor;
//        self.layer.borderWidth = 3;
    }
    return self;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
