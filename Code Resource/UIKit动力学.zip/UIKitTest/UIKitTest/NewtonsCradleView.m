//
//  NewtonsCradleView.m
//  UIKitTest
//
//  Created by 单鹏涛 on 15/7/20.
//  Copyright (c) 2015年 单鹏涛. All rights reserved.
//

#import "NewtonsCradleView.h"
#import "Ball.h"

@implementation NewtonsCradleView {
    
    NSUInteger ballCount;
    NSArray *_balls;
    NSArray *_anchors;
    UIDynamicAnimator *_animator;
    UIPushBehavior *_userDragBehavior;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        ballCount = 5;
        [self createBallsAndAnchors];
        
        [self applyDynamicBehaviors];
    }
    return self;
}

- (void)createBallsAndAnchors {
    NSMutableArray *ballsArray = [NSMutableArray array];
    NSMutableArray *anchorsArray = [NSMutableArray array];
    
    CGFloat ballSize = 30;//CGRectGetWidth(self.bounds)/(3.0*(ballCount-1));
    CGFloat ballLeft = 150;
    CGFloat ballTop = 300;
    
    
    for (int i=0; i<ballCount; i++) {
        Ball *ball = [[Ball alloc]initWithFrame:CGRectMake(0, 0, ballSize, ballSize)];
        CGFloat x = ballLeft + i*ballSize;
        CGFloat y = ballTop;
        
        ball.center = CGPointMake(x, y);
        
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handleBallPan:)];
        [ball addGestureRecognizer:panGesture];
        
        [ball addObserver:self forKeyPath:@"center" options:NSKeyValueObservingOptionNew context:Nil];
        [ballsArray addObject:ball];
        [self addSubview:ball];
        
        UIView *blueBox = [self createAnchorForBall:ball];
        [anchorsArray addObject:blueBox];
        [self addSubview:blueBox];
    }
    
    _balls = ballsArray;
    _anchors = anchorsArray;
}

- (UIView *)createAnchorForBall:(Ball *)ball {
    CGPoint anchor = ball.center;
    anchor.y -= CGRectGetHeight(self.bounds)/4.0;
    UIView *blueBox = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, 10)];
    blueBox.backgroundColor = [UIColor blueColor];
    blueBox.center = anchor;
    return blueBox;
}

- (void)handleBallPan:(UIPanGestureRecognizer *)recoginizer {
    if (recoginizer.state == UIGestureRecognizerStateBegan) {
        if (_userDragBehavior) {
            [_animator removeBehavior:_userDragBehavior];
        }
        
//        _userDragBehavior  = [[UIPushBehavior alloc]initWithItems:@[recoginizer.view] mode:UIPushBehaviorModeContinuous];
            _userDragBehavior  = [[UIPushBehavior alloc]initWithItems:@[recoginizer.view] mode:UIPushBehaviorModeInstantaneous];
        [_animator addBehavior:_userDragBehavior];
    }

    
    _userDragBehavior.pushDirection = CGVectorMake([recoginizer translationInView:self].x/10.f, 0);
    if (recoginizer.state == UIGestureRecognizerStateEnded) {
        [_animator removeBehavior:_userDragBehavior];
        _userDragBehavior = nil;
    }
}



- (void)applyDynamicBehaviors {
    //添加UIDynamic的动力行为，同时把多个动力行为组合为一个复杂的动力行为。
    UIDynamicBehavior *behavior = [[UIDynamicBehavior alloc] init];
    
    [self applyAttachBehaviorForBalls:behavior];
    [behavior addChildBehavior:[self createGravityBehaviorForObjects:_balls]];//重力
    [behavior addChildBehavior:[self createCollisionBehaviorForObjects:_balls]];//碰撞
    [behavior addChildBehavior:[self createItemBehavior]];//配置
    
    _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self];
    [_animator addBehavior:behavior];
}

- (void)applyAttachBehaviorForBalls:(UIDynamicBehavior *)behavior
{
    //为每个球到对应的锚点添加一个AttachmentBehavior，并作为一个子Behavior添加到一个Behavior中。
    for(int i=0; i<ballCount; i++)
    {
        UIDynamicBehavior *attachmentBehavior = [self createAttachmentBehaviorForBallBearing:[_balls objectAtIndex:i] toAnchor:[_anchors objectAtIndex:i]];
        [behavior addChildBehavior:attachmentBehavior];
    }
}

- (UIDynamicBehavior *)createAttachmentBehaviorForBallBearing:(id<UIDynamicItem>)ballBearing toAnchor:(id<UIDynamicItem>)anchor
{
    //把球attach到锚点上
    UIAttachmentBehavior *behavior = [[UIAttachmentBehavior alloc] initWithItem:ballBearing
                                                               attachedToAnchor:[anchor center]];
    
    return behavior;
}

- (UIDynamicBehavior *)createGravityBehaviorForObjects:(NSArray *)objects
{
    //    为所有的球添加一个重力行为
    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems:objects];
    gravity.magnitude = 10;//重力加速度，1代表加速度是（每秒100个点）
    return gravity;
}

- (UIDynamicBehavior *)createCollisionBehaviorForObjects:(NSArray *)objects
{
    //    为所有的球添加一个碰撞行为
    return [[UICollisionBehavior alloc] initWithItems:objects];
}

- (UIDynamicItemBehavior *)createItemBehavior
{
    //    为所有的球的动力行为做一个公有配置，像空气阻力，摩擦力，弹性密度等
    UIDynamicItemBehavior *itemBehavior = [[UIDynamicItemBehavior alloc] initWithItems:_balls];
    
    itemBehavior.elasticity = 0;//两个物体之间发生碰撞后的弹性。浮点值，范围0~1
    itemBehavior.resistance = 0;// 线性阻力系数。（0--CGFLOAT_MAX）
    
    
    itemBehavior.density = 1;// 物体的密度。这个主要影响在惯性上。也就是力改变这个物体运动的难易程度。浮点值，范围0~1
    itemBehavior.friction = 1;// 两个物体之间的线性滑动摩擦力。浮点值，范围0~1。
    itemBehavior.allowsRotation = NO;// 设置行为中的dynamic item是否可以循环

//    itemBehavior.angularResistance = 1;//设置角度阻力系数（

    return itemBehavior;
}

#pragma mark - Observer
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    //    Observer方法，当ball的center属性发生变化时，刷新整个view
    [self setNeedsDisplay];
}

//覆盖父类的方法，主要是为了在锚点和球之间画一条线
-(void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    for(id<UIDynamicItem> ballBearing in _balls){
        CGPoint anchor =[[_anchors objectAtIndex:[_balls indexOfObject:ballBearing]] center];
        CGPoint ballCenter = [ballBearing center];
        CGContextMoveToPoint(context, anchor.x, anchor.y);
        CGContextAddLineToPoint(context, ballCenter.x, ballCenter.y);
        CGContextSetLineWidth(context, 1.0f);
        [[UIColor blackColor] setStroke];
        CGContextDrawPath(context, kCGPathFillStroke);
    }
    [self setBackgroundColor:[UIColor whiteColor]];
}

//添加了Observer必须释放，不然会造成内存泄露。
-(void)dealloc
{
    for (Ball *ball in _balls) {
        [ball removeObserver:self forKeyPath:@"center"];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
