//
//  PaneBehavior.h
//  UIKitTest
//
//  Created by 王强 on 15/7/20.
//  Copyright (c) 2015年 王强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaneBehavior : UIDynamicBehavior

@property (nonatomic) CGPoint targetPoint;
@property (nonatomic) CGPoint veloctiy;

-(instancetype)initWithItem:(id<UIDynamicItem>)item;

@end
