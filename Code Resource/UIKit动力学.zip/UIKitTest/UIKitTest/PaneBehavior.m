//
//  PaneBehavior.m
//  UIKitTest
//
//  Created by 王强 on 15/7/20.
//  Copyright (c) 2015年 王强. All rights reserved.
//

#import "PaneBehavior.h"

@implementation PaneBehavior

-(instancetype)initWithItem:(id<UIDynamicItem>)item {
    return self;
}

- (void)setTargetPoint:(CGPoint)targetPoint {
    _targetPoint = targetPoint;

    
}


@end
