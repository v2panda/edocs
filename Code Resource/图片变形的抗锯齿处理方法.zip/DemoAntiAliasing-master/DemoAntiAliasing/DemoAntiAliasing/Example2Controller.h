//
//  Example1Controller2.h
//  DemoAntiAliasing
//
//  Created by Ralph Li on 8/31/15.
//  Copyright © 2015 LJC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface Example2Controller : ViewController

@end
