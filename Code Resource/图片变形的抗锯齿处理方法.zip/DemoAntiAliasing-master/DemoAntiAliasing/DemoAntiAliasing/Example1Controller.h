//
//  Example1Controller1.h
//  DemoAntiAliasing
//
//  Created by Ralph Li on 8/31/15.
//  Copyright © 2015 LJC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface Example1Controller : ViewController

@end
