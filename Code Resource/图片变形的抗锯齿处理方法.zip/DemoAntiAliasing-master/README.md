# DemoAntiAliasing
Demo shows Anti-Aliasing with rotated image
