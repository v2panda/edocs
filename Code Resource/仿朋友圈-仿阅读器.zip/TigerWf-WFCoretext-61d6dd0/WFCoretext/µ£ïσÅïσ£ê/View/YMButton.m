//
//  YMButton.m
//  WFCoretext
//
//  Created by 阿虎 on 14/11/4.
//  Copyright (c) 2014年 tigerwf. All rights reserved.
//

#import "YMButton.h"

@implementation YMButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
