//
//  E_Mark.h
//  WFReader
//
//  Created by 阿虎 on 15/3/2.
//  Copyright (c) 2015年 tigerwf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface E_Mark : NSObject

@property (nonatomic,strong) NSString  *markChapter;
@property (nonatomic,strong) NSString  *markRange;
@property (nonatomic,strong) NSString  *markContent;
@property (nonatomic,strong) NSString  *markTime;

@end
