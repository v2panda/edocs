# ADo_TmallPhoto
模仿天猫app 相册功能 打开相册第一个cell 为摄像头及时抓取的内容 其他为相册内的照片  (点击第一个cell进入拍摄界面,你懂得!)
<br>
<br>
<br>
<br>
![ADo_GuideGif](http://ww4.sinaimg.cn/mw690/8e4407e9jw1es8ju5qb4gg20bd0k6x6q.gif)
