//
//  ADo_SecondViewController.h
//  ADo_TmallPhotoAlbum
//
//  Created by 杜 维欣 on 15/5/19.
//  Copyright (c) 2015年 ADo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADo_SecondViewController : UIViewController

@end
