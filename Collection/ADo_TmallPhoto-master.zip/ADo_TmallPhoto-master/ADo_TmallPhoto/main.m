//
//  main.m
//  ADo_TmallPhoto
//
//  Created by 杜 维欣 on 15/5/19.
//  Copyright (c) 2015年 ADo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
