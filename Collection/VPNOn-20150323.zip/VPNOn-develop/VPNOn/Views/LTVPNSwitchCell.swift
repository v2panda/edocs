//
//  LTVPNConnectionCell.swift
//  VPNOn
//
//  Created by Lex Tang on 1/26/15.
//  Copyright (c) 2015 LexTang.com. All rights reserved.
//

import UIKit

class LTVPNSwitchCell: LTVPNTableViewCell
{
    @IBOutlet weak var switchButton: UISwitch!
    @IBOutlet weak var titleLabel: LTTableViewCellTitle!
}
