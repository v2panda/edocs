//
//  UserWeibo.swift
//  itjh_ios
//
//  Created by LijunSong on 15/3/27.
//  Copyright (c) 2015年 LijunSong. All rights reserved.
//

import Foundation

class UserWeibo: NSObject {
    
    var user_client_id = String() //用户微博id
    
    var face = String() //用户微博头像
    
    var nickname = String() //用户微博昵称
    
    var platform_id = Int() //平台
}