//
//  Article.swift
//  itjh
//
//  Created by LijunSong on 14/11/8.
//  Copyright (c) 2014年 itjh. All rights reserved.
//

import Foundation

/**
    文章实体类
*/
class Article: NSObject {
    
    var aid = Int()
    var date = NSString()
    var title = NSString()
    var img = NSString()
    var author_id = Int()
    var author = NSString()
}
