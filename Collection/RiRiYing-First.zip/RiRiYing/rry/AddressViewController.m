//
//  AddressViewController.m
//  fanfan
//
//  Created by Ren Guohua on 14-2-27.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import "AddressViewController.h"
#import "GHCache.h"

#import "AddAddressViewController.h"
#import "AddressCell.h"
#import "GlobleData.h"

@interface AddressViewController ()

@end

@implementation AddressViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
    [self initTableView];
    [self initData];
	
}

- (void)initData
{
    [self getDataFromCache];
    [self getDataFromNetwork];
}

/**
 *  从缓存中获取数据
 */
- (void)getDataFromCache
{
    NSData *data = [[GHCache shareCache] dataFromFile:_parentName];
    if (data)
    {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        addressArray = dic[@"Data"];
        [_tableView reloadData];
    }
}
/**
 *  获取地址列表
 */
- (void)getDataFromNetwork
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager GET:@"GetAreaList" parameters:[self getparameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/common/GetAreaList" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getparameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        
        [[GHCache shareCache] cacheData:responseObject tofile:self.parentName];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                addressArray = dic[@"data"];
                [_tableView reloadData];
            }
        }
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
       
    }];
}
- (NSDictionary *)getparameters
{
    
    return @{@"p_area_code":_parentId,
             };
}
- (void)setMyView
{
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)setNavigationBar
{
    self.navigationItem.title = _titleText;

//    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    

    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 44.0f, 30.0f)];
    [leftButton setTitle:@"取消" forState:UIControlStateNormal];
    [leftButton addTarget:self action:@selector(dismiss:) forControlEvents:UIControlEventTouchUpInside];
    leftButton.tintColor = [UIColor blackColor];
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
}
- (void)dismiss:(id)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height) style:UITableViewStylePlain];
    
    _tableView.backgroundColor = [UIColor whiteColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
    
    [_tableView registerClass:[AddressCell class] forCellReuseIdentifier:@"AddressCell"];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}


#pragma mark UITableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [addressArray count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0f;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddressCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AddressCell" forIndexPath:indexPath];
   
    [cell bindData:addressArray[indexPath.row]];
    return  cell;
}

#pragma mark UITableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *addressName =  addressArray[indexPath.row][@"area_name"];
    if ([self.delegate isKindOfClass:[AddAddressViewController class]])
    {
        AddAddressViewController *addViewController = (AddAddressViewController*)self.delegate;
        [addViewController resetButtonWithTag:self.buttonTag title:addressName];
    }
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning

{
    [super didReceiveMemoryWarning];
    
}

@end
