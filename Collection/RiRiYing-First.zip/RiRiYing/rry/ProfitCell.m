//
//  ProfitCell.m
//  rry
//
//  Created by Ren Guohua on 14-6-4.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "ProfitCell.h"

@implementation ProfitCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseIdentifier];
    if (self)
    {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

/**
 *  绑定数据
 *
 *  @param data 数据源
 */
- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        
        self.textLabel.text = [NSString stringWithFormat:@"%.2f",[dic[@"affect_money"] floatValue]];
        if (IOS7) {
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        } else {
            self.textLabel.font = [UIFont systemFontOfSize:15];
        }
        
        self.textLabel.textColor = UIColorFromRGB(0xa70793);
        
        self.detailTextLabel.text = dic[@"add_time"];
        if(IOS7)
            self.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    }
}

@end
