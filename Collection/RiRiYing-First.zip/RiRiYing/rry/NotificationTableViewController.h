//
//  NotificationTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-6-26.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationTableViewController : UITableViewController
{
    NSMutableArray *dataArray;
}
@property (nonatomic, strong) UILabel *hintLabel;

@end
