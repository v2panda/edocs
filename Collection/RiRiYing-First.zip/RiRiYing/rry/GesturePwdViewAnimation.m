//
//  GesturePwdViewAnimation.m
//  rry
//
//  Created by Ren Guohua on 14-6-10.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "GesturePwdViewAnimation.h"

@implementation GesturePwdViewAnimation

/**
 *
 *
 *  @param transitionContext
 *
 *  @return the animationDutation
 */
- (NSTimeInterval)transitionDuration:(id <UIViewControllerContextTransitioning>)transitionContext
{
    return 1.5f;
}
/**
 *  animate
 *
 *  @param transitionContext
 */
- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext
{
    
    // 1. Get controllers from transition context
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *toViewSnapshot = [toVC.view resizableSnapshotViewFromRect:toVC.view.frame afterScreenUpdates:YES withCapInsets:UIEdgeInsetsZero];
    // 2. Set init frame for toVC
   // CGRect screenBounds = [[UIScreen mainScreen] bounds];
    CGRect finalFrame = [transitionContext finalFrameForViewController:toVC];
    
    toViewSnapshot.frame = CGRectOffset(finalFrame, 0, 0);
    
    UIView *toView = toVC.view;
    
    // 3. Add toVC's view to containerView
    UIView *containerView = [transitionContext containerView];
    [containerView addSubview:toViewSnapshot];
    // [containerView addSubview:toView];
    [containerView addSubview:fromVC.view];
    
    
    
    // 4. Do animate now
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration
                          delay:0.0
         usingSpringWithDamping:1.0
          initialSpringVelocity:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                 
                        fromVC.view.transform = CGAffineTransformScale(fromVC.view.transform,3.0, 3.0);
                        fromVC.view.layer.opacity = 0.0f;
                         
                     } completion:^(BOOL finished) {
                         
                         // 5. Tell context that we completed.
                         // remove all the temporary views
                         if ([transitionContext transitionWasCancelled]) {
                             
                         } else {
                             
                             [containerView addSubview:toView];
                             [self removeOtherViews:toView];
                         }
                         
                         // inform the context of completion
                         [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
                     }];
    
    
}

/**
 *  // removes all the views other than the given view from the superview
 *
 *  @param viewToKeep 
 */
- (void)removeOtherViews:(UIView*)viewToKeep {
    UIView *containerView = viewToKeep.superview;
    for (UIView *view in containerView.subviews) {
        if (view != viewToKeep) {
            [view removeFromSuperview];
        }
    }
}

@end
