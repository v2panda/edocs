//
//  GlobleData.h
//  Renji
//
//  Created by Ren Guohua on 13-10-28.
//  Copyright (c) 2013年 YunFeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//@class UserData;
#import "UserData.h"

#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

#define IOS_VERSION [[[UIDevice currentDevice] systemVersion] floatValue]

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define RGB(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]

#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

@interface GlobleData : NSObject

@property (nonatomic,strong)NSString *deviceToken;
@property (nonatomic,strong)NSString *baseUrlString;
@property (nonatomic,strong)NSString *key;

+(GlobleData*)shareInfo;
-(NSString*)getPathOfFileName:(NSString*)fileName;

- (NSMutableArray*)getAllFilePathOfDocument;
- (void)removeAllfilesFromDocument;
- (NSString*)getStringFromDate:(NSDate*)date withFormatString:(NSString*)format;
- (NSDate*)getDateFromString:(NSString*)dateString withFormatString:(NSString*)format;
- (NSInteger)getWeekdayNumberFromDate:(NSDate*)date;

- (void)shutdownAllLocalNotifications;
- (BOOL) connectedToNetwork;
- (BOOL)isLogin;
- (UserData*)getUserData;
- (NSString*)zipString:(NSString*)string;
- (NSString*)unZipString:(NSString*)string;
- (NSData*)getRealDataWithData:(NSData*)data;

- (BOOL)idNumberIsvalidWithString:(NSString*)string;

- (void)saveGesture:(NSString*)passcode withUserName:(NSString*)userName;
- (NSString*)getGestureCodeWithUserName:(NSString*)userName;
+ (BOOL)isPureInt:(NSString*)string;


- (NSDictionary *)encrytUrlWithParam2:(NSDictionary *)paramDic path:(NSString *)path key:(NSString *)key;
- (NSURL *)encrytUrlWithParam:(NSDictionary *)paramDic path:(NSString *)path;
- (NSData *)decrytWithData:(NSData *)data key:(NSString *)key;

- (NSDictionary *)encrytUrlWithParam:(NSDictionary *)paramDic path:(NSString *)path key:(NSString *)key otherParamDict:(NSDictionary *)otherParamDict;

- (NSData *)encryData:(NSData *)data;

+ (NSString *)createRandomKey;

+ (void)showExceptionAlert;

@end
