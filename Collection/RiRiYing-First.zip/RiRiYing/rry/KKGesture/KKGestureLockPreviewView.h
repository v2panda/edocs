//
//  KKGestureLockPreviewView.h
//  KKGestureLockView
//
//  Created by Luke on 3/11/14.
//  Copyright (c) 2014 geeklu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KKGestureLockView.h"

@interface KKGestureLockPreviewView : KKGestureLockView

@property (nonatomic, strong) NSString *passcode;

@end
