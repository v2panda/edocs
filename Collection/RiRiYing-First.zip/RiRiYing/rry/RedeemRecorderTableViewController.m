//
//  RedeemRecorderTableViewController.m
//  rry
//
//  Created by Ren Guohua on 14-7-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RedeemRecorderTableViewController.h"
#import "RightCell.h"
#import "GlobleData.h"
#import "UserData.h"
#import "SellDetail.h"
#import "EGORefreshTableHeaderView.h"

@interface RedeemRecorderTableViewController ()<EGORefreshTableHeaderDelegate>
{
    BOOL _isFinished;
    int _page;
    
    EGORefreshTableHeaderView * _refreshHeaderView;
    BOOL _reloading;
    
    UIButton *moreBtn;
}

@end

@implementation RedeemRecorderTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavigationBar];
    [self registerCell];
    [self setMyView];
    [self initHintLabel];
    [self getReDeemDataFromNetwork];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}



/**
 *  获取http请求参数
 *
 *  @return http请求参数
 */
- (NSDictionary*)getParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
//    return @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]]};
    return @{@"user_id":[userData.userId stringValue],
             @"page": @(_page)
             };
}



/**
 *  从网络获取赎回明细
 */
- (void)getReDeemDataFromNetwork
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager GET:@"GetWithdrawList" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/money/withdrawList" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"dic == %@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                if ([dic[@"data"][@"rows"] isKindOfClass:[NSArray class]])
                {
                    
                    NSArray *tempArray = [self getRedeemDataArrayWithArray:dic[@"data"][@"rows"]];
                    //                if(tempArray.count==0)
                    //                {
                    //                    self.tableView.hidden = YES;
                    //                }
                    //                else
                    //                {
                    //                    self.tableView.hidden = NO;
                    //                }
                    
                    
                    if (_page <= 1) {
                        [dataArray removeAllObjects];
                    }
                    [dataArray addObjectsFromArray:tempArray ];
                    
                    if(dataArray.count==0)
                    {
                        _hintLabel.hidden = NO;
                    }
                    else
                    {
                        _hintLabel.hidden = YES;
                    }
                    
                    if (dataArray.count >= [dic[@"data"][@"total"] intValue] ) {
                        _isFinished = YES;
                        self.tableView.tableFooterView = nil;
                    } else {
                        _isFinished = NO;
                        self.tableView.tableFooterView = moreBtn;
                    }
                    
                    [self reloadData];
                }
            }

        }
        [self doneLoadingTableViewData];
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        [self doneLoadingTableViewData];
    }];
}

- (void)reloadData
{
    [self.tableView reloadData];
}

/**
 *  格式化赎回明细
 *
 *  @param array 疏忽明细元数据
 *
 *  @return 格式化之后的数据
 */
- (NSArray*)getRedeemDataArrayWithArray:(NSArray*)array
{
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array)
    {
        SellDetail *sell = [[SellDetail alloc] initWithDictionary:[NSMutableDictionary dictionaryWithDictionary:dic]];
        [mutableArray addObject:sell];
    }
    return [NSArray arrayWithArray:mutableArray];
}



- (void)setMyView
{
    _page = 1;
    _isFinished = NO;
    dataArray = [[NSMutableArray alloc] init];
    
    if (_refreshHeaderView ==  nil)
    {
        _refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame:
                              CGRectMake(0.0f, -10.0f - self.view.bounds.size.height,
                                         self.view.frame.size.width, self.view.bounds.size.height)];
        _refreshHeaderView.delegate = self;
        [self.tableView addSubview:_refreshHeaderView];
    }
    
    
    moreBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    moreBtn.frame=CGRectMake(0, 0, 320, 40);
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
    moreBtn.backgroundColor=[UIColor clearColor];
    [moreBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [moreBtn setTitle:@"上拉加载更多" forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(loadMore) forControlEvents:UIControlEventTouchUpInside];
    
   // self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
       self.tableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.tableView.bounds.size.width, 0.01f)];
    self.tableView.backgroundView = nil;
}

- (void)setNavigationBar
{
    
//    self.navigationItem.title = @"赎回记录";
    self.navigationItem.title = @"赎回明细";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initHintLabel
{
    _hintLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height -64.0f -50.0f)];
    if (IOS7) {
        _hintLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline]
        ;
    } else {
        _hintLabel.font = [UIFont systemFontOfSize:15];
    }
    _hintLabel.textColor = [UIColor lightGrayColor];
    _hintLabel.textAlignment = NSTextAlignmentCenter;
    _hintLabel.text = @"暂无赎回明细";
    [self.view addSubview:_hintLabel];
    [self.view sendSubviewToBack:_hintLabel];
    _hintLabel.hidden = YES;
}

- (void)registerCell
{
    [self.tableView registerClass:[RightCell class] forCellReuseIdentifier:@"RightCell"];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [dataArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RightCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RightCell" forIndexPath:indexPath];
    
    [cell bindData:dataArray[indexPath.row]];
    
    return cell;
}

#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 80.0f;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)loadMore
{
    if (!_isFinished)
    {
        _page += 1;
        
        [moreBtn setTitle:@"正在加载..." forState:UIControlStateNormal];
        
        [self getReDeemDataFromNetwork];
    }
}

#pragma mark -- tableView delegate method
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
    if (_reloading) {
        [moreBtn setTitle:@"正在加载..." forState:UIControlStateNormal];
    } else {
        float offset = scrollView.contentOffset.y;
        float contentHeight = scrollView.contentSize.height ;
        float sub = contentHeight - offset-scrollView.frame.size.height;
        
        if (((iPhone5 ? sub :  sub) < -44) && contentHeight >= scrollView.frame.size.height )
        {
            [moreBtn setTitle:@"松开加载更多" forState:UIControlStateNormal];
        } else {
            [moreBtn setTitle:@"上拉加载更多" forState:UIControlStateNormal];
        }
    }
    
    
}


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    
    if (!_reloading) {
        float offset = scrollView.contentOffset.y ;
        float  contentHeight = scrollView.contentSize.height;
        float sub = contentHeight  - offset-scrollView.frame.size.height;
        if ((iPhone5 ? sub : sub) < -44 && contentHeight >= scrollView.frame.size.height)
        {
            [self loadMore];
        }
    }
    
	
}
#pragma mark --EGORefreshTableHeaderDelegate method
- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view
{
    return _reloading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view
{
    return [NSDate date];
}

- (void)reloadTableViewDataSource
{
	_reloading = YES;
    _page = 1;
    _isFinished = NO;
	[self getReDeemDataFromNetwork];
}

- (void)doneLoadingTableViewData
{
    _reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
    
    if (_isFinished) {
        self.tableView.tableFooterView = nil;
    } else {
        self.tableView.tableFooterView = moreBtn;
    }
}

@end
