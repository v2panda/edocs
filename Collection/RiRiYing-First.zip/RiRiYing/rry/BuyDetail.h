//
//  BuyDetail.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "JSONModel.h"

@interface BuyDetail : JSONModel

//@property (nonatomic, strong) NSNumber *amount;
@property (nonatomic, strong) NSString *amount;

@property (nonatomic, strong) NSString *time;
@property (nonatomic, strong) NSNumber *fee;
@property (nonatomic, strong) NSNumber *sta;
@property (nonatomic, strong) NSString *invest_time;
@property (nonatomic, strong) NSNumber * name;

@end
