//
//  FundsViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "FundsViewController.h"
#import "FundsTypeTableViewController.h"
#import "FundsCell.h"
#import "ArrayDataSource.h"
#import "GlobleData.h"
#import "UserData.h"
#import "BuyDetail.h"
#import "SellDetail.h"

#import "RightCell.h"
#import "EGORefreshTableHeaderView.h"

@interface FundsViewController () <EGORefreshTableHeaderDelegate>
{
    BOOL _isFinished;
    int _page;
    
    EGORefreshTableHeaderView * _refreshHeaderView;
    BOOL _reloading;
    
    UIButton *moreBtn;
    
    SelectFundsType *page;
}

@end

@implementation FundsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self setMyView];
    [self setNavigationBar];
    [self initTableView];
    
    hasNoneDataText = [[UITextField alloc]init];
    hasNoneDataText.userInteractionEnabled = NO;
    hasNoneDataText.frame = CGRectMake(0, (self.view.frame.size.height-100)/2, 320, 30);
    hasNoneDataText.text = @"暂未查询到任何信息";
    hasNoneDataText.textAlignment = NSTextAlignmentCenter;
    [_tableView addSubview:hasNoneDataText];
//    [self.view sendSubviewToBack:hasNoneDataText];
    hasNoneDataText.hidden = YES;
    
    [self setNavigationTitle];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
//    [self initData];
    
    [page removeFromSuperview];
    
}


- (void)initData
{
    _type = _type ? _type :@"0";
    
}

/**
 *  从网络获取收益数据
 */
- (void)getDataFromNetwork
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager POST:@"DetailFundsList" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/money/getMoneyLog" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject ];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"dic == %@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                if ([dic[@"data"][@"rows"] isKindOfClass:[NSArray class]])
                {
                    NSLog(@"%@",dic);
                    
                    
                    NSArray *tempArray = dic[@"data"][@"rows"];
                    //                if(tempArray.count==0)
                    //                {
                    ////                    self.tableView.hidden = YES;
                    //                }
                    //                else
                    //                {
                    ////                    self.tableView.hidden = NO;
                    //                }
                    
                    
                    if (_page <= 1) {
                        [dataArray removeAllObjects];
                    }
                    [dataArray addObjectsFromArray:tempArray ];
                    
                    if (dataArray.count == 0) {
                        hasNoneDataText.hidden = NO;
                    } else {
                        hasNoneDataText.hidden = YES;
                    }
                    
                    if (dataArray.count >= [dic[@"data"][@"total"] intValue] ) {
                        _isFinished = YES;
                        self.tableView.tableFooterView = nil;
                    } else {
                        _isFinished = NO;
                        self.tableView.tableFooterView = moreBtn;
                    }
                    
                    
                    [self reloadData];
                }
            }
            else
            {
                dataArray = nil;
                self.tableView.hidden = YES;
                [self reloadData];
            }
        }
        
        [self doneLoadingTableViewData];
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        [self doneLoadingTableViewData];
    }];
}


-(void)getShuhuiDataList
{
//    _type = @"2";
    AFHTTPRequestOperationManager *sessionManager2 = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager2.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager2 GET:@"GetWithdrawList" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject2){
    
    [sessionManager2 POST:@"api/money/getMoneyLog" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data2 = [[GlobleData shareInfo] getRealDataWithData:responseObject2];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"dic == %@",dic);
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                if ([dic[@"data"][@"rows"] isKindOfClass:[NSArray class]])
                {
                    dataArray = [[NSMutableArray alloc]init];
                    NSArray *array = dic[@"data"][@"rows"];
                    for(int i=0;i<array.count;i++)
                    {
                        NSDictionary *arrayDic = [array objectAtIndex:i];
                        
                        
                        NSMutableDictionary *nodeDic = [[NSMutableDictionary alloc]init];
                        id sta = [arrayDic objectForKey:@"sta"];
                        
                        if ([sta isEqualToNumber:@-1])
                        {
                            [nodeDic setObject:@9 forKey:@"type"];
                        }
                        else if ([sta isEqualToNumber:@0])
                        {
                            [nodeDic setObject:@8 forKey:@"type"];
                        }
                        else if ([sta isEqualToNumber:@1])
                        {
                            [nodeDic setObject:@6 forKey:@"type"];
                        }
                        else if ([sta isEqualToNumber:@2])
                        {
                            [nodeDic setObject:@5 forKey:@"type"];
                        }
                        
                        [nodeDic setObject:[arrayDic objectForKey:@"amount"] forKey:@"affect_money"];
                        [nodeDic setObject:[arrayDic objectForKey:@"add_time_s"] forKey:@"add_time_s"];
                        [nodeDic setObject:@0 forKey:@"totalAmount"];
                        
                        [dataArray addObject:nodeDic];
                    }
                    dataSource.items = dataArray;
                    if(dataArray.count==0)
                    {
                        self.tableView.hidden = YES;
                    }
                    else
                    {
                        self.tableView.hidden = NO;
                    }
                    [_tableView reloadData];
                }
                else
                {
                    dataArray = nil;
                    self.tableView.hidden = YES;
                    [self reloadData];
                }
            }

        }
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
    }];
}

-(void)getGoumaiDataList
{
//    _type = @"0";
    _type = @"1";
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager POST:@"DetailFundsList" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/money/getMoneyLog" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject ];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"dic == %@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                if ([dic[@"data"][@"rows"] isKindOfClass:[NSArray class]])
                {
                    dataArray = [[NSMutableArray alloc]init];
                    NSArray *array = dic[@"data"][@"rows"];
                    for(int i=0;i<array.count;i++)
                    {
                        NSDictionary *arrayDic = [array objectAtIndex:i];
                        
                        if([[arrayDic objectForKey:@"type"] intValue]!=1)
                            continue;
                        
                        NSMutableDictionary *nodeDic = [[NSMutableDictionary alloc]init];
                        [nodeDic setObject:[arrayDic objectForKey:@"type"] forKey:@"type"];
                        [nodeDic setObject:[arrayDic objectForKey:@"affect_money"] forKey:@"affect_money"];
                        [nodeDic setObject:[arrayDic objectForKey:@"add_time_s"] forKey:@"add_time_s"];
                        [nodeDic setObject:[arrayDic objectForKey:@"totalAmount"] forKey:@"totalAmount"];
                        
                        [dataArray addObject:nodeDic];
                    }
                    dataSource.items = dataArray;
                    if(dataArray.count==0)
                    {
                        self.tableView.hidden = YES;
                    }
                    else
                    {
                        self.tableView.hidden = NO;
                    }
                    [_tableView reloadData];
                }
            }
            else
            {
                dataArray = nil;
                self.tableView.hidden = YES;
                [self reloadData];
            }

        }
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
    }];
    
//    AFHTTPSessionManager *sessionManager2 = [[AFHTTPSessionManager alloc] initWithBaseURL:BASEURL];
//    sessionManager2.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager2 GET:@"GetRechargeList" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject2){
//        
//        NSData *data2 = [[GlobleData shareInfo] getRealDataWithData:responseObject2];
//        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data2 options:NSJSONReadingMutableLeaves error:nil];
//        NSLog(@"dic == %@",dic);
//        if ([dic[@"StateCode"] isEqualToNumber:@1] )
//        {
//            if ([dic[@"Data"] isKindOfClass:[NSArray class]])
//            {
//                dataArray = [[NSMutableArray alloc]init];
//                NSArray *array = dic[@"Data"];
//                for(int i=0;i<array.count;i++)
//                {
//                    NSDictionary *arrayDic = [array objectAtIndex:i];
//                    
//                    
//                    NSMutableDictionary *nodeDic = [[NSMutableDictionary alloc]init];
//                    [nodeDic setObject:@1 forKey:@"type"];
//                    [nodeDic setObject:[arrayDic objectForKey:@"amount"] forKey:@"affect_money"];
//                    [nodeDic setObject:[arrayDic objectForKey:@"add_time_s"] forKey:@"add_time_s"];
//                    [nodeDic setObject:@0 forKey:@"totalAmount"];
//                    
//                    [dataArray addObject:nodeDic];
//                }
//                dataSource.items = dataArray;
//                [_tableView reloadData];
//            }
//            else
//            {
//                dataArray = nil;
//                [self reloadData];
//            }
//        }
//        
//    } failure:^(AFHTTPRequestOperation *task, NSError *error){
//        
//    }];
}


-(void)getJiangliDataList
{
    _type = @"0";
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager POST:@"DetailFundsList" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/money/getMoneyLog" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject ];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"dic == %@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                if ([dic[@"data"] isKindOfClass:[NSArray class]])
                {
                    dataArray = [[NSMutableArray alloc]init];
                    NSArray *array = dic[@"data"];
                    for(int i=0;i<array.count;i++)
                    {
                        NSDictionary *arrayDic = [array objectAtIndex:i];
                        
                        if([[arrayDic objectForKey:@"type"] intValue]!=7)
                            continue;
                        
                        NSMutableDictionary *nodeDic = [[NSMutableDictionary alloc]init];
                        [nodeDic setObject:@7 forKey:@"type"];
                        [nodeDic setObject:[arrayDic objectForKey:@"affect_money"] forKey:@"affect_money"];
                        [nodeDic setObject:[arrayDic objectForKey:@"add_time_s"] forKey:@"add_time_s"];
                        [nodeDic setObject:[arrayDic objectForKey:@"totalAmount"] forKey:@"totalAmount"];
                        
                        [dataArray addObject:nodeDic];
                    }
                    dataSource.items = dataArray;
                    if(dataArray.count==0)
                    {
                        self.tableView.hidden = YES;
                    }
                    else
                    {
                        self.tableView.hidden = NO;
                    }
                    [_tableView reloadData];
                }
            }
            else
            {
                dataArray = nil;
                self.tableView.hidden = YES;
                [self reloadData];
            }

        }
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
    }];
}

/**
 *  重载数据
 */
- (void)reloadData
{
    dataSource.items = dataArray;
    [_tableView reloadData];
}

/**
 *  HTTP请求参数
 *
 *  @return 返回字典 — 请求参数
 */

- (NSDictionary*)getParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
//    return @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//             @"type":[[GlobleData shareInfo] zipString:_type]
//             };
    return @{@"user_id":[userData.userId stringValue],
             @"type":_type,
             @"time_type": @"0",
             @"page": @(_page)
             };
}


- (void)setMyView
{
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
}

/**
 *  设置导航栏
 */
- (void)setNavigationBar
{
    
    
    
    //self.navigationItem.title = @"资金明细";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
/**
 *  导航栏左按钮点击事件
 *
 *  @param sender
 */
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  设置导航栏title
 */
- (void)setNavigationTitle
{
    UIButton *titleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    titleButton.frame = (CGRect){
        
        .origin.x = 0.0f,
        .origin.y = 0.0f,
        .size.width = 100.0f,
        .size.height = 32.0f
        
    };
    
    if ([_type isEqualToString:@"0"])
    {
        [titleButton setTitle:@"资金明细▼" forState:UIControlStateNormal];
    }
    else if([_type isEqualToString:@"1"])
    {
        [titleButton setTitle:@"返收益▼" forState:UIControlStateNormal];
    }
    
   // [titleButton setImage:[UIImage imageNamed:@"icon_cancel.png"] forState:UIControlStateNormal];
    [titleButton addTarget:self action:@selector(titleButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.titleView = titleButton;
}

/**
 *  导航栏标题的点击事件
 *
 *  @param sender 
 */
- (void)titleButtonClicked:(id)sender
{
    ///zzzili
    page = [[SelectFundsType alloc]init];
    page.frame = CGRectMake(0, 0, 320, 568);
    page.delegate = self;
    page.backgroundColor = [UIColor clearColor];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:page];

    
//    FundsTypeTableViewController *fundsTypeVC = [[FundsTypeTableViewController alloc] init];
//    fundsTypeVC.delegate = self;
//    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:fundsTypeVC];
//    [self presentViewController:nav animated:YES completion:nil];
}

-(void)GetFundsType:(int)type name:(NSString*)name
{
    UIButton *titleBtn = (UIButton*)self.navigationItem.titleView;
    [titleBtn setTitle:name forState:UIControlStateNormal];
    
    _page = 1;
    _isFinished = NO;
//    if(type==0||type==1)
//    {
        _type = [NSString stringWithFormat:@"%d",type];
        [self getDataFromNetwork];
//    }
//    else if(type==4)
//    {
//        [self getJiangliDataList];
//    }
//    else if(type==2)
//    {
//        [self getGoumaiDataList];
//    }
//    else if(type==3)
//    {
//        [self getShuhuiDataList];
//    }
}

/**
 *  初始化赎回明细TableView
 */
- (void)initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height - 64.0f) style:UITableViewStyleGrouped];
    _tableView.backgroundView = nil;
    _tableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, _tableView.bounds.size.width, 0.01f)];
    _tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
    [_tableView registerClass:[FundsCell class] forCellReuseIdentifier:@"FundsCell"];
    
    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:nil otherIdentifier:@"FundsCell" configureCellBlock:^(id cell, id data){
        
        if ([_type isEqualToString: @"2"]) {
            [cell bindData2:data];
        } else {
            [cell bindData:data];
        }
        
    }];
    
    _tableView.dataSource = dataSource;
    _tableView.delegate = self;
    
    
    [self.view addSubview:_tableView];
    
    _page = 1;
    _isFinished = NO;
    dataArray = [[NSMutableArray alloc] init];
    
    if (_refreshHeaderView ==  nil)
    {
        _refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame:
                              CGRectMake(0.0f, -10.0f - self.view.bounds.size.height,
                                         self.view.frame.size.width, self.view.bounds.size.height)];
        _refreshHeaderView.delegate = self;
        [self.tableView addSubview:_refreshHeaderView];
    }
    
    moreBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    moreBtn.frame=CGRectMake(0, 0, 320, 40);
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
    moreBtn.backgroundColor=[UIColor clearColor];
    [moreBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [moreBtn setTitle:@"上拉加载更多" forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(loadMore) forControlEvents:UIControlEventTouchUpInside];
    
    [self getDataFromNetwork];
}



#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 65.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}

-(void)loadMore
{
    if (!_isFinished)
    {
        _page += 1;
        
        [moreBtn setTitle:@"正在加载..." forState:UIControlStateNormal];
        
        [self getDataFromNetwork];
    }
}

#pragma mark -- tableView delegate method
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
    if (_reloading) {
        [moreBtn setTitle:@"正在加载..." forState:UIControlStateNormal];
    } else {
        float offset = scrollView.contentOffset.y;
        float contentHeight = scrollView.contentSize.height ;
        float sub = contentHeight - offset-scrollView.frame.size.height;
        
        if (((iPhone5 ? sub :  sub) < -44) && contentHeight >= scrollView.frame.size.height )
        {
            [moreBtn setTitle:@"松开加载更多" forState:UIControlStateNormal];
        } else {
            [moreBtn setTitle:@"上拉加载更多" forState:UIControlStateNormal];
        }
    }
    
    
}


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    
    if (!_reloading) {
        float offset = scrollView.contentOffset.y ;
        float  contentHeight = scrollView.contentSize.height;
        float sub = contentHeight  - offset-scrollView.frame.size.height;
        if ((iPhone5 ? sub : sub) < -44 && contentHeight >= scrollView.frame.size.height)
        {
            [self loadMore];
        }
    }
    
	
}
#pragma mark --EGORefreshTableHeaderDelegate method
- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view
{
    return _reloading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view
{
    return [NSDate date];
}

- (void)reloadTableViewDataSource
{
	_reloading = YES;
    _page = 1;
    _isFinished = NO;
	[self getDataFromNetwork];
}

- (void)doneLoadingTableViewData
{
    _reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
    
    if (_isFinished) {
        self.tableView.tableFooterView = nil;
    } else {
        self.tableView.tableFooterView = moreBtn;
    }
}

@end
