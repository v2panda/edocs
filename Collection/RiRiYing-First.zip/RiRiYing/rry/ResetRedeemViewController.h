//
//  ResetRedeemViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-27.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResetRedeemViewController : UIViewController<UITextFieldDelegate>
{
    NSTimer *verifyTimer;
    NSInteger verifiedTime;
}

@property (nonatomic, strong) UITextField *verifiedCodeField;
@property (nonatomic, strong) UITextField *currentPasswordField;
@property (nonatomic, strong) UITextField *phoneTextField;
@property (nonatomic, strong) UITextField *idCardTextField;

@property (nonatomic, strong) UIImageView *verifiedCodeLineView;
@property (nonatomic, strong) UIImageView *currentPasswordLineView;
@property (nonatomic, strong) UIImageView *phoneLineView;

@property (nonatomic, strong) UIButton *getVerifiedCodeButton;
@property (nonatomic, strong) UILabel *verifiedRightLabel;

@property (nonatomic, strong) NSString *phoneNumber;
@property (nonatomic, strong) NSString *verifiedCode;



@end
