//
//  MailCheckTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-6-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MailCheckFooterView;

@interface MailCheckTableViewController : UITableViewController<UIGestureRecognizerDelegate>
{
    NSArray *dataArray;
}
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) NSMutableDictionary *cellStringDic;
@property (nonatomic, strong) MailCheckFooterView* footerView;
@end
