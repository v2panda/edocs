//
//  AddBankCardViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "AddBankCardViewController.h"
#import "BankCardTypeTableViewController.h"
#import "GlobleData.h"

@interface AddBankCardViewController ()

@end

@implementation AddBankCardViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
    [self initCardNumberTextField];
    [self initNextButton];
    [self addTap];
}

- (void)setMyView
{
    self.view.backgroundColor = UIColorFromRGB(0xf7f7f7);
}

- (void)setNavigationBar
{
    self.navigationItem.title = @"添加银行卡号";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
    
    
}
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  输入卡号
 */
- (void)initCardNumberTextField
{
    _cardNumberTextField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 30.0f, 320.0f, 44.0f)];
    
    UILabel *leftView = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 66.0f, 44.0f)];
    leftView.text = @"卡号";
    leftView.textAlignment = NSTextAlignmentCenter;
    leftView.textColor = [UIColor lightGrayColor];

    _cardNumberTextField.leftView = leftView;
    _cardNumberTextField.leftViewMode = UITextFieldViewModeAlways;

    _cardNumberTextField.backgroundColor = [UIColor whiteColor];
    _cardNumberTextField.delegate = self;
    _cardNumberTextField.keyboardType = UIKeyboardTypeNumberPad;
    _cardNumberTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [self.view addSubview:_cardNumberTextField];
    
    UIView *topLineView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMinY(_cardNumberTextField.frame) - 1.0f, self.view.frame.size.width, 1.0f)];
    topLineView.backgroundColor = UIColorFromRGB(0xe0e0e0);
    [self.view addSubview:topLineView];
    
    UIView *bottomLineView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_cardNumberTextField.frame), self.view.frame.size.width, 1.0f)];
    bottomLineView.backgroundColor = UIColorFromRGB(0xe0e0e0);
    [self.view addSubview:bottomLineView];
}

/**
 *  下一步按钮
 */
- (void)initNextButton
{
    _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _nextButton.frame = CGRectInset(CGRectOffset(_cardNumberTextField.frame, 0.0f, 89.0f), 20.0f, 5.0f) ;
    
    _nextButton.backgroundColor = UIColorFromRGB(0x36a41d);
    _nextButton.tintColor = UIColorFromRGB(0xffffff);
    _nextButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_nextButton setTitle:@"下一步" forState:UIControlStateNormal];
    [_nextButton addTarget:self action:@selector(nextButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _nextButton.layer.cornerRadius = 3.0f;
    
    [self.view addSubview:_nextButton];
    
}

/**
 *  下一步按钮点击事件
 *
 *  @param sender
 */

- (void)nextButtonClicked:(id)sender
{
    [self makeKeyBoardMiss];
    if ([self inputIsIlligal])
    {
        return;
    }
    [self checkBankCardIsBindOrNot];
}

/**
 *  检测该银行卡是否已经被绑定
 */

- (void)checkBankCardIsBindOrNot
{
    UIAlertView *loadingAlert=[[UIAlertView alloc] initWithTitle:@"正在检测银行卡信息..." message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:nil,nil];
    loadingAlert.alertViewStyle=UIAlertViewStyleDefault;
    [loadingAlert show];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc]initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    NSDictionary *parameters = [self getParameters];
//    [sessionManager POST:@"CheckCardNumber" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/member/checkBankNumber" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
    
        [loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];

        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@0] )
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"身份证号已存在" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
            else if([dic[@"sta"] isEqualToNumber:@1])
            {
                [self pushNext];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"服务器异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }

        }
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        [loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        
    }];
    
}

/**
 *  获取Http请求参数
 *
 *  @return Http请求参数
 */
- (NSDictionary*)getParameters
{
    NSLog(@"number == %@",[[GlobleData shareInfo] zipString:_cardNumberTextField.text]);
//    return  @{@"card_number":[[GlobleData shareInfo] zipString:_cardNumberTextField.text],
//              };
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    
    return  @{@"card_number":[_cardNumberTextField.text stringByReplacingOccurrencesOfString:@" " withString:@""],
              @"user_id": [userData.userId stringValue]
              };
}

/**
 *  切换到下一个绑定银行卡的viewController
 */
- (void)pushNext
{
    BankCardTypeTableViewController *cardTypeVC = [[BankCardTypeTableViewController alloc] init];
    cardTypeVC.cardNumber = _cardNumberTextField.text;
    [self.navigationController pushViewController:cardTypeVC animated:YES];

}

/**
 *  判断输入是否合法
 *
 *  @return YES－非法 NO－合法
 */
- (BOOL)inputIsIlligal
{
    if (_cardNumberTextField.text.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"卡号不能为空" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }

    return NO;
}


#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.frame.origin.y+textField.frame.size.height > self.view.frame.size.height -216.0f-22.0f)
    {
        CGFloat offY = (self.view.frame.size.height-216.0f)-textField.frame.size.height-textField.frame.origin.y-22.0f;//屏幕总高度-键盘高度-UITextField高度
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        self.view.frame = CGRectMake(self.view.frame.origin.x, offY-44.0f, self.view.frame.size.width, self.view.frame.size.height);//UITextField位置的y坐标移动到offY
        [UIView commitAnimations];//开始动画效果
    }
    else
    {
        [self recoverFrame];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        [self recoverFrame];
        return NO;
    }
    
    NSString *realString = [textField.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (realString.length >= 19 && ![string isEqualToString:@""])
    {
        return NO;
    }
    
    if (realString.length % 4 == 0 && ![string isEqualToString:@""] && realString.length != 0)
    {
        textField.text = [NSString stringWithFormat:@"%@ ",textField.text];
    }
    return YES;
}

/**
 *  恢复各个view的位置大小
 */
-(void)recoverFrame
{
    [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
    [UIView setAnimationDuration:0.3];
    //UITextField位置复原
    
    self.view.frame = CGRectMake(0.0f,self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height);
    [UIView commitAnimations];
}

/**
 *  增加点击手势
 */
- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.view addGestureRecognizer:tap];
}
/**
 *  点击事件
 *
 *  @param recognizer 手势
 */

-( void)tap:(UIGestureRecognizer *)recognizer
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
}

/**
 *  隐藏键盘
 */
- (void)makeKeyBoardMiss
{
    for (id textField in [self.view subviews])
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            UITextField *theTextField = (UITextField*)textField;
            [theTextField resignFirstResponder];
        }
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


@end
