//
//  UserData.m
//  jkt
//
//  Created by Ren Guohua on 14-5-13.
//  Copyright (c) 2014年 ghren. All rights reserved.
//

#import "UserData.h"

@implementation UserData

/**
 *  KVC方法，生成自定义的属性
 *
 *  @param value 值
 *  @param key   键
 */
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    // subclass implementation should set the correct key value mappings for custom keys
    if ([key isEqualToString:@"userid"])
    {
        self.userId = value;
    }
    if ([key isEqualToString:@"idcard_img"])
    {
        self.userId = value;
    }
    else if ([key isEqualToString:@"real_name"])
    {
        self.realName = value;
    }
    else if ([key isEqualToString:@"mobile"])
    {
        self.phoneNumber = value;
    }
    else if ([key isEqualToString:@"idcard_sta"])
    {
        self.realNameVerified = value;
    }
    else if ([key isEqualToString:@"idcard"])
    {
        self.idcard = value;
    }
    else if ([key isEqualToString:@"email_sta"])
    {
        self.emailVerified = value;
    }
    else if ([key isEqualToString:@"email"])
    {
        self.email = value;
    }
    else if ([key isEqualToString:@"mobile_sta"])
    {
        self.phoneNumberVerified = value;
    }
    else if ([key isEqualToString:@"encrypt_key"])
    {
        self.secret_key = value;
    }
    else if ([key isEqualToString:@"bank_sta"])
    {
        self.bank_sta = value;
    }
    else
    {
        [super setValue:value forUndefinedKey:key];
    }
}

@end
