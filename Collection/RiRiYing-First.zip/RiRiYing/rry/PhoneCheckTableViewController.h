//
//  PhoneCheckTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-6-14.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PhoneCheckFooterView;
@interface PhoneCheckTableViewController : UITableViewController<UIGestureRecognizerDelegate>
{
    NSArray *dataArray;
}
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) NSMutableDictionary *cellStringDic;
@property (nonatomic, strong) PhoneCheckFooterView* footerView;

@end
