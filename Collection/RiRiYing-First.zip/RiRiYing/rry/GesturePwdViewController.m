//
//  GesturePwdViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-27.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "GesturePwdViewController.h"
#import "FBShimmeringView.h"
#import "GesturePwdViewAnimation.h"
#import "GlobleData.h"
#import "UserData.h"
#import "LoginViewController.h"

@interface GesturePwdViewController ()

@end

@implementation GesturePwdViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        setCount = 0;
        inputCount = 0;
        entErrorNum = 0;
        isCheckOldPassOk = NO;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self initBgView];
    [self initLockView];
    [self initShimmeringView];
    [self initTitleLabel];
    if(self.isChangePW==YES)
    {
        ///加返回按钮
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:@"返回" forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:14];
        btn.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        [btn addTarget:self action:@selector(touchReturn) forControlEvents:UIControlEventTouchDown];
        btn.frame = CGRectMake(5, 25, 40, 30);
        [self.view addSubview:btn];
    }
    
}

-(void)touchReturn
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

/**
 *  设置自身View
 */
- (void)setMyView
{
    self.view.backgroundColor = [UIColor whiteColor];
    
}
/**
 *  初始化背景View
 */
- (void)initBgView
{
    _bgView = [[UIImageView alloc] initWithFrame:(CGRect){0.0f,0.0f,self.view.frame.size.width, self.view.frame.size.height}];
    _bgView.image = [UIImage imageNamed:@"gesture.png"];
    [self.view addSubview:_bgView];
    /*
     NSArray *imagesArray = @[
     [UIImage imageNamed:@"gesture.png"],
     [UIImage imageNamed:@"gesture1.png"],
     [UIImage imageNamed:@"gesture2.png"],
     [UIImage imageNamed:@"gesture3.png"],
     [UIImage imageNamed:@"gesture4.png"],
     [UIImage imageNamed:@"gesture5.png"],
     [UIImage imageNamed:@"gesture6.png"],
     [UIImage imageNamed:@"gesture7.png"],
     [UIImage imageNamed:@"gesture7.png"],
     [UIImage imageNamed:@"gesture6.png"],
     [UIImage imageNamed:@"gesture5.png"],
     [UIImage imageNamed:@"gesture4.png"],
     [UIImage imageNamed:@"gesture3.png"],
     [UIImage imageNamed:@"gesture2.png"],
     [UIImage imageNamed:@"gesture1.png"],
     ];
     
     _bgView.animationImages = imagesArray;
     _bgView.animationDuration = 2.5f;
     _bgView.animationRepeatCount = 0;
     
     [_bgView startAnimating];
     */
    
}

/**
 *  初始化发光字体View
 */
- (void)initShimmeringView
{
    _shimmeringView = [[FBShimmeringView alloc] initWithFrame:(CGRect){
        
        .origin.x = 0.0f,
        .origin.y = 64.0f,
        .size.width = 320.0f,
        .size.height = 44.0f,
    }];
    _shimmeringView.shimmering = YES;
    _shimmeringView.shimmeringBeginFadeDuration = 0.3f;
    _shimmeringView.shimmeringEndFadeDuration = 0.3f;
    _shimmeringView.shimmeringOpacity = 0.3f;
    [self.view addSubview:_shimmeringView];
}

/**
 *  初始化标题Label
 */
- (void)initTitleLabel
{
    _titleLabel = [[UILabel alloc] initWithFrame:(CGRect){0.0f,0.0f,320.0f,44.0f}];
    _titleLabel.text = @"设置手势密码";
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.textColor = UIColorFromRGB(0xedf3df);
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.font = [UIFont systemFontOfSize:15.0f];
    self.shimmeringView.contentView = _titleLabel;
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"gesturePwd"] == nil)
    {
        _titleLabel.text = @"设置手势密码";
    }
    else
    {
        if (_isChangePW)
        {
            _titleLabel.text = @"输入旧的手势密码";
        }
        else
        {
            _titleLabel.text = @"输入手势密码";
        }
    }
}

/**
 *  初始化手势密码View
 */
- (void)initLockView
{
    self.lockView = [[KKGestureLockView alloc] initWithFrame:(CGRect){0.0f,0.0f,self.view.frame.size.width, self.view.frame.size.height}];
    self.lockView.normalGestureNodeImage = [UIImage imageNamed:@"gesture_node_normal.png"];
    self.lockView.selectedGestureNodeImage = [UIImage imageNamed:@"gesture_node_selected.png"];
    self.lockView.lineColor = [[UIColor orangeColor] colorWithAlphaComponent:0.3];
    self.lockView.lineWidth = 12;
    self.lockView.delegate = self;
    self.lockView.contentInsets = UIEdgeInsetsMake(150, 20, 100, 20);
    
    [self.view addSubview:_lockView];
    
}

#pragma mark - gesturLockView delegate
- (void)gestureLockView:(KKGestureLockView *)gestureLockView didBeginWithPasscode:(NSString *)passcode
{
    
}

/**
 *  手势密码输入完毕后的回调函数
 *
 *  @param gestureLockView  手势View
 *  @param passcode        密码
 */
- (void)gestureLockView:(KKGestureLockView *)gestureLockView didEndWithPasscode:(NSString *)passcode
{
    if(passcode.length<7)
    {
        _titleLabel.text = @"密码长度不能少于4位";
        return;
    }
    if(_isChangePW)//是修改密码zzzili
    {
        if(setCount == 0)
        {
            if ([[[GlobleData shareInfo] getGestureCodeWithUserName:[[[GlobleData shareInfo] getUserData].userId stringValue]] isEqualToString:passcode]||isCheckOldPassOk==YES)
            {
                _titleLabel.text = @"输入新的手势密码";
                setCount ++;
            }
            else
            {
                _titleLabel.text = @"输入错误,请重新输入";
                [self setErrorAnimation];
                entErrorNum ++;
                if(entErrorNum>=5)
                {
//                    //输入用户密码来确认
//                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"请输入用户登录密码" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"验证", nil];
//                    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
//                    UITextField * textField = [alert textFieldAtIndex:0];
//                    textField.secureTextEntry = YES;
//                    alert.tag = 999;
//                    [alert show];
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"你已经连续5次输错手势，手势解锁已关闭，请重新登录！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
                    alert.tag = 998;
                    [alert show];
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"gesturePwd"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
        }
        else if (setCount == 1)
        {
            gestureString = passcode;
            _titleLabel.text = @"重复输入手势密码";
            setCount ++;
        }
        else if (setCount == 2)
        {
            if ([passcode isEqualToString:gestureString])
            {
                _titleLabel.text = @"手势密码设置成功";
                
                UserData *userData = [[GlobleData shareInfo] getUserData];
                
                if (userData)
                {
                    [[GlobleData shareInfo] saveGesture:passcode withUserName:[userData.userId stringValue]];
                }
                
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else
            {
                _titleLabel.text = @"两次输入密码不一致,请重新设置密码";
                setCount = 1;
                [self setErrorAnimation];
            }
        }
        
        return;
    }
    if ([[GlobleData shareInfo] getGestureCodeWithUserName:[[[GlobleData shareInfo] getUserData].userId stringValue]] == nil)
    {
        setCount ++;
        if (setCount == 1)
        {
            gestureString = passcode;
            _titleLabel.text = @"重复输入手势密码";
        }
        if (setCount == 2)
        {
            if ([passcode isEqualToString:gestureString])
            {
                _titleLabel.text = @"手势密码设置成功";
                
                UserData *userData = [[GlobleData shareInfo] getUserData];
                if (userData)
                {
                    [[GlobleData shareInfo] saveGesture:passcode withUserName:[userData.userId stringValue]];
                }
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else
            {
                _titleLabel.text = @"两次输入密码不一致,请重新设置密码";
                setCount = 0;
                [self setErrorAnimation];
            }
        }
    }
    else
    {
        if ([[[GlobleData shareInfo] getGestureCodeWithUserName:[[[GlobleData shareInfo] getUserData].userId stringValue]] isEqualToString:passcode]||isCheckOldPassOk==YES)
        {
            _titleLabel.text = @"输入正确";
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        else
        {
            _titleLabel.text = @"输入错误,请重新输入";
            [self setErrorAnimation];
            entErrorNum ++;
            if(entErrorNum>=5)
            {
                //输入用户密码来确认
//                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"手势密码已失效，请重新登录" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"你已经连续5次输错手势，手势解锁已关闭，请重新登录！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
//                alert.alertViewStyle = UIAlertViewStylePlainTextInput;
//                UITextField * textField = [alert textFieldAtIndex:0];
//                textField.secureTextEntry = YES;
                alert.tag = 998;
                [alert show];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"gesturePwd"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
        }
    }
}

/**
 *  输入错误时候的提示动画
 */
- (void)setErrorAnimation
{
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
    animation.keyPath = @"position.x";
    animation.values = @[ @0, @10, @-10, @10, @0 ];
    animation.keyTimes = @[ @0, @(1 / 6.0), @(3 / 6.0), @(5 / 6.0), @1 ];
    animation.duration = 0.4;
    
    animation.additive = YES;
    [_titleLabel.layer removeAllAnimations];
    [_titleLabel.layer addAnimation:animation forKey:@"shake"];
}

- (void)gestureLockView:(KKGestureLockView *)gestureLockView didCanceledWithPasscode:(NSString *)passcode
{
    
}

#pragma  animation
- (id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed
{
    return [GesturePwdViewAnimation new];
}


#pragma mark - Status Bar

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    
    return UIStatusBarAnimationFade;
}
- (BOOL)prefersStatusBarHidden
{
    return NO;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==999)
    {
        if(buttonIndex==1)
        {
            UITextField * textField = [alertView textFieldAtIndex:0];
            ///zzzili14
            NSString *myPass = [[NSUserDefaults standardUserDefaults]objectForKey:@"zzuserPass"];
            if([textField.text isEqualToString:myPass])
            {
                isCheckOldPassOk = YES;
                entErrorNum = 0;
                [self gestureLockView:nil didEndWithPasscode:@"-------"];
            }
            else
            {
                isCheckOldPassOk = NO;
                //输入用户密码来确认
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"请输入用户登录密码" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"验证", nil];
                alert.alertViewStyle = UIAlertViewStylePlainTextInput;
                UITextField * textField = [alert textFieldAtIndex:0];
                textField.secureTextEntry = YES;
                alert.tag = 999;
                [alert show];
            }
        }
        else
        {
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    }
    else if(alertView.tag==998)
    {
        if(buttonIndex==0)
        {
            LoginViewController *loginVC = [[LoginViewController alloc] init];
            loginVC.isHomePage = NO;
            loginVC.delegate = self;
            NSLog(@"%@", NSStringFromClass([self.parentController class]));
            
            if ([self.parentController isKindOfClass:[LoginViewController class]]) {
                loginVC.isHomePage = YES;
                UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:loginVC];
                [self presentViewController:nav animated:YES completion:nil];
            } else {
                
                [self.parentController.navigationController pushViewController:loginVC animated:YES];
                [self dismissViewControllerAnimated:NO completion:nil];
            }
            //[self presentViewController:loginVC animated:YES completion:nil];
            
            
            
        }
    }
}

@end
