//
//  ArrayDataSource.h
//  fanfan
//
//  Created by Ren Guohua on 14-3-29.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ArrayDataSource : NSObject<UITableViewDataSource>
{
    void (^configureCellBlock)(id, id);
}
@property (nonatomic, strong) NSArray *items;
@property (nonatomic, strong) NSDictionary *cellIdentifierDic;
@property (nonatomic, strong) NSString *otherIdentifier;
@property (nonatomic, strong) id otherProperty;

/**
 *  初始化tableView数据源
 *
 *  @param itemArray       数据
 *  @param identifierDic   特殊的cell和标识
 *  @param otherIdentifier 一般的cell和标识
 *  @param configureCell   配置cell
 *
 *  @return 返回生成的数据源
 */
- (id)initWithItems:(NSArray*)itemArray
  cellIdentifierDic:(NSDictionary*)identifierDic
    otherIdentifier:(NSString*)otherIdentifier
 configureCellBlock:(void (^)(id, id))configureCell;
@end
