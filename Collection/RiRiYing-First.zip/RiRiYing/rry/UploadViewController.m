//
//  UploadViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-26.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "UploadViewController.h"
#import "GlobleData.h"
#import "UserData.h"

@interface UploadViewController ()

@end

@implementation UploadViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyview];
    [self setNavigationBar];
    [self initTopLabel];
    [self initLeftImageView];
    [self initRightImageView];
    [self initHintLabel];
    [self initFinishButton];
}


- (void)setMyview
{
    self.view.backgroundColor = UIColorFromRGB(0xf7f7f7);
}
- (void)setNavigationBar
{
    self.navigationItem.title = @"上传身份证";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initTopLabel
{
    _topLabel = [[UILabel alloc] initWithFrame:(CGRect){20.0f,0.0f,280.0f,44.0f}];
    _topLabel.text = @"上传身份证正面和背面两张照片";
    _topLabel.font = [UIFont systemFontOfSize:13.0f];
    _topLabel.textColor = [UIColor lightGrayColor];
    _topLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_topLabel];
}

- (void)initLeftImageView
{
    _leftImageView = [[UIImageView alloc] initWithFrame:(CGRect){20.0f,CGRectGetMaxY(_topLabel.frame) + 10.0f, 63.0f, 63.0f}];
    _leftImageView.backgroundColor = [UIColor lightGrayColor];
    _leftImageView.image = [UIImage imageNamed:@"正面.png"];
    [self.view addSubview:_leftImageView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapLeft:)];
    [_leftImageView addGestureRecognizer:tap];
    _leftImageView.userInteractionEnabled = YES;
}

- (void)tapLeft:(UIGestureRecognizer *)recognizer
{
    isRightImage = NO;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"相册", @"拍照",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
    
}
- (void)initRightImageView
{
    _rightImageView = [[UIImageView alloc] initWithFrame:(CGRect){CGRectGetMaxX(_leftImageView.frame) + 20.0f,CGRectGetMaxY(_topLabel.frame) + 10.0f, 63.0f, 63.0f}];
    _rightImageView.backgroundColor = [UIColor lightGrayColor];
    _rightImageView.image = [UIImage imageNamed:@"背面.png"];
    [self.view addSubview:_rightImageView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapRight:)];
    [_rightImageView addGestureRecognizer:tap];
    _rightImageView.userInteractionEnabled = YES;
    
}

- (void)tapRight:(UIGestureRecognizer *)recognizer
{
    isRightImage = YES;

    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"相册", @"拍照",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
    
}

- (void)pickImageFromPhotoLibrary
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    imagePicker.allowsEditing = NO;
    
    [self presentViewController:imagePicker animated:YES completion:nil];
}
- (void)pickImageFromCamera
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    imagePicker.allowsEditing = NO;
    imagePicker.showsCameraControls = YES;
    
    [self presentViewController:imagePicker animated:YES completion:nil];
}


- (NSString*)convertToBase64StringWithImage:(UIImage*)image
{
    ///zzzili
    NSData *data = UIImageJPEGRepresentation(image, 0.2);//UIImagePNGRepresentation(image);
    NSString *base64String = [data base64EncodedStringWithOptions:0];
    return base64String;
}

- (void)initHintLabel
{
    _hintLabel = [[UILabel alloc] initWithFrame:(CGRect){20.0f,CGRectGetMaxY(_leftImageView.frame) + 30.0f,260.0f,66.0f}];
    _hintLabel.text = @"需要提交身份证之后才能进行提现(赎回)操作";
    _hintLabel.backgroundColor = [UIColor clearColor];
    _hintLabel.font = [UIFont systemFontOfSize:13.0f];
    _hintLabel.numberOfLines = 0;
    _hintLabel.textColor = [UIColor lightGrayColor];
    [self.view addSubview:_hintLabel];
}

- (void)initFinishButton
{
    _finishButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _finishButton.frame = CGRectInset(CGRectMake(0.0f,CGRectGetMaxY(_hintLabel.frame) + 20.0f, 320.0f, 44.0f), 20.0f, 5.0f);
    
    _finishButton.backgroundColor = UIColorFromRGB(0x36a41d);
    _finishButton.tintColor = UIColorFromRGB(0xffffff);
    _finishButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_finishButton setTitle:@"完成" forState:UIControlStateNormal];
    [_finishButton addTarget:self action:@selector(finishButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _finishButton.layer.cornerRadius = 3.0f;
    
    [self.view addSubview:_finishButton];
}

- (void)finishButtonClicked:(id)sender
{
    if ([self inputIsIlligal])
    {
        return;
    }
    
    _loadingAlert=[[UIAlertView alloc] initWithTitle:@"正在上传..." message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:nil,nil];
    _loadingAlert.alertViewStyle=UIAlertViewStyleDefault;
    [_loadingAlert show];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSDictionary *parameters = [self getParameters];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self regWithParameters:parameters];
        });
        
    });
    
}
- (void)regWithParameters:(NSDictionary*)parameters
{
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    [sessionManager POST:@"uploadUserImg" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    
    

    NSDictionary *finalDict = [[GlobleData shareInfo] encrytUrlWithParam:parameters path:nil key:[GlobleData shareInfo].key otherParamDict:[self getOtherParameters]];
    [sessionManager POST:@"api/member/UploadIdcard"  parameters:finalDict success:^(AFHTTPRequestOperation *task, id responseObject){
        
        [_loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSLog(@"123:%@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"上传成功" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                alert.tag = 1;
                [alert show];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"上传失败" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
        }
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        [_loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (NSDictionary*)getParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    
  //  NSLog(@"left == %@",leftBase64String);
    
//    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//              @"idcard_img":[[GlobleData shareInfo] zipString:leftBase64String],
//              @"idcard_img_EndName":[[GlobleData shareInfo] zipString:@"png"],
//              @"idcard_img_back":[[GlobleData shareInfo] zipString:rightBase64String],
//              @"idcard_img_back_EndName":[[GlobleData shareInfo] zipString:@"png"],
//              };
    
    return  @{@"user_id":[userData.userId stringValue],
              };
}

- (NSDictionary*)getOtherParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    
    return  @{
              @"idcard_img":leftBase64String,
              @"idcard_img_back":rightBase64String,
              };

}

- (BOOL)inputIsIlligal
{
    if(![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网路无法连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (leftBase64String.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请上传身份证照片" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (rightBase64String.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请上传身份证照片" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}

- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    // 返回新的改变大小后的图片
    return scaledImage;
}

#pragma mark - UIImage picker

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    ////zzzili14
    UIImage *image= [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    NSData *imgData = UIImageJPEGRepresentation(image, 0.1);
    image = [UIImage imageWithData:imgData];
    image = [self scaleToSize:image size:CGSizeMake(448, 600)];
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    }
    if (!isRightImage)
    {
        leftImage = image;
        _leftImageView.image = image;
        _leftImageView.bounds = (CGRect){
            .origin.x = 0,
            .origin.y = 0,
            .size.width = 64.0f,
            .size.height = 64.0f * image.size.height / image.size.width,
        };
        leftBase64String = [self convertToBase64StringWithImage:leftImage];
    }
    else
    {
        rightImage = image;
        _rightImageView.image = image;
        _rightImageView.bounds = (CGRect){
            .origin.x = 0,
            .origin.y = 0,
            .size.width = 64.0f,
            .size.height = 64.0f * image.size.height / image.size.width,
        };
        rightBase64String = [self convertToBase64StringWithImage:rightImage];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UIActionSheet delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        [self pickImageFromPhotoLibrary];
    }
    else if (buttonIndex == 1)
    {
        [self pickImageFromCamera];
    }
    
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
