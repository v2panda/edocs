//
//  MailCheckTableViewController.m
//  rry
//
//  Created by Ren Guohua on 14-6-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "MailCheckTableViewController.h"
#import "MailCheckInputCell.h"
#import "MailButtonCell.h"
#import "GlobleData.h"
#import "UserData.h"
#import "MBProgressHUD.h"
#import "MailCheckFooterView.h"

@interface MailCheckTableViewController ()

@end

@implementation MailCheckTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self setNavigationBar];
    [self initFooterView];
    [self registerCell];
    [self addTap];
    self.tableView.scrollEnabled = NO;
    
}
/**
 *  初始化数据
 */
- (void)initData
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil || userData.email == nil)
    {
        dataArray = @[@{@"image":@"email.png",@"title":@"邮箱",@"security":@"0", @"mail":@""},
                      @{@"image":@"mima.png",@"title":@"验证码",@"security":@"1", @"mail":@""}
                      ];
    } else {
        dataArray = @[@{@"image":@"email.png",@"title":@"邮箱",@"security":@"0", @"mail":userData.email},
                      @{@"image":@"mima.png",@"title":@"验证码",@"security":@"1", @"mail":@""}
                      ];
    }
    
}

/**
 *  注册UITableViewCell
 */
- (void)registerCell
{
    [self.tableView registerClass:[MailCheckInputCell class] forCellReuseIdentifier:@"inputCell"];
    
    [self.tableView registerClass:[MailButtonCell class] forCellReuseIdentifier:@"buttonCell"];
}

/**
 *  设置导航栏
 */
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"验证邮箱";
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
/**
 *  导航栏左按钮点击事件
 *
 *  @param sender leftButton
 */
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initFooterView
{
    _footerView = [[MailCheckFooterView alloc] initWithFrame:(CGRect){
        
        .origin.x = 0.0f,
        .origin.y = 0.0f,
        .size.width = 320.0f,
        .size.height = 88.0f,
    }];
    
    self.tableView.tableFooterView = _footerView;
    [_footerView configCheckButtonEvent:^{
        [self verifyEmail];
    }];
}
/**
 *  在tableView 上添加单击事件
 */
- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    tap.delegate = self;
    [self.tableView addGestureRecognizer:tap];
}

/**
 *  Tap event
 *
 *  @param recognizer tap
 */
-( void)tap:(UIGestureRecognizer *)recognizer
{
    [_textField resignFirstResponder];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 若为UITableViewCellContentView（即点击了tableViewCell），则不截获Touch事件
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    return  YES;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [dataArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    

    MailCheckInputCell *cell = (MailCheckInputCell*)[tableView dequeueReusableCellWithIdentifier:@"inputCell" forIndexPath:indexPath];
    cell.saveInputString = ^(NSString *cellString){
        
        if (_cellStringDic == nil)
        {
            _cellStringDic = [NSMutableDictionary dictionary];
        }
        _cellStringDic[indexPath] = cellString;
    };
    cell.delegate = self;
    cell.index = indexPath;
    [cell bindData:dataArray[indexPath.row]];
    [cell bindInput:_cellStringDic[indexPath]];
    
    return cell;

   
//    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"buttonCell" forIndexPath:indexPath];
//    return cell;
}


#pragma mark - Table view delegat


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (indexPath.section == 1 && indexPath.row == 0)
//    {
//        [tableView deselectRowAtIndexPath:indexPath animated:YES];
//        [self verifyEmail];
//    }

}

- (void)verifyEmail
{
    if ([self inputIsIlligal])
    {
        return;
    }
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:hud];
	
	hud.detailsLabelText = @"正在验证邮箱...";
    hud.square = YES;
    [hud show:YES];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager POST:@"checkEmail" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    
    [sessionManager POST:@"api/member/EmailVerify" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        [hud hide:YES];
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSLog(@"aaa:%@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
       
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"邮箱验证成功" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                alert.tag = 1;
                [alert show];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        [hud hide:YES];
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];

}

- (NSDictionary*)getParameters
{
    NSString *emailString = _cellStringDic[[NSIndexPath indexPathForRow:0 inSection:0]];
    
    if (emailString == nil || emailString.length <= 0)
    {
        return nil;
    }
    
    NSString *veriedCodeString = _cellStringDic[[NSIndexPath indexPathForRow:1 inSection:0]];
    if (veriedCodeString == nil || veriedCodeString.length <= 0)
    {
        return nil;
    }
    
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    //[[GlobleData shareInfo] zipString:emailString]
//    return @{
//             @"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//             @"email":emailString,
//             @"valiCode":[[GlobleData shareInfo] zipString:veriedCodeString]
//             };
    return @{
             @"user_id":[userData.userId stringValue],
             @"email":emailString,
             @"valid_code":veriedCodeString
             };
}


- (BOOL)inputIsIlligal
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    NSString *emailString = _cellStringDic[[NSIndexPath indexPathForRow:0 inSection:0]];
    if (emailString == nil || emailString.length <= 0 || [emailString rangeOfString:@"@"].location==NSNotFound)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入正确的邮箱地址" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    NSString *veriedCodeString = _cellStringDic[[NSIndexPath indexPathForRow:1 inSection:0]];
    if (veriedCodeString == nil || veriedCodeString.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入正确的验证码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    return NO;
}

#pragma mark - UIAlert delegate
//根据被点击按钮的索引处理点击事件
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1)
    {
        if (buttonIndex == 0)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}
//411121199002054091
//13526667893
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
