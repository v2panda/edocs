//
//  ShowBankCardViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "ShowBankCardViewController.h"
#import "BindCell.h"
#import "ArrayDataSource.h"
#import "UserData.h"
#import "GlobleData.h"
#import "BankCard.h"

@interface ShowBankCardViewController ()

@end

@implementation ShowBankCardViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self setMyView];
    [self setNavigationBar];
    [self initTableView];
    
}

/**
 *  初始化数据
 */
- (void)initData
{
    NSString *bankName;
    NSString *cardNum;
    if (_bankCard.bankName.length <= 0)
    {
        bankName = @"暂无银行名称";
    }
    else
    {
        bankName = _bankCard.bankName;
    }
    
    if (_bankCard.cardNumber.length>10)
    {
        NSString *star = @"";
        for (int i=0; i<_bankCard.cardNumber.length-10; i++) {
            star = [star stringByAppendingString:@"*"];
        }
        
        NSString *str=[NSString stringWithFormat:@"%@%@%@",[_bankCard.cardNumber substringToIndex:6], star,[_bankCard.cardNumber substringWithRange:NSMakeRange(_bankCard.cardNumber.length-4, 4)]];
        cardNum = str;
    }else
    {
        cardNum = _bankCard.cardNumber;
        
    }
    
    dataArray = @[@{@"image":@"no_yinhangka.png",@"title":bankName,@"detail":cardNum}];
}

- (void)setMyView
{
    self.view.backgroundColor = UIColorFromRGB(0xffffff);
    
}

/**
 *  初始化导航栏
 */
- (void)setNavigationBar
{
    // [self.navigationItem setHidesBackButton:YES];
    
    self.navigationItem.title = @"银行卡";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
}
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  初始化TableView
 */
- (void)initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height) style:UITableViewStyleGrouped];
    _tableView.backgroundView = nil;
    _tableView.backgroundColor = UIColorFromRGB(0xf7f7f7);
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
    [_tableView registerClass:[BindCell class] forCellReuseIdentifier:@"Cell"];
    
    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:nil otherIdentifier:@"Cell" configureCellBlock:^(id cell, id data){
        
        [cell bindData:data];
    }];
    
    self.tableView.dataSource = dataSource;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}


#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 77.0f;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


@end
