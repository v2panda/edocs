//
//  RegViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface RegViewController : UIViewController<UITextFieldDelegate,MBProgressHUDDelegate>

@property (nonatomic, strong) UITextField *userNameTextField;
@property (nonatomic, strong) UIButton *nextButton;
@property (nonatomic, strong) UIButton *agreeButton;
@property (nonatomic, strong) UIButton *agreementShowButton;

@property (nonatomic, strong) MBProgressHUD *hud;

@end
