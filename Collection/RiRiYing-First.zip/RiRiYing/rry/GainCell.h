//
//  GainCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GainCell : UICollectionViewCell

@property (nonatomic, strong) UILabel *leftTopNameLabel;
@property (nonatomic, strong) UILabel *leftTopDataLabel;

@property (nonatomic, strong) UILabel *rightTopNameLabel;
@property (nonatomic, strong) UILabel *rightTopDataLabel;;

@property (nonatomic, strong) UILabel *leftBottomNameLabel;
@property (nonatomic, strong) UILabel *leftBottomDataLabel;;

@property (nonatomic, strong) UILabel *rightBottomNameLabel;
@property (nonatomic, strong) UILabel *rightBottomDataLabel;

@property (nonatomic, strong) id delegate;

- (void)bindData:(id)data;
@end
