 //
//  MainViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "MainViewController.h"
#import "UserCenterViewController.h"
#import "RedeemTableViewController.h"
#import "BankCardBindViewController.h"
#import "TopCell.h"
#import "AccountCell.h"
#import "GainCell.h"
#import "PlotCell.h"
#import "GlobleData.h"
#import "UserData.h"
#import "BankCard.h"
#import "MainData.h"
#import "LoginViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyview];
    [self setNavigationBar];
    [self initCollectionView];
    [self initLeftBottomButton];
    [self initRightBottomButton];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self getCardNumberFromNetwork];
    [self initData];
}

- (void)initData
{
    [self getDataFromNetwork];
    [self getMainDataFromNetwork];
}

/**
 *  从网络获取七日年化数据
 */
- (void)getDataFromNetwork
{
//    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager GET:@"GetYearRateList" parameters:nil success:^(AFHTTPRequestOperation *task, id responseObject){
    NSLog(@"aaa:%@", [GlobleData shareInfo].key);
    
    [sessionManager POST:@"api/common/getYearRateList" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:nil path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];

        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                plotDataArray = dic[@"data"];
                [_collectionView reloadData];
            }
            else
            {
                
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        NSLog(@"%@", task.request.URL);
    }];

}

/**
 *  获取银行卡信息
 */
- (void)getCardNumberFromNetwork
{
//    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    [sessionManager GET:@"GetCardNumber" parameters:[self getCardNumParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/member/getBankInfo" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getCardNumParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo]getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                NSDictionary *dataDic = dic[@"data"];
                _bankCard = [[BankCard alloc]initWithDictionary:[NSMutableDictionary dictionaryWithDictionary:dataDic]];
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        NSLog(@"%@", task.request.URL);
    }];
}


- (NSDictionary*)getCardNumParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
//    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
    
    return  @{@"user_id":[userData.userId stringValue]
              };
}

/**
 *  获取收益数据
 */
- (void)getMainDataFromNetwork
{
//    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager GET:@"GetMainData" parameters:[self getCardNumParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/member/amounts" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getCardNumParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];

        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                mainData = [[MainData alloc] initWithDictionary:[NSMutableDictionary  dictionaryWithDictionary:dic[@"data"]]];
                [_collectionView reloadData];
            }
            else
            {
                
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        
    }];
}



- (void)setMyview
{
    self.view.backgroundColor = UIColorFromRGB(0xffffff);
    
}





- (void)setNavigationBar
{
    [self.navigationItem setHidesBackButton:YES];
    self.navigationItem.title = @"日日盈";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    [rightButton setBackgroundImage:[UIImage imageNamed:@"bar_yhzx.png"] forState:UIControlStateNormal];
    [rightButton setBackgroundImage:[UIImage imageNamed:@"bar_yhzx_hl.png"] forState:UIControlStateHighlighted];
    
    [rightButton addTarget:self action:@selector(rightButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    
    self.navigationItem.rightBarButtonItem = rightButtonItem;


}

- (void)rightButtonClicked:(id)sender
{
    UserCenterViewController *userCenterVC = [[UserCenterViewController alloc] init];
    [self.navigationController pushViewController:userCenterVC animated:YES];
    
}

- (void)initLeftBottomButton
{
    _leftBottomButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _leftBottomButton.frame =  (CGRect){
        
        .origin.x = 0.0f,
        .origin.y = self.view.frame.size.height - 64.0f -44.0f,
        .size.width = self.view.frame.size.width / 2,
        .size.height = 44.0f,
    };
    
    [_leftBottomButton setTitle:@"赎回" forState:UIControlStateNormal];
    _leftBottomButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    [_leftBottomButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_leftBottomButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
    [_leftBottomButton setBackgroundImage:[UIImage imageNamed:@"home_bar_bj"] forState:UIControlStateNormal];
    [_leftBottomButton setBackgroundImage:[UIImage imageNamed:@"home_bar_bj"] forState:UIControlStateHighlighted];
    _leftBottomButton.tintColor = [UIColor redColor];
    _leftBottomButton .backgroundColor = [UIColor whiteColor];
    [_leftBottomButton addTarget:self action:@selector(leftBottomButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_leftBottomButton];
}

- (void)leftBottomButtonClicked:(id)sender
{

    if (_bankCard == nil /*|| _bankCard.bankName == nil*/ || _bankCard.cardNumber == nil /*|| [_bankCard.bankName length] == 0*/ || [_bankCard.cardNumber length] == 0 || [_bankCard.sta intValue] == 0 || [_bankCard.sta intValue] == -1)

    {
        BankCardBindViewController *bankCardBindVC = [[BankCardBindViewController alloc] init];
        [self.navigationController pushViewController:bankCardBindVC animated:YES];
    }
    else
    {
        RedeemTableViewController *redeemVC = [[RedeemTableViewController alloc] init];
        [self.navigationController pushViewController:redeemVC animated:YES];
    }

}

- (void)initRightBottomButton
{
    _rightBottomButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightBottomButton.frame =  (CGRect){
        
        .origin.x = self.view.frame.size.width / 2,
        .origin.y = self.view.frame.size.height - 64.0f -44.0f,
        .size.width = self.view.frame.size.width / 2,
        .size.height = 44.0f,
    };
    _rightBottomButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    [_rightBottomButton setTitle:@"购买" forState:UIControlStateNormal];
    
    [_rightBottomButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_rightBottomButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
    [_rightBottomButton setBackgroundImage:[UIImage imageNamed:@"home_bar_bj"] forState:UIControlStateNormal];
    [_rightBottomButton setBackgroundImage:[UIImage imageNamed:@"home_bar_bj"] forState:UIControlStateHighlighted];
    _rightBottomButton.tintColor = [UIColor redColor];
    _rightBottomButton.backgroundColor = [UIColor whiteColor];
    [_rightBottomButton addTarget:self action:@selector(rightBottomButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_rightBottomButton];
}
- (void)rightBottomButtonClicked:(id)sender
{
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"目前暂不支持移动端购买" message:@"请登录电脑站(y.cybp2c.com)进行操作" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
    alert.alertViewStyle=UIAlertViewStyleDefault;
    [alert show];
}

/**
 *  初始化CollectionView
 */

- (void)initCollectionView
{
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    CGRect frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height - 64.0f);
    _collectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
    _collectionView.backgroundColor = [UIColor clearColor];
    if(IOS7)
    {
       self.automaticallyAdjustsScrollViewInsets = NO;
    }
    _collectionView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 44.0f, 0.0f);
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    _collectionView.showsVerticalScrollIndicator = NO;
    
    [_collectionView registerClass:[TopCell class] forCellWithReuseIdentifier:@"TopCell"];
    [_collectionView registerClass:[AccountCell class] forCellWithReuseIdentifier:@"AccountCell"];
    [_collectionView registerClass:[GainCell class] forCellWithReuseIdentifier:@"GainCell"];
    [_collectionView registerClass:[PlotCell class] forCellWithReuseIdentifier:@"PlotCell"];
    [self.view addSubview:_collectionView];
    
}

#pragma  - mark UICollection DataSource


-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 4;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{

    return UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f);
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        TopCell *cell = (TopCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"TopCell" forIndexPath:indexPath];
        
        [cell bindData:mainData];
        return cell;
    }
    if (indexPath.row == 1)
    {
        AccountCell *cell = (AccountCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"AccountCell" forIndexPath:indexPath];
        
        [cell bindData:mainData];
        return cell;
    }
    if (indexPath.row == 2)
    {
        GainCell *cell = (GainCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"GainCell" forIndexPath:indexPath];
        cell.delegate = self;
        [cell bindData:mainData];
        return cell;
    }

        PlotCell *cell = (PlotCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"PlotCell" forIndexPath:indexPath];
        
        [cell bindData:plotDataArray];
        return cell;
    
}


#pragma mark  UICollection Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    

    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        return CGSizeMake(320.0f, 144.0f);
    }
    if (indexPath.row == 1)
    {
        return CGSizeMake(320.0f, 124.0f);
    }
    if (indexPath.row == 2)
    {
        return CGSizeMake(320.0f, 158.0f);
    }
    if (indexPath.row == 3)
    {
         return CGSizeMake(320.0f, 226.0f);
    }
    return CGSizeMake(320.0f, 56.0f);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0.0f;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    
    return 0.0f;
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
