//
//  LoginViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-13.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController<UITextFieldDelegate>

@property (nonatomic, strong) UIImageView *logoView;
@property (nonatomic, strong) UITextField *userNameTextField;
@property (nonatomic, strong) UITextField *pwdTextField;
@property (nonatomic, strong) UIButton *loginButton;
@property (nonatomic, strong) UIButton *forgetPwdButton;
@property (nonatomic, strong) UILabel *versionLabel;
@property (nonatomic, assign) BOOL isHomePage;
@property (nonatomic, strong) id delegate;

@end
