//
//  UploadViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-26.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UploadViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>
{
    BOOL isRightImage;
    UIImage *leftImage;
    UIImage *rightImage;
    NSString *leftBase64String;
    NSString *rightBase64String;
}

@property (nonatomic, strong) UILabel *topLabel;
@property (nonatomic, strong) UIImageView *leftImageView;
@property (nonatomic, strong) UIImageView *rightImageView;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UIAlertView *loadingAlert;

@property (nonatomic, strong) UIButton *finishButton;

@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *phoneNumber;
@property (nonatomic, strong) NSString *realName;
@property (nonatomic, strong) NSString *loginPwd;
@property (nonatomic, strong) NSString *getCashPwd;


@end
