//
//  ResetPwdViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-26.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "ResetPwdViewController.h"
#import "GlobleData.h"

@interface ResetPwdViewController ()

@end

@implementation ResetPwdViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
    [self initidCardTextField];
    [self initPhoneTextField];
    [self initVerifiedCodeFiled];
    [self initNewPasswordFiled];
    [self addTap];
}
/**
 *  viewController's view
 */
- (void)setMyView
{
    self.view.backgroundColor = [UIColor whiteColor];
}
/**
 *  navigationBar
 */
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"重置密码";
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setFrame:CGRectMake(0.0f, 0.0f, 50.0f, 30.0f)];
    [rightButton setTitle:@"提交" forState:UIControlStateNormal];
    rightButton.tintColor = [UIColor whiteColor];
    rightButton.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    rightButton.titleLabel.textAlignment = NSTextAlignmentRight;
    [rightButton addTarget:self action:@selector(rightButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    
    self.navigationItem.rightBarButtonItem = rightButtonItem;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back_hl.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
/**
 *  导航栏做左按钮点击事件
 *
 *  @param sender 按钮
 */
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  导航栏右按钮点击事件
 *
 *  @param sender 按钮
 */
- (void)rightButtonClicked:(id)sender
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
    
    if (![self inputIsIlligal])
    {
        [self resetPassword];
    }
}

/**
 *  重置密码
 */
- (void)resetPassword
{
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *parameters = [self getParameters];

//    [sessionManager POST:@"updatePwd" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/login/UpdatePwd"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:parameters path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
    
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
    
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"修改成功" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                alert.tag = 111;
                [alert show];
            }
            else if([dic[@"sta"] isEqualToNumber:@0])
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }

        }
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
    
}

/**
 *  获取网络接口参数
 *
 *  @return 网络接口参数
 */
- (NSDictionary*)getParameters
{
    if (_phoneTextField.text.length != 11 || _verifiedCodeField.text.length <= 0 || _currentPasswordField.text.length < 6)
    {
        return nil;
    }
//    return @{@"mobile":[[GlobleData shareInfo] zipString:_phoneTextField.text],
//             @"valiCode":[[GlobleData shareInfo] zipString:_verifiedCodeField.text],
//             @"app_login_pwd":[[GlobleData shareInfo] zipString:_currentPasswordField.text],
//             @"idcard":[[GlobleData shareInfo] zipString:_idCardTextField.text]
//             };
    
    return @{@"value":_phoneTextField.text,@"account":_idCardTextField.text, @"value_type":@"mobile", @"valid_code": _verifiedCodeField.text, @"pwd": _currentPasswordField.text};
    
}

/**
 *  身份证号码输入框
 */
- (void)initidCardTextField
{
    
    _idCardTextField = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, 0.0f, self.view.frame.size.width - 20.0f, 48.0f)];
    _idCardTextField.textColor = UIColorFromRGB(0x4a4a4a);
    _idCardTextField.placeholder = @"身份证号";
    _idCardTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _idCardTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_idCardTextField];
    
    UIImageView *lineView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 48.0f, self.view.frame.size.width, 1.0f)];
    lineView.image = [UIImage imageNamed:@"line.png"];
    [self.view addSubview:lineView];
}

/**
 *  手机号码输入框
 */
- (void)initPhoneTextField
{
 
    _phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, CGRectGetMaxY(_idCardTextField.frame) + 1, self.view.frame.size.width - 20.0f, 48.0f)];
    _phoneTextField.textColor = UIColorFromRGB(0x4a4a4a);
    _phoneTextField.placeholder = @"手机号码";
    _phoneTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _phoneTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_phoneTextField];
    
    _phoneLineView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_phoneTextField.frame), self.view.frame.size.width, 1.0f)];
    _phoneLineView.image = [UIImage imageNamed:@"line.png"];
    _phoneTextField.keyboardType = UIKeyboardTypeNumberPad;
    [self.view addSubview:_phoneLineView];
}

/**
 *  验证码
 */
- (void)initVerifiedCodeFiled
{
    _verifiedCodeField = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, CGRectGetMaxY(_phoneTextField.frame) + 1, self.view.frame.size.width - 20.0f, 48.0f)];
    _verifiedCodeField.textColor = UIColorFromRGB(0x4a4a4a);
    _verifiedCodeField.placeholder = @"验证码";
    _verifiedCodeField.delegate = self;
    _verifiedCodeField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _verifiedCodeField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_verifiedCodeField];
    
    _getVerifiedCodeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _getVerifiedCodeButton.frame = CGRectMake(0.0f, 0.0f, 100.0f, 48.0f);
    [_getVerifiedCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [_getVerifiedCodeButton setTintColor:UIColorFromRGB(0x2fb610)];
    [_getVerifiedCodeButton setTitleColor:UIColorFromRGB(0x2fb610) forState:UIControlStateNormal];
    _getVerifiedCodeButton.titleLabel.font = [UIFont systemFontOfSize:14];
    
    [_getVerifiedCodeButton addTarget:self action:@selector(getVerifiedCode:) forControlEvents:UIControlEventTouchUpInside];
    _verifiedCodeField.rightView = _getVerifiedCodeButton;
    _verifiedCodeField.rightViewMode = UITextFieldViewModeAlways;
    
    
    _verifiedCodeLineView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_verifiedCodeField.frame), self.view.frame.size.width, 1.0f)];
    _verifiedCodeLineView.image = [UIImage imageNamed:@"line.png"];
    [self.view addSubview:_verifiedCodeLineView];
}

/**
 *  获取验证码
 *
 *  @param sender 按钮
 */
- (void)getVerifiedCode:(id)sender
{
    if(![GlobleData isPureInt:_phoneTextField.text]||_phoneTextField.text.length!=11)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"错误" message:@"手机号格式不正确" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alert show];
        return;
    }

    if ([self inputIsIlligalForVerifiedCode])
    {
        return;
    }
    
    NSDictionary *dic = [self getVerifiedParameters];
    
    UIButton *button = (UIButton *)sender;
    button.userInteractionEnabled = NO;
    
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }

    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
 
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager POST:@"ValiCode" parameters:[self getVerifiedParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    [sessionManager POST:@"api/login/GetVerifyCode"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:dic path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@",dic);
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                _verifiedCode = dic[@"sta"];
                
                verifiedTime = 180;
                if (_verifiedRightLabel == nil)
                {
                    _verifiedRightLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 100.0f, 48.0f)];
                }
                _verifiedRightLabel.text = [NSString stringWithFormat:@"%ld秒",(long)verifiedTime];
                _verifiedRightLabel.textColor = [UIColor redColor];
                _verifiedRightLabel.textAlignment = NSTextAlignmentCenter;
                _verifiedCodeField.rightView = _verifiedRightLabel;
                verifyTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(handleTimer:) userInfo:nil repeats:YES];
            }
            else
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:dic[@"msg"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alert show];
            }
        }
        
        button.userInteractionEnabled = YES;
    
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        button.userInteractionEnabled = YES;
        
    }];
    
    
}

/**
 *  获取验证码网络接口参数
 *
 *  @return 网络接口参数
 */
- (NSDictionary*)getVerifiedParameters
{
    if (_phoneTextField.text.length != 11)
    {
        return nil;
    }
//    return @{@"mobile":[[GlobleData shareInfo] zipString:_phoneTextField.text],@"idcard":[[GlobleData shareInfo] zipString:_idCardTextField.text]};
    return @{@"value":_phoneTextField.text,@"account":_idCardTextField.text, @"value_type":@"mobile"};
}

/**
 *  定时器事件
 *
 *  @param timer 定时器
 */
- (void)handleTimer:(NSTimer*)timer
{
    
    verifiedTime --;
    if (verifiedTime == 0)
    {
        _verifiedCodeField.rightView = _getVerifiedCodeButton;
        [verifyTimer invalidate];
    }
    else
    {
        _verifiedRightLabel.text = [NSString stringWithFormat:@"%ld秒",(long)verifiedTime];
    }
}

/**
 *  密码输入框
 */
- (void)initNewPasswordFiled
{
    _currentPasswordField = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, CGRectGetMaxY(_verifiedCodeField.frame) + 1, self.view.frame.size.width - 20.0f, 48.0f)];
    _currentPasswordField.textColor = UIColorFromRGB(0x4a4a4a);
    _currentPasswordField.placeholder = @"新密码";
    _currentPasswordField.delegate = self;
    _currentPasswordField.secureTextEntry = YES;
    _currentPasswordField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _currentPasswordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_currentPasswordField];
    
    _currentPasswordLineView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_currentPasswordField.frame), self.view.frame.size.width, 1.0f)];
    _currentPasswordLineView.image = [UIImage imageNamed:@"line.png"];
    [self.view addSubview:_currentPasswordLineView];
    
    ///确认新密码
    _rePasswordField = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, CGRectGetMaxY(_currentPasswordField.frame) + 1, self.view.frame.size.width - 20.0f, 48.0f)];
    _rePasswordField.textColor = UIColorFromRGB(0x4a4a4a);
    _rePasswordField.placeholder = @"确认新密码";
    _rePasswordField.delegate = self;
    _rePasswordField.secureTextEntry = YES;
    _rePasswordField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _rePasswordField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_rePasswordField];
    
    _currentPasswordLineView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_rePasswordField.frame), self.view.frame.size.width, 1.0f)];
    _currentPasswordLineView.image = [UIImage imageNamed:@"line.png"];
    [self.view addSubview:_currentPasswordLineView];
}

#pragma mark Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.frame.origin.y+textField.frame.size.height > self.view.frame.size.height-216.0f-22.0f)
    {
        
        CGFloat offY = (self.view.frame.size.height-216.0f)-textField.frame.size.height-textField.frame.origin.y-22.0f;//屏幕总高度-键盘高度-UITextField高度
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        self.view.frame = CGRectMake(self.view.frame.origin.x, offY-44.0f, self.view.frame.size.width, self.view.frame.size.height);//UITextField位置的y坐标移动到offY
        [UIView commitAnimations];//开始动画效果
    }
    else
    {
        [self recoverFrame];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{

}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        [self recoverFrame];
        return NO;
    }
    
    if (textField == _idCardTextField)
    {
        if (range.location > 17)
        {
            return NO;
        }
    }
    return YES;
}

/**
 *  判断输入是否合法
 *
 *  @return Yes 不合法 NO 合法
 */
- (BOOL)inputIsIlligalForVerifiedCode
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (_phoneTextField.text.length != 11)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"手机号码不正确" message:@"请输入正确的绑定手机号接收验证码" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


/**
 *  判断输入是否合法
 *
 *  @return Yes 不合法 NO 合法
 */
- (BOOL)inputIsIlligal
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(![[GlobleData shareInfo] idNumberIsvalidWithString:_idCardTextField.text])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"身份证号码不合法" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (_phoneTextField.text.length < 11)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入正确手机号码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    if (_verifiedCodeField.text.length <= 0 /*||![_verifiedCodeField.text isEqualToString:_verifiedCode]*/)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"验证码输入错误" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }

    if (_currentPasswordField.text.length < 6)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入至少6位新密码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    if([_currentPasswordField.text isEqualToString:_rePasswordField.text]==NO)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"两次密码不一致" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


-(void)recoverFrame
{
    [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
    [UIView setAnimationDuration:0.3];
    //UITextField位置复原
    self.view.frame = CGRectMake(0.0f, 64.0f, self.view.frame.size.width, self.view.frame.size.height);
    [UIView commitAnimations];
}

/**
 *  添加自身view 的点击事件
 */
- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.view addGestureRecognizer:tap];
}

/**
 *  点击事件
 *
 *  @param recognizer 点击手势
 */
-( void)tap:(UIGestureRecognizer *)recognizer
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
}

/**
 *  键盘消失
 */
- (void)makeKeyBoardMiss
{
    for (id textField in [self.view subviews])
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            UITextField *theTextField = (UITextField*)textField;
            [theTextField resignFirstResponder];
        }
    }
}

#pragma UIAlert delegate
//根据被点击按钮的索引处理点击事件
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (alertView.tag == 111)
    {
        if (buttonIndex == 0)
        {
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}



@end
