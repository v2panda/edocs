//
//  RedeemTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RedeemTableViewController : UITableViewController

{
    NSArray *dataArray;
    NSDictionary *dataDic;
}

@property (nonatomic, strong) UIButton *finishButton;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UILabel *leftBottomLabel;
@property (nonatomic, strong) UIButton *rightBottomButton;

@property (nonatomic, strong) NSMutableDictionary *cellStringDic;


@end
