//
//  BankCardBindViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "BankCardBindViewController.h"
#import "BindCell.h"
#import "ArrayDataSource.h"
#import "AddBankCardViewController.h"


@interface BankCardBindViewController ()

@end

@implementation BankCardBindViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self setMyView];
    [self setNavigationBar];
    [self initTableView];
    [self initLabel];
}
/**
 *  初始化tableView中初始数据
 */
- (void)initData
{
    dataArray = @[@{@"image":@"no_yinhangka.png",@"title":@"绑定银行卡",@"detail":@"用于接收赎回(提现)的资金"}];
}

- (void)setMyView
{
    self.view.backgroundColor = UIColorFromRGB(0xffffff);
}
/**
 *  初始化导航栏
 */
- (void)setNavigationBar
{
   // [self.navigationItem setHidesBackButton:YES];
    
    self.navigationItem.title = @"绑定银行卡";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
}

/**
 *  导航栏左按钮点击事件
 *
 *  @param sender
 */
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  初始化TableView
 */
- (void)initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height) style:UITableViewStyleGrouped];
    
    _tableView.backgroundColor = UIColorFromRGB(0xf7f7f7);
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
    [_tableView registerClass:[BindCell class] forCellReuseIdentifier:@"Cell"];

    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:nil otherIdentifier:@"Cell" configureCellBlock:^(id cell, id data){
        
        [cell bindData:data];
    }];
    
    self.tableView.dataSource = dataSource;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}

- (void)initLabel
{
    _label = [[UILabel alloc] initWithFrame:CGRectMake(30.0f, 120.0f, 260.0f, 40.0f)];
    _label.textColor = [UIColor lightGrayColor];
    _label.text = @"需要绑定银行卡才能提交赎回申请";
    _label.backgroundColor = [UIColor clearColor];
    _label.textAlignment = NSTextAlignmentCenter;
    if(IOS7)
    {
        _label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    }
    [_tableView addSubview:_label];
}

#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 77.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddBankCardViewController *addVC = [[AddBankCardViewController alloc] init];
    [self.navigationController pushViewController:addVC animated:YES];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
