//
//  AddAddressViewController.h
//  fanfan
//
//  Created by Ren Guohua on 14-2-27.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddAddressViewController : UIViewController

@property (nonatomic, strong) UIButton *cityButton;
@property (nonatomic, strong) UIButton *areaButton;
@property (nonatomic, strong) UIButton *streetButton;


@property (nonatomic, strong) UIButton *okButton;

@property (nonatomic, strong) NSMutableArray *buttonArray;
@property (nonatomic, strong) NSArray *buttonNameArray;

@property (nonatomic, strong) id delegate;

/**
 *  重置地址按钮的名称
 *
 *  @param tag   按钮的tag
 *  @param title 按钮名称
 */
- (void)resetButtonWithTag:(NSInteger)tag title:(NSString*)title;

@end
