//
//  RegLastStepViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegLastStepViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>
{
    BOOL isRightImage;
    UIImage *leftImage;
    UIImage *rightImage;
    NSString *leftBase64String;
    NSString *rightBase64String;
}

@property (nonatomic, strong) UILabel *topLabel;
@property (nonatomic, strong) UIImageView *leftImageView;
@property (nonatomic, strong) UIImageView *rightImageView;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UIAlertView *loadingAlert;

@property (nonatomic, strong) UIButton *nextButton;
@property (nonatomic, strong) UIButton *skipButton;

@property (nonatomic, strong) NSString *userId;



@end
