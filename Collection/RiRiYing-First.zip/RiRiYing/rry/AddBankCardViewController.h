//
//  AddBankCardViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddBankCardViewController : UIViewController<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *cardNumberTextField;
@property (nonatomic, strong) UIButton *nextButton;


@end
