//
//  ProtocolViewController.m
//  rry
//
//  Created by dld on 14-9-25.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "ProtocolViewController.h"
#import "GlobleData.h"

@interface ProtocolViewController ()

@end

@implementation ProtocolViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setNavigationBar];
    [self initWebView];
    [self initData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (void)initData
{
    [self getDataFromNetwork];
}
/**
 *  从网络回去公告详情
 */
- (void)getDataFromNetwork
{
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    //    [sessionManager GET:@"GetArticle" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    
    
    [sessionManager POST:@"api/global/getProtocol" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:nil path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        //        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSLog(@"aaa:%@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                NSString *webStr = dic[@"data"][@"content"];
                [_webView loadHTMLString:webStr baseURL:nil];
            }
        }
        
        
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
    }];
}

/**
 *  获取http请求参数
 *
 *  @return 返回http请求参数
 */
- (NSDictionary*)getParameters
{
    //    return  @{@"articleId_s":[[GlobleData shareInfo] zipString:[NSString stringWithFormat:@"%@",self.notificationId]]};
    //    return  @{@"id":[NSString stringWithFormat:@"%@",self.notificationId]};
    return nil;
}

- (void)setNavigationBar
{
    
    [self.navigationItem setHidesBackButton:YES];
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    


    
    self.navigationItem.title = @"日日盈用户协议";
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}

- (void)leftButtonClicked:(id)sender
{
//    [self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)initWebView
{
    if (IOS7) {
        _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-64)];
    } else {
        _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-44)];
    }
    [self.view addSubview:_webView];
    [_webView loadHTMLString:self.content baseURL:nil];
}

@end
