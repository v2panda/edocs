// http://www.wuleilei.com/

#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>

#define kChosenCipherBlockSize	kCCBlockSizeAES128
#define kChosenCipherKeySize	kCCKeySizeAES128
#define kChosenDigestLength		CC_SHA1_DIGEST_LENGTH

@interface StringEncryption : NSObject

+ (NSString *)encryptString:(NSString *)plainSourceStringToEncrypt key:(NSString*)_key;
+ (NSString *)decryptString:(NSString *)base64StringToDecrypt key:(NSString*)_key;
+ (NSData *)encrypt:(NSData *)plainText key:(NSString*)_key;
+ (NSData *)decrypt:(NSData *)plainText key:(NSString*)_key;
+ (NSData *)doCipher:(NSData *)plainText context:(CCOperation)encryptOrDecrypt  key:(NSString*)_key;

@end
