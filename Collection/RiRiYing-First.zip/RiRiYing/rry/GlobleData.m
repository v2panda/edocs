//
//  GlobleData.m
//  Renji
//
//  Created by Ren Guohua on 13-10-28.
//  Copyright (c) 2013年 YunFeng. All rights reserved.
//

#import "GlobleData.h"
#import <netinet/in.h>
#import "UserData.h"
#import "LFCGzipUtillity.h"
#import "StringEncryption.h"
#import "NSData+Base64.h"
#import "RSAEncrypt.h"
#import "NSString+XXTEA.h"

@implementation GlobleData

static GlobleData *instance = nil;

+ (GlobleData*)shareInfo{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

-(id)init
{
    if (self = [super init])
    {
        NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"userData"];
        
        if (data == nil)
        {
            self.key = nil;
        }
        

//        data = [StringEncryption decrypt:data key:@"*&232rsalj"];

//        data = [instance getRealDataWithData:data];
        //    data = [[GlobleData shareInfo] decrytWithData:data key:[GlobleData shareInfo].key];
        
        if (data == nil)
        {
            self.key = nil;
        } else {
            NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
            
            dic = dic[@"data"];
            
            if (dic == nil || [dic isEqual:[NSNull null]])
            {
                self.key = nil;
            } else {
                self.key = dic[@"encrypt_key"];
            }
        }
    }
    return self;
}
/**
 *  获取沙盒中该文件的路径
 *
 *  @param fileName 文件名
 *
 *  @return 返回沙盒中该文件的路径
 */
-(NSString*)getPathOfFileName:(NSString *)fileName
{
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *plistPath=[path stringByAppendingPathComponent:fileName];
    
    return plistPath;
}
/**
 *  获取所有沙盒文件的路径
 *
 *  @return 返回沙盒文件路径的数组
 */
- (NSMutableArray*)getAllFilePathOfDocument
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSString *document=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSArray *fileList =[fileManager contentsOfDirectoryAtPath:document error:NULL];
    
    NSMutableArray *filePathArray = [[NSMutableArray alloc] init];
    for (NSString *file in fileList) {
        
        NSString *path =[document stringByAppendingPathComponent:file];
        [filePathArray addObject:path];
    }
    return filePathArray;
}

/**
 *  删除所有沙盒里的文件
 */
- (void)removeAllfilesFromDocument
{
    NSMutableArray *filePathArray = [self getAllFilePathOfDocument];
    NSFileManager* fileManager=[NSFileManager defaultManager];
    
    for (NSString *path in filePathArray)
    {
        [fileManager removeItemAtPath:path error:nil];
    }
    
}
/**
 *  日期转换成字符串
 *
 *  @param date   要转换的日期
 *  @param format 转换的格式
 *
 *  @return 返回转换的字符串
 */
- (NSString*)getStringFromDate:(NSDate*)date withFormatString:(NSString*)format
{
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];//实例化一个NSDateFormatter对象
    
    [dateFormat setDateFormat:format];//设定时间格式,这里可以设置成自己需要的格式
    NSString *currentDateStr = [dateFormat stringFromDate:date];
    return currentDateStr;
}
/**
 *  字符串转换成日期格式
 *
 *  @param dateString 字符串
 *  @param format     转换的格式字符串
 *
 *  @return 返回转换的日期结果
 */
- (NSDate*)getDateFromString:(NSString*)dateString withFormatString:(NSString*)format
{
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];//实例化一个NSDateFormatter对象
    
    [dateFormat setDateFormat:format];//设定时间格式,这里可以设置成自己需要的格式
    NSDate *date = [dateFormat dateFromString:dateString];
    return date;
}


/**
 *  终止所有的本地通知
 */
- (void)shutdownAllLocalNotifications
{
	NSArray *localNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications];
	for(UILocalNotification *notification in localNotifications)
	{
        [[UIApplication sharedApplication] cancelLocalNotification:notification];
	}
}


#pragma mark Network
- (BOOL) connectedToNetwork
{
    // Create zero addy
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    if (!didRetrieveFlags)
    {
        return NO;
    }
    
    BOOL isReachable = flags & kSCNetworkFlagsReachable;
    BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
    return (isReachable && !needsConnection) ? YES : NO;
}

- (BOOL)isLogin
{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"userData"] == nil)
    {
        return NO;
    }
    return YES;
}


- (NSInteger)getWeekdayNumberFromDate:(NSDate*)date
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSDateComponents *weekdayComponents = [calendar components:(NSWeekdayCalendarUnit) fromDate:date];
    
    return [weekdayComponents weekday];
}

- (UserData*)getUserData
{
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"userData"];
    
    if (data == nil)
    {
        return nil;
    }
//    data = [[GlobleData shareInfo] getRealDataWithData:data];
//    data = [[GlobleData shareInfo] decrytWithData:data key:[GlobleData shareInfo].key];
    
    if (data == nil)
    {
        return nil;
    }
    NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    dic = dic[@"data"];
    if (dic == nil || [dic isEqual:[NSNull null]])
    {
        return nil;
    }
//    [GlobleData shareInfo].key = dic[@"data"][@"encrypt_key"];
    
    UserData *userData = [[UserData alloc] initWithDictionary:[NSMutableDictionary dictionaryWithDictionary:dic]];
    return userData;
}

- (NSString*)zipString:(NSString*)string
{
    NSLog(string);
    ///string  转data
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    
    //data zip压缩
   // data = [LFCGzipUtillity gzipData:data];

    
    /////aes 加密
//    data = [StringEncryption encrypt:data key:@"1234567890123456"];
    data = [StringEncryption encrypt:data key:@"*&232rsaldfj"];
    

    //data base64编码
    NSString *base64 = [data base64EncodingWithLineLength:0];
    return [base64 stringByReplacingOccurrencesOfString:@" " withString:@""];
}

- (NSData *)encryData:(NSData *)data
{
    NSData *temp = [StringEncryption encrypt:data key:@"*&232rsalj"];
    return temp;
}

- (NSString*)unZipString:(NSString*)string
{

    NSData *data = [NSData dataWithBase64EncodedString:string];
    
    ///aes解密
    data = [StringEncryption decrypt:data key:@"*&232rsalj"];
    
    //data 解压缩
   // data = [LFCGzipUtillity uncompressZippedData:data];

    
    //data转string
    string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(string);
    return string;

}

- (NSData*)getRealDataWithData:(NSData*)data
{
    NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    string = [[GlobleData shareInfo] unZipString:string];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}



- (BOOL)idNumberIsvalidWithString:(NSString*)string
{
    //判断位数
    NSString *sPaperId = string;
    if ([sPaperId length] < 15 ||[sPaperId length] > 18) {
        
        return NO;
    }
    
    NSString *carid = sPaperId;
   // long lSumQT =0;
    //加权因子
    int R[] ={7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 };
    //校验码
   unsigned char sChecker[]={'1','0','X','x', '9', '8', '7', '6', '5', '4', '3', '2'};
    
    //将15位身份证号转换成18位
    
    NSMutableString *mString = [NSMutableString stringWithString:sPaperId];
    if ([sPaperId length] == 15) {
        
        
        [mString insertString:@"19" atIndex:6];
        
        long p = 0;
        const char *pid = [mString UTF8String];
        for (int i=0; i<=16; i++)
        {
            p += (pid[i]-48) * R[i];
        }
        
        int o = p%11;
        NSString *string_content = [NSString stringWithFormat:@"%c",sChecker[o]];
        [mString insertString:string_content atIndex:[mString length]];
        carid = mString;
        
    }
    
    //判断地区码
    NSString * sProvince = [carid substringToIndex:2];
    
    if (![self areaCode:sProvince]) {
        
        return NO;
    }
    
    //判断年月日是否有效
    
    //年份
    int strYear = [[self getStringWithRange:carid Value1:6 Value2:4] intValue];
    //月份
    int strMonth = [[self getStringWithRange:carid Value1:10 Value2:2] intValue];
    //日
    int strDay = [[self getStringWithRange:carid Value1:12 Value2:2] intValue];
    
    
    NSTimeZone *localZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    [dateFormatter setTimeStyle:NSDateFormatterNoStyle];
    [dateFormatter setTimeZone:localZone];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date=[dateFormatter dateFromString:[NSString stringWithFormat:@"%d-%d-%d 12:01:01",strYear,strMonth,strDay]];
    if (date == nil) {
        
        return NO;
    }
    
    const char *PaperId  = [carid UTF8String];
    
    //检验长度
    if( 18 != strlen(PaperId)) return -1;
    //校验数字
    for (int i=0; i<18; i++)
    {
        if (i < 17)
        {
            if (!isdigit(PaperId[i]))
            {
                return NO;
            }
        }
        else
        {
            if(!('X' == PaperId[i] || 'x' == PaperId[i] ||isdigit(PaperId[i])))
            {
                return NO;
            }
        }
        
    }
    //验证最末的校验码
//    for (int i=0; i<=16; i++)
//    {
//        lSumQT += (PaperId[i]-48) * R[i];
//    }
//    if (sChecker[lSumQT%11] != PaperId[17] )
//    {
//        if (sChecker[lSumQT%11] != 'x' || sChecker[lSumQT%11] != 'X')
//        {
//            return NO;
//        }
//    }
    
    return YES;
    
}

/**
 * 功能:获取指定范围的字符串
 * 参数:字符串的开始小标
 * 参数:字符串的结束下标
 */
- (NSString *)getStringWithRange:(NSString *)str Value1:(NSInteger )value1 Value2:(NSInteger )value2;
{
    return [str substringWithRange:NSMakeRange(value1,value2)];
}

/**
 * 功能:判断是否在地区码内
 * 参数:地区码
 */
- (BOOL)areaCode:(NSString *)code
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"北京" forKey:@"11"];
    [dic setObject:@"天津" forKey:@"12"];
    [dic setObject:@"河北" forKey:@"13"];
    [dic setObject:@"山西" forKey:@"14"];
    [dic setObject:@"内蒙古" forKey:@"15"];
    [dic setObject:@"辽宁" forKey:@"21"];
    [dic setObject:@"吉林" forKey:@"22"];
    [dic setObject:@"黑龙江" forKey:@"23"];
    [dic setObject:@"上海" forKey:@"31"];
    [dic setObject:@"江苏" forKey:@"32"];
    [dic setObject:@"浙江" forKey:@"33"];
    [dic setObject:@"安徽" forKey:@"34"];
    [dic setObject:@"福建" forKey:@"35"];
    [dic setObject:@"江西" forKey:@"36"];
    [dic setObject:@"山东" forKey:@"37"];
    [dic setObject:@"河南" forKey:@"41"];
    [dic setObject:@"湖北" forKey:@"42"];
    [dic setObject:@"湖南" forKey:@"43"];
    [dic setObject:@"广东" forKey:@"44"];
    [dic setObject:@"广西" forKey:@"45"];
    [dic setObject:@"海南" forKey:@"46"];
    [dic setObject:@"重庆" forKey:@"50"];
    [dic setObject:@"四川" forKey:@"51"];
    [dic setObject:@"贵州" forKey:@"52"];
    [dic setObject:@"云南" forKey:@"53"];
    [dic setObject:@"西藏" forKey:@"54"];
    [dic setObject:@"陕西" forKey:@"61"];
    [dic setObject:@"甘肃" forKey:@"62"];
    [dic setObject:@"青海" forKey:@"63"];
    [dic setObject:@"宁夏" forKey:@"64"];
    [dic setObject:@"新疆" forKey:@"65"];
    [dic setObject:@"台湾" forKey:@"71"];
    [dic setObject:@"香港" forKey:@"81"];
    [dic setObject:@"澳门" forKey:@"82"];
    [dic setObject:@"国外" forKey:@"91"];
    
    if ([dic objectForKey:code] == nil) {
        
        return NO;
    }
    return YES;
}


- (void)saveGesture:(NSString*)passcode withUserName:(NSString*)userName
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[userDefaults objectForKey:@"gesturePwd"]];
    if (!dic)
    {
        dic = [NSMutableDictionary dictionary];
    }
    dic[userName] = passcode;
    [userDefaults setObject:dic forKey:@"gesturePwd"];
    [userDefaults synchronize];
}

- (NSString*)getGestureCodeWithUserName:(NSString *)userName
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSMutableDictionary *dic = [userDefaults objectForKey:@"gesturePwd"];
    
    return dic[userName];
}

+ (BOOL)isPureInt:(NSString*)string
{
    NSScanner* scan = [NSScanner scannerWithString:string];
    int val;
    return[scan scanInt:&val] && [scan isAtEnd];
}


- (NSDictionary *)encrytUrlWithParam2:(NSDictionary *)paramDic path:(NSString *)path key:(NSString *)key
{
    NSMutableDictionary *tempDict = [[NSMutableDictionary alloc] init];
    
    if (path) {
        [tempDict setObject:path forKey:@"r"];
    }
    
    
    RSAEncrypt *rsa = [[RSAEncrypt alloc] init];
    
    if (paramDic) {
        NSString *paramString = @"";
        for (NSString *key in paramDic) {
            paramString = [paramString stringByAppendingFormat:@"%@=%@&", key, paramDic[key]];
        }
        paramString = [paramString substringToIndex:paramString.length-1];
        
        [tempDict setObject:[paramString encryptXXTEA:key] forKey:@"param"];
    }
    
    if (key) {
        [tempDict setObject:[rsa encryptToString:key] forKey:@"key"];
    }
    
    
    return tempDict;
}

- (NSDictionary *)encrytUrlWithParam:(NSDictionary *)paramDic path:(NSString *)path key:(NSString *)key otherParamDict:(NSDictionary *)otherParamDict
{
    NSMutableDictionary *tempDict = [[NSMutableDictionary alloc] initWithDictionary:[self encrytUrlWithParam2:paramDic path:path key:key]];
    
    if (otherParamDict) {
        [tempDict addEntriesFromDictionary:otherParamDict];
    }
    return tempDict;
}

-(NSString*)URLencode:(NSString*)originalString stringEncoding:(NSStringEncoding)stringEncoding
{
    NSArray *escapeChars = [NSArray arrayWithObjects:@";", @"/" , @"?" , @":",@"@" , @"&" , @"=" , @"+" ,@"$", @",",@"!", @"'", @"(", @")", @"*", nil];
    NSArray *replaceChars = [NSArray arrayWithObjects:@"%3B" , @"%2F", @"%3F" , @"%3A" , @"%40" , @"%26" , @"%3D" , @"%2B" , @"%24" , @"%2C" ,@"%21", @"%27", @"%28", @"%29", @"%2A", nil];
    int len =[escapeChars count];
    NSMutableString *temp = [originalString mutableCopy];
    int i;
    for(i = 0; i < len; i++)
    {
        [temp replaceOccurrencesOfString:[escapeChars objectAtIndex:i] withString:[replaceChars objectAtIndex:i] options:NSLiteralSearch range:NSMakeRange(0, [temp length])];
    }
    NSString *outStr = [NSString stringWithString:temp];
    return outStr;
}

-(NSString*)URLdecode:(NSString*)originalString stringEncoding:(NSStringEncoding)stringEncoding
{
    NSArray *escapeChars = [NSArray arrayWithObjects:@"%3B" , @"%2F", @"%3F" , @"%3A" , @"%40" , @"%26" , @"%3D" , @"%2B" , @"%24" , @"%2C" ,@"%21", @"%27", @"%28", @"%29", @"%2A", nil];
    NSArray *replaceChars = [NSArray arrayWithObjects:@";", @"/" , @"?" , @":",@"@" , @"&" , @"=" , @"+" ,@"$", @",",@"!", @"'", @"(", @")", @"*", nil];
    int len =[escapeChars count];
    NSMutableString *temp = [originalString  mutableCopy];
    int i;
    for(i = 0; i < len; i++)
    {
        [temp replaceOccurrencesOfString:[escapeChars objectAtIndex:i] withString:[replaceChars objectAtIndex:i] options:NSLiteralSearch range:NSMakeRange(0, [temp length])];
    }
    NSString *outStr = [NSString stringWithString:temp];
    return outStr;
}

- (NSURL *)encrytUrlWithParam:(NSDictionary *)paramDic path:(NSString *)path
{
    RSAEncrypt *rsa = [[RSAEncrypt alloc] init];
    
    NSString *paramString = @"";
    for (NSString *key in paramDic) {
        paramString = [paramString stringByAppendingFormat:@"%@=%@&", key, paramDic[key]];
    }
    paramString = [paramString substringToIndex:paramString.length-1];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@/index&param=%@&key=%@", BASEURL2, path, [self URLencode:[paramString encryptXXTEA:@"123456789abcdef"] stringEncoding:NSUTF8StringEncoding], [self URLencode:[rsa encryptToString:@"123456789abcdef"] stringEncoding:NSUTF8StringEncoding]];
    return [NSURL URLWithString:urlStr];
}

- (NSData *)decrytWithData:(NSData *)data key:(NSString *)key
{
    NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"%@", string);
    string = [[self URLdecode:string stringEncoding:NSUTF8StringEncoding] decryptXXTEA:key];
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}

+ (NSString *)createRandomKey
{
    CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
    
    NSString *strUUID = (NSString *)CFBridgingRelease(CFUUIDCreateString (kCFAllocatorDefault,uuidRef));
    return strUUID;
//    return @"123456789abcdef";
}

+ (void)showExceptionAlert
{
    
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"服务器异常！" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
    [alert show];
    
}
@end
