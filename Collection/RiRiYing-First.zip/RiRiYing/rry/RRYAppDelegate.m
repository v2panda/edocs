//
//  RRYAppDelegate.m
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RRYAppDelegate.h"
#import "MainViewController.h"
#import "LoginViewController.h"
#import "GlobleData.h"
#import "UIKit+AFNetworking.h"
#import "GesturePwdViewController.h"
#import "GesturePwdViewAnimation.h"

#import "MobClick.h"
#define UMENG_APPKEY @"543502e6fd98c59b770015fd"


NSString *newVersionPath;

@implementation RRYAppDelegate

/**
 *
 * 程序入口，系统函数
 *
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"zzuserPass"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    UINavigationController *navigationController;
    if ([[GlobleData shareInfo] isLogin])
    {
        MainViewController *mainVC = [[MainViewController alloc] init];
        navigationController = [[UINavigationController alloc] initWithRootViewController:mainVC];
    }
    else
    {
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        loginVC.isHomePage = YES;
        navigationController = [[UINavigationController alloc] initWithRootViewController:loginVC];
    }
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    self.window.rootViewController = navigationController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    if ([[GlobleData shareInfo] isLogin])
    {
        GesturePwdViewController *gestureVC = [[GesturePwdViewController alloc] init];
        if ([self.window.rootViewController isKindOfClass:[UINavigationController class]])
        {
            UINavigationController *nav = (UINavigationController*)self.window.rootViewController;
            if(IOS7)
            {
                gestureVC.transitioningDelegate = gestureVC;
            }
        
            gestureVC.parentController = nav.topViewController;
            if (![nav.visibleViewController isKindOfClass:[GesturePwdViewController class]])
            {
                [nav.visibleViewController presentViewController:gestureVC animated:NO completion:nil];
            }
            
        }
    }
    [self OpenUMeng];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginTimeOut) name:@"LoginTimeOut" object:nil];
    
    return YES;
}

- (void)loginTimeOut
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"登录超时，请重新登录！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    alert.tag = 2;
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 2) {
        LoginViewController *loginVC = [[LoginViewController alloc] init];
        loginVC.isHomePage = YES;
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginVC];
        self.window.rootViewController = navigationController;
    }
}

-(void)OpenUMeng //打开友盟
{
    [MobClick setAppVersion:XcodeAppVersion]; //参数为NSString * 类型,自定义app版本信
    [MobClick startWithAppkey:UMENG_APPKEY reportPolicy:(ReportPolicy) REALTIME channelId:nil];
//    [MobClick checkUpdateWithDelegate:self selector:@selector(updateMethod:)];
//    [MobClick checkUpdate];
    
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    if (![[GlobleData shareInfo] isLogin])
    {
        return;
    }
    GesturePwdViewController *gestureVC = [[GesturePwdViewController alloc] init];
    if ([self.window.rootViewController isKindOfClass:[UINavigationController class]])
    {
        UINavigationController *nav = (UINavigationController*)self.window.rootViewController;
        if(IOS7)
        {
            gestureVC.transitioningDelegate = gestureVC;
        }
        if ([nav.visibleViewController isKindOfClass:[GesturePwdViewController class]])
        {
            return;
        }
        gestureVC.parentController = nav.topViewController;
        [nav.visibleViewController presentViewController:gestureVC animated:NO completion:nil];
    }
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"zzuserPass"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}



@end
