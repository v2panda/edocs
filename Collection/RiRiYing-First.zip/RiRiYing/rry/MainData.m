//
//  MainData.m
//  rry
//
//  Created by Ren Guohua on 14-5-23.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "MainData.h"

@implementation MainData

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    // subclass implementation should set the correct key value mappings for custom keys
    if ([key isEqualToString:@"amount"])
    {
        self.totalAmount = value;
    }
    else if ([key isEqualToString:@"yesterday"])
    {
        self.yerIncom = value;
    }
    else if ([key isEqualToString:@"bank_address"])
    {
        self.manCount = value;
    }
    else if ([key isEqualToString:@"million"])
    {
        self.wanIncom = value;
    }
    else if ([key isEqualToString:@"all_income"])
    {
        self.totalIncom = value;
    }
    else if ([key isEqualToString:@"week"])
    {
        self.weekIncom = value;
    }
    else if ([key isEqualToString:@"month"])
    {
        self.monthIncom = value;
    }
    else
    {
        [super setValue:value forUndefinedKey:key];
    }
}


@end

