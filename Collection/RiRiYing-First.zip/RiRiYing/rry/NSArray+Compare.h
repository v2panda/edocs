//
//  NSArray+Compare.h
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Compare)
/**
 *  获取数组中最大的元素
 *
 *  @return 返回最大元素
 */
- (NSNumber*)getMaxItem;
/**
 *  获取数组中最小的元素
 *
 *  @return 返回最小的元素
 */
- (NSNumber*)getMinItem;

@end
