//
//  RegViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RegViewController.h"
#import "RegAdditionViewController.h"
#import "RegLastStepViewController.h"
#import "GlobleData.h"
#import "WebViewController.h"
#import "ProtocolViewController.h"

@interface RegViewController ()

@end

@implementation RegViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyview];
    [self setNavigationBar];
    [self initUserNameTextField];
    [self initNextButton];
    [self initAgreementShowButton];
    [self initAgreeButton];
    [self addTap];
}


- (void)setMyview
{
    self.view.backgroundColor = UIColorFromRGB(0xf7f7f7);
}
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"注册";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
}
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initUserNameTextField
{
    _userNameTextField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 15.0f, 320.0f, 44.0f)];
    UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image = [UIImage imageNamed:@"pic_sfz.png"];
    if(IOS7)
    {
        leftView.image = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        leftView.tintColor = UIColorFromRGB(0x909090);
    }
    _userNameTextField.leftView = leftView;
    _userNameTextField.leftViewMode = UITextFieldViewModeAlways;
    _userNameTextField.borderStyle = UITextBorderStyleRoundedRect;
    _userNameTextField.delegate = self;
    _userNameTextField.placeholder = @"请输入身份证号码";
    _userNameTextField.keyboardType = UIKeyboardTypeAlphabet;
    _userNameTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _userNameTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
//    _userNameTextField.text = @"33071919610920021X";
    [self.view addSubview:_userNameTextField];
    
    
    UILabel *rightView = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 100.0f, 32.0f)];
    rightView.font = [UIFont systemFontOfSize:11.0f];
    rightView.textColor = UIColorFromRGB(0xb3b3b3);
    rightView.text = @"(将用作登录账号)";
   
    _userNameTextField.rightView = rightView;
    _userNameTextField.rightViewMode = UITextFieldViewModeUnlessEditing;
}

- (void)initAgreeButton
{
    _agreeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _agreeButton.frame = (CGRect){10.0f, CGRectGetMaxY(_userNameTextField.frame) + 12.0f, 32.0f,32.0f} ;
    
    [_agreeButton setBackgroundImage:[UIImage imageNamed:@"weixuan.png"] forState:UIControlStateNormal];
    [_agreeButton setBackgroundImage:[UIImage imageNamed:@"yixuan.png"] forState:UIControlStateHighlighted];
    [_agreeButton setBackgroundImage:[UIImage imageNamed:@"yixuan.png"] forState:UIControlStateSelected];
    [_agreeButton setBackgroundImage:[UIImage imageNamed:@"yixuan.png"] forState:UIControlStateHighlighted|UIControlStateSelected];
    
    [_agreeButton addTarget:self action:@selector(agreeButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view addSubview:_agreeButton];
}

- (void)agreeButtonClicked:(id)sender
{
    if (!_agreeButton.selected)
    {
        _agreeButton.selected = YES;
        if (_userNameTextField.text.length > 14)
        {
            [self setNextButtonEnable];
        }
    }
    else
    {
        _agreeButton.selected = NO;
        
        [self setNextButtonUnable];
    }
}

- (void)initAgreementShowButton
{
    _agreementShowButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _agreementShowButton.frame = (CGRect){66.0f, CGRectGetMaxY(_userNameTextField.frame) + 20.0f, 100.0f,18.0f} ;
    
    _agreementShowButton.titleLabel.font = [UIFont systemFontOfSize:13.0f];
    
    NSString *string = @"日日盈用户协议";
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:string];
    
    
    NSDictionary *attributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0x489d3f)};
    [attributedString addAttributes:attributes range:[string rangeOfString:@"日日盈用户协议"]];
    attributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0x000000)};

    [attributedString addAttributes:attributes range:[string rangeOfString:@"同意"]];
    
    [_agreementShowButton setAttributedTitle:attributedString forState:UIControlStateNormal];
    [_agreementShowButton addTarget:self action:@selector(agreementShowButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _agreementShowButton.layer.cornerRadius = 3.0f;
    _agreementShowButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.view addSubview:_agreementShowButton];

    UILabel *label = [[UILabel alloc] initWithFrame:(CGRect){CGRectGetMinX(_agreementShowButton.frame) - 32.0f,_agreementShowButton.frame.origin.y,32.0f,_agreementShowButton.frame.size.height}];
    label.font = [UIFont systemFontOfSize:13.0f];
    label.text = @"同意";
    label.textAlignment = NSTextAlignmentRight;

    [self.view addSubview:label];

}

- (void)agreementShowButtonClicked:(id)sender
{
    
//    WebViewController *webViewController = [[WebViewController alloc] init];
//    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webViewController];
//    [self presentViewController:nav animated:YES completion:nil];
    
    ProtocolViewController *webViewController = [[ProtocolViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webViewController];
    [self presentViewController:nav animated:YES completion:nil];


}

- (void)initNextButton
{
    _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _nextButton.frame = CGRectInset(CGRectOffset(_userNameTextField.frame, 0.0f, 89.0f), 20.0f, 5.0f) ;
    
    _nextButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
    _nextButton.tintColor = UIColorFromRGB(0xffffff);
    _nextButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_nextButton setTitle:@"下一步" forState:UIControlStateNormal];
    [_nextButton addTarget:self action:@selector(nextButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _nextButton.layer.cornerRadius = 3.0f;
    _nextButton.enabled = NO;
    
    [self.view addSubview:_nextButton];
}

- (void)setNextButtonEnable
{
    _nextButton.enabled = YES;
    _nextButton.backgroundColor = UIColorFromRGB(0x2fb610);
}
- (void)setNextButtonUnable
{
    _nextButton.enabled = NO;
    _nextButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
}

- (void)nextButtonClicked:(id)sender
{
    [self makeKeyBoardMiss];
    if ([self inputIsIlligal])
    {
        return;
    }
    [self checkIdIsExist];
}

- (void)checkIdIsExist
{
    _hud = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:_hud];
	_hud.delegate = self;
	_hud.detailsLabelText = @"正在检测证件信息...";
    _hud.square = YES;
    [_hud show:YES];
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }
    NSDictionary *parameters = [self getParameters];
//    [sessionManager POST:@"CheckIdcard" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/login/CheckIdcard"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:parameters path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        [_hud hide:YES];
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];

        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@0] )
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"身份证号已存在" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
            else if([dic[@"sta"] isEqualToNumber:@1])
            {
                [self pushNext];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"服务器异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }

        }
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        [_hud hide:YES];
        
    }];

}


- (NSDictionary*)getParameters
{

//    return  @{@"idcard":[[GlobleData shareInfo] zipString:_userNameTextField.text],
//            };
    return  @{@"idcard":_userNameTextField.text,
              };
}

- (void)pushNext
{
//    RegLastStepViewController *regLastVC = [[RegLastStepViewController alloc] init];
//    regLastVC.userId = _userNameTextField.text;
//    [self.navigationController pushViewController:regLastVC animated:YES];
    
    RegAdditionViewController *additionVC = [[RegAdditionViewController alloc] init];
    additionVC.regFlag = @"0";
    additionVC.userId = _userNameTextField.text;
    [self.navigationController pushViewController:additionVC animated:YES];
}


- (BOOL)inputIsIlligal
{
    if(![[GlobleData shareInfo] idNumberIsvalidWithString:_userNameTextField.text])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"您输入的身份证号码不合法" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    if(!_agreeButton.selected)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"必须同意日日盈用户协议才能使用我们的服务" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.frame.origin.y+textField.frame.size.height > self.view.frame.size.height -216.0f-22.0f)
    {
        CGFloat offY = (self.view.frame.size.height-216.0f)-textField.frame.size.height-textField.frame.origin.y-22.0f;//屏幕总高度-键盘高度-UITextField高度
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        self.view.frame = CGRectMake(self.view.frame.origin.x, offY-44.0f, self.view.frame.size.width, self.view.frame.size.height);//UITextField位置的y坐标移动到offY
        [UIView commitAnimations];//开始动画效果
    }
    else
    {
        [self recoverFrame];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        [self recoverFrame];
        return NO;
    }
    if ((range.location > 17 || textField.text.length > 17) && string.length > 0)
    {
        return NO;
    }
    
    NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (toBeString.length > 14 && _agreeButton.selected)
    {
        [self setNextButtonEnable];
    }
    else
    {
        [self setNextButtonUnable];
    }
    
    if ([string isEqualToString:@"x"])
    {
        textField.text = [NSString stringWithFormat:@"%@X",textField.text];
        return NO;
    }
    return YES;
}

-(void)recoverFrame
{
    [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
    [UIView setAnimationDuration:0.3];
    //UITextField位置复原
    
    self.view.frame = CGRectMake(0.0f,self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height);
    [UIView commitAnimations];
}


- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.view addGestureRecognizer:tap];
}

-( void)tap:(UIGestureRecognizer *)recognizer
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
}

- (void)makeKeyBoardMiss
{
    for (id textField in [self.view subviews])
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            UITextField *theTextField = (UITextField*)textField;
            [theTextField resignFirstResponder];
        }
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
