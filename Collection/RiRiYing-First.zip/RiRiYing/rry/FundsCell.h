//
//  FundsCell.h
//  rry
//
//  Created by Ren Guohua on 14-7-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FundsCell : UITableViewCell

@property (nonatomic, strong) UILabel *leftTopLabel;
@property (nonatomic, strong) UILabel *rightTopLabel;
@property (nonatomic, strong) UILabel *leftBottomLabel;
@property (nonatomic, strong) UILabel *rightBottomLabel;


- (void)bindData:(id)data;
- (void)bindData2:(id)data;

@end
