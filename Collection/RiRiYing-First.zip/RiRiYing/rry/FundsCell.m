//
//  FundsCell.m
//  rry
//
//  Created by Ren Guohua on 14-7-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "FundsCell.h"

@implementation FundsCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self initLeftTopLabel];
        [self initRightTopLabel];
        [self initLeftBottomLabel];
        [self initRightBottomLabel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)initLeftTopLabel
{
    _leftTopLabel = [[UILabel alloc] initWithFrame:(CGRect){
    
        .origin.x = 20.0f,
        .origin.y = 10.0f,
        .size.width = 100.0f,
        .size.height = 20.0f
    
    }];
    _leftTopLabel.backgroundColor = [UIColor clearColor];
    if(IOS7)
    {
       _leftTopLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    } else {
        _leftTopLabel.font = [UIFont systemFontOfSize:15];
    }
    [self addSubview:_leftTopLabel];
}

- (void)initRightTopLabel
{
    _rightTopLabel = [[UILabel alloc] initWithFrame:(CGRect){
        
        .origin.x = 200.0f,
        .origin.y = 10.0f,
        .size.width = 100.0f,
        .size.height = 20.0f
        
    }];
    _rightTopLabel.backgroundColor = [UIColor clearColor];
    if(IOS7)
    {
       _rightTopLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    } else {
        _rightTopLabel.font = [UIFont systemFontOfSize:15];
    }
    _rightTopLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:_rightTopLabel];
}

- (void)initLeftBottomLabel
{
    _leftBottomLabel = [[UILabel alloc] initWithFrame:(CGRect){
        
        .origin.x = 20.0f,
        .origin.y = 35.0f,
        .size.width = 150.0f,
        .size.height = 20.0f
        
    }];
    _leftBottomLabel.backgroundColor = [UIColor clearColor];
    if(IOS7)
    {
        _leftBottomLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    } else {
        _leftBottomLabel.font = [UIFont systemFontOfSize:15];
    }
    _leftBottomLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:_leftBottomLabel];
}

- (void)initRightBottomLabel
{
    _rightBottomLabel = [[UILabel alloc] initWithFrame:(CGRect){
        
        .origin.x = 200.0f,
        .origin.y = 35.0f,
        .size.width = 100.0f,
        .size.height = 20.0f
        
    }];
    _rightBottomLabel.backgroundColor = [UIColor clearColor];
    if(IOS7)
    {
        _rightBottomLabel.font =[UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    } else {
        _rightBottomLabel.font = [UIFont systemFontOfSize:15];
    }
    _rightBottomLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:_rightBottomLabel];
}

- (void)bindData2:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        
        _rightTopLabel.text = [NSString stringWithFormat:@"%@",dic[@"affect_money"]];
        _leftBottomLabel.text = dic[@"add_time"];
        _rightBottomLabel.text = nil;
        
        _leftTopLabel.text =dic[@"type"];
    }

}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        
        _rightTopLabel.text = [NSString stringWithFormat:@"%@",dic[@"affect_money"]];
        _leftBottomLabel.text = dic[@"add_time"];
        _rightBottomLabel.text = [NSString stringWithFormat:@"%@",dic[@"amount"]];
        
         _leftTopLabel.text =dic[@"type"];
//        
//        if ([data[@"type"] isEqualToNumber:@1 ])
//        {
//            _leftTopLabel.text = @"购买";
//        }
//        else if([data[@"type"] isEqualToNumber:@2 ] )
//        {
//            _leftTopLabel.text = @"赎回";
//        }
//        else if([data[@"type"] isEqualToNumber:@3 ])
//        {
//            _leftTopLabel.text = @"返收益";
//        }
//
//        else if([data[@"type"] isEqualToNumber:@4 ])
//        {
//            _leftTopLabel.text = @"购买转入计息";
//        }
//
//        else if([data[@"type"] isEqualToNumber:@5 ] )
//        {
//            _leftTopLabel.text = @"赎回打款成功";
//        }
//
//        else if([data[@"type"] isEqualToNumber:@6 ])
//        {
//            _leftTopLabel.text = @"赎回不通过";
//        }
//        
//        else if([data[@"type"] isEqualToNumber:@8 ])
//        {
//            _leftTopLabel.text = @"处理中";
//        }
//        
//        else if([data[@"type"] isEqualToNumber:@9 ])
//        {
//            _leftTopLabel.text = @"赎回不通过";
//        }
//
//        else if([data[@"type"] isEqualToNumber:@7] )
//        {
//            _leftTopLabel.text = @"推荐奖励";
//        }
    }
}


@end
