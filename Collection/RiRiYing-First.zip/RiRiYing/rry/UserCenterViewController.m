//
//  UserCenterViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "UserCenterViewController.h"
#import "LoginViewController.h"
#import "BankCardBindViewController.h"
#import "ShowBankCardViewController.h"
#import "FundsViewController.h"
#import "RedeemRecorderTableViewController.h"
#import "BuyRecorderTableViewController.h"
#import "AboutUsViewController.h"
#import "TodoViewController.h"
#import "UserInfoTableViewController.h"
#import "HelpViewController.h"
#import "GesturePwdViewController.h"
#import "NotificationTableViewController.h"
#import "ArrayDataSource.h"
#import "UserAvatarCell.h"
#import "UserItemCell.h"
#import "UserData.h"
#import "GlobleData.h"
#import "BankCard.h"
#import "GlobleData.h"

#import "CustomIOS7AlertView.h"


@interface UserCenterViewController ()
{
    NSDictionary *versionDic;
    
    NSString *currentVersion;
}

@end

@implementation UserCenterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self setMyView];
    [self setNavigationBar];
    [self initTableView];
    
    [self checkToUpdate];
}

 /**
  *  从网络获取公告数据
  */
 - (void)checkToUpdate
{
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    //    [sessionManager GET:@"GetArticleList" parameters:nil success:^(AFHTTPRequestOperation *task, id responseObject){
    
    
    [sessionManager POST:@"api/global/getAppVersion" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:@{@"platform": @"ios"} path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        //        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                versionDic = dic[@"data"];
                
                int localVersion = [[[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey] intValue];
                int remoteVersion = [[versionDic objectForKey:@"version"] intValue];
                if (remoteVersion > localVersion)
                {
                    currentVersion = [NSString stringWithFormat:@"当前有新版本v%@", [versionDic objectForKey:@"name"]];
                    UserData *userData = [[GlobleData shareInfo] getUserData];
                    
                    NSString *tel;
                    if (userData.phoneNumber.length>7)
                    {
                        NSString *star = @"";
                        for (int i=0; i<userData.phoneNumber.length-7; i++) {
                            star = [star stringByAppendingString:@"*"];
                        }
                        
                        NSString *str=[NSString stringWithFormat:@"%@%@%@",[userData.phoneNumber substringToIndex:3], star,[userData.phoneNumber substringWithRange:NSMakeRange(userData.phoneNumber.length-4, 4)]];
                        tel = str;
                    }else
                    {
                        tel = userData.phoneNumber;
                        
                    }
                    
                    dataArray = @[@[@{@"image":@"touxiang.png",@"title":userData.realName ? userData.realName : @"暂无",@"subTitle":tel ? tel : @"暂无"}],
                                  @[@{@"image":@"daiban.png",@"title":@"待办事项"},
                                    @{@"image":@"yinhangka.png",@"title":@"银行卡"},
                                    @{@"image":@"xiaofeimingxi.png",@"title":@"修改手势密码"},
                                    @{@"image":@"xiaofeimingxi.png",@"title":@"资金明细"},
                                    @{@"image":@"xiaofeimingxi.png",@"title":/*@"购买记录"*/@"认购债权"},
                                    @{@"image":@"xiaofeimingxi.png",@"title":@"赎回明细"},
                                    ],
                                  @[@{@"image":@"gonggao.png",@"title":@"公告"},
                                    @{@"image":@"bangzhu.png",@"title":@"帮助"},
                                    @{@"image":@"about.png",@"title":@"关于"},
                                    @{@"image":@"about.png",@"title":@"版本更新", @"subtitle":currentVersion}
                                    ]
                                  ];
                    
                    dataSource.items = dataArray;
                    [_tableView reloadData];
                }
                
                
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
    }];
}

     
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getCardNumberFromNetwork];
}
- (void)getCardNumberFromNetwork
{
//    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSLog(@"%@",[self getCardNumParameters]);
//    [sessionManager GET:@"GetCardNumber" parameters:[self getCardNumParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/member/getBankInfo" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getCardNumParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        
    
//        NSData *data = [[GlobleData shareInfo]getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                NSDictionary *dataDic = dic[@"data"];
                _bankCard = [[BankCard alloc]initWithDictionary:[NSMutableDictionary dictionaryWithDictionary:dataDic]];
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        NSLog(@"%@", task.request.URL);
    }];
}


- (NSDictionary*)getCardNumParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
//    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//              };
    return  @{@"user_id":[userData.userId stringValue],
              };
}


- (void)initData
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    currentVersion = [NSString stringWithFormat:@"当前版本是v%@", [infoDictionary objectForKey:@"CFBundleShortVersionString"]];
    
    
    
    UserData *userData = [[GlobleData shareInfo] getUserData];
    
    NSString *tel;
    if (userData.phoneNumber.length>7)
    {
        NSString *star = @"";
        for (int i=0; i<userData.phoneNumber.length-7; i++) {
            star = [star stringByAppendingString:@"*"];
        }
        
        NSString *str=[NSString stringWithFormat:@"%@%@%@",[userData.phoneNumber substringToIndex:3], star,[userData.phoneNumber substringWithRange:NSMakeRange(userData.phoneNumber.length-4, 4)]];
        tel = str;
    }else
    {
        tel = userData.phoneNumber;
        
    }
    
    dataArray = @[@[@{@"image":@"touxiang.png",@"title":userData.realName ? userData.realName : @"暂无",@"subTitle":tel ? tel : @"暂无"}],
                  @[@{@"image":@"daiban.png",@"title":@"待办事项"},
                    @{@"image":@"yinhangka.png",@"title":@"银行卡"},
                    @{@"image":@"xiaofeimingxi.png",@"title":@"修改手势密码"},
                    @{@"image":@"xiaofeimingxi.png",@"title":@"资金明细"},
                    @{@"image":@"xiaofeimingxi.png",@"title":/*@"购买记录"*/@"认购债权"},
                    @{@"image":@"xiaofeimingxi.png",@"title":@"赎回明细"},
                    ],
                  @[@{@"image":@"gonggao.png",@"title":@"公告"},
                    @{@"image":@"bangzhu.png",@"title":@"帮助"},
                    @{@"image":@"about.png",@"title":@"关于"},
                    @{@"image":@"about.png",@"title":@"版本更新", @"subtitle":currentVersion}
                    ]
                  ];
}

- (void)setMyView
{
    self.view.backgroundColor = UIColorFromRGB(0xffffff);
    
}
- (void)setNavigationBar
{
    self.navigationItem.title = @"个人中心";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle     = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor    = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent  = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setFrame:CGRectMake(0.0f, 0.0f, 60.0f, 32.0f)];
    [rightButton setTitle:@"注销" forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(rightButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem = rightButtonItem;
    
}
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightButtonClicked:(id)sender
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"zzuserPass"];
//    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"gesturePwd"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    LoginViewController *loginVC = [[LoginViewController alloc] init];
    loginVC.isHomePage = NO;
    loginVC.delegate = self;
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginVC];
    [self.navigationController presentViewController:navigationController animated:NO completion:nil];
}



- (void)initTableView
{
    if(IOS7)
       _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height - 64.0f) style:UITableViewStyleGrouped];
    else
       _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height - 44.0f) style:UITableViewStyleGrouped];
    
    _tableView.backgroundView = nil;
    _tableView.backgroundColor = UIColorFromRGB(0xf7f7f7);
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
    [_tableView registerClass:[UserAvatarCell class] forCellReuseIdentifier:@"UserAvatarCell"];
    [_tableView registerClass:[UserItemCell class] forCellReuseIdentifier:@"UserItemCell"];
    NSDictionary *dic = @{[NSIndexPath indexPathForRow:0 inSection:0]:@"UserAvatarCell"};
    
    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:dic otherIdentifier:@"UserItemCell" configureCellBlock:^(id cell, id data){
        
        [cell bindData:data];
    }];
    
    self.tableView.dataSource = dataSource;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}

#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0)
    {
        return 77.0f;
    }
    
    return 44.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1 && indexPath.row == 1)
    {
        if (_bankCard == nil || _bankCard.bankName == nil || _bankCard.cardNumber == nil)
        {
            BankCardBindViewController *bankCardBindVC = [[BankCardBindViewController alloc] init];
            [self.navigationController pushViewController:bankCardBindVC animated:YES];
        }
        else
        {
            ShowBankCardViewController *showBankCardVC = [[ShowBankCardViewController alloc] init];
            showBankCardVC.bankCard = _bankCard;
            [self.navigationController pushViewController:showBankCardVC animated:YES];
        }
    }
    
    if (indexPath.section == 1 && indexPath.row == 3)
    {
        FundsViewController *fundsVC = [[FundsViewController alloc] init];
        [self.navigationController pushViewController:fundsVC animated:YES];
    }
    if (indexPath.section == 1 && indexPath.row == 2)
    {
        ////修改手势密码
        GesturePwdViewController *gestureVC = [[GesturePwdViewController alloc] init];
        if(IOS7)
        {
            gestureVC.transitioningDelegate = gestureVC;
        }
        gestureVC.isChangePW = YES;
        gestureVC.parentController=self;
        [self.navigationController presentViewController:gestureVC animated:YES completion:nil];
    }
    
    if (indexPath.section == 1 && indexPath.row == 4)
    {
        
        BuyRecorderTableViewController *buyRecorderVC = [[BuyRecorderTableViewController alloc] init];
        [self.navigationController pushViewController:buyRecorderVC animated:YES];
    }
    
    
    if (indexPath.section == 1 && indexPath.row == 5)
    {
        RedeemRecorderTableViewController *redeemRecorderVC = [[RedeemRecorderTableViewController alloc] init];

        [self.navigationController pushViewController:redeemRecorderVC animated:YES];
    }
    
    if (indexPath.section == 2 && indexPath.row == 2)
    {
        AboutUsViewController *aboutUsVC = [[AboutUsViewController alloc] init];
        [self.navigationController pushViewController:aboutUsVC animated:YES];
    }
    if (indexPath.section == 1 && indexPath.row == 0)
    {
        TodoViewController *todoVC = [[TodoViewController alloc] init];
        [self.navigationController pushViewController:todoVC animated:YES];
    }
    if (indexPath.section == 2 && indexPath.row == 0)
    {
        NotificationTableViewController *notificationVC = [[NotificationTableViewController alloc] init];
        [self.navigationController pushViewController:notificationVC animated:YES];
    }
    if (indexPath.section == 2 && indexPath.row == 1)
    {
        HelpViewController *helpVC = [[HelpViewController alloc] init];
        [self.navigationController pushViewController:helpVC animated:YES];
    }
    
    if (indexPath.section == 0 && indexPath.row == 0)
    {
        UserInfoTableViewController *userInfoVC = [[UserInfoTableViewController alloc] init];
        [self.navigationController pushViewController:userInfoVC animated:YES];
    }
    
    if (indexPath.section == 2 && indexPath.row == 3)
    {
        
        int localVersion = [[[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey] intValue];
        int remoteVersion = [[versionDic objectForKey:@"version"] intValue];
        
        
        if (remoteVersion > localVersion)
        {
            NSString *message = [versionDic objectForKey:@"desc"];
            message = [message stringByReplacingOccurrencesOfString:@"\\n" withString:@"\n"];
            
            if (IOS_VERSION >= 7.0) {
                CustomIOS7AlertView *alertView = [[CustomIOS7AlertView alloc] init];
                
                
                [alertView setContainerView:[self getIOS7AlertView:message]];
                
                
                [alertView setButtonTitles:[NSMutableArray arrayWithObjects:@"以后再说", @"去Appstore更新", nil]];
                [alertView setUseMotionEffects:TRUE];
                [alertView show];
                
                [alertView setOnButtonTouchUpInside:^(CustomIOS7AlertView *alertView, int buttonIndex) {
                    if (buttonIndex == 1) {
                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[versionDic objectForKey:@"downurl"]]];
                    }
                    [alertView close];
                }];
            } else {
                UIAlertView *alert2 = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"检测到当前有新版本:%@", [versionDic objectForKey:@"name"]] message:message delegate:self cancelButtonTitle:@"以后再说" otherButtonTitles:@"去Appstore更新", nil];
                alert2.delegate = self;
                alert2.tag = 2;
                [alert2 show];
            }
        }else{
            UIAlertView *alert3 = [[UIAlertView alloc]initWithTitle:@"现在已经是最新的版本！" message:nil delegate:nil cancelButtonTitle:@"知道了 " otherButtonTitles:nil, nil];
            [alert3 show];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (UIView *)getIOS7AlertView:(NSString *)message
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 280, 200)];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, 280, 20)];
    titleLabel.font = [UIFont boldSystemFontOfSize:17];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = [NSString stringWithFormat:@"检测到当前有新版本：%@", [versionDic  objectForKey:@"name"]];
    [view addSubview:titleLabel];
    
    UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 45, 260, 20)];
    contentLabel.font = [UIFont systemFontOfSize:14];
    contentLabel.textAlignment = NSTextAlignmentLeft;
    contentLabel.textColor = [UIColor blackColor];
    contentLabel.backgroundColor = [UIColor clearColor];
    contentLabel.text = message;
    contentLabel.numberOfLines = 0;
    
    CGSize size = [contentLabel.text sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(270, 1000) lineBreakMode:NSLineBreakByWordWrapping];
    contentLabel.frame = CGRectMake(10, 45, 260, size.height);
    
    [view addSubview:contentLabel];
    
    view.frame = CGRectMake(0, 0, 280, 65+size.height);
    
    return view;
}

#pragma mark -UIAlertViewDelegate
 - (void)willPresentAlertView:(UIAlertView *)alertView{
     
     if (IOS_VERSION < 7.0) {
         if (alertView.tag == 2) {
             UIView * view = [alertView.subviews objectAtIndex:2];
             if([view isKindOfClass:[UILabel class]]){
                 UILabel* tempLabel = (UILabel*) view;
                 tempLabel.textAlignment = NSTextAlignmentLeft;
             }
         }
     }
 }
 
 - (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 2) {
        if (buttonIndex == 1) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[versionDic objectForKey:@"downurl"]]];
        }
    } else if (alertView.tag == 1) {
        if (buttonIndex == 1) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[versionDic objectForKey:@"downurl"]]];
        }
    }
    
}

     
@end
