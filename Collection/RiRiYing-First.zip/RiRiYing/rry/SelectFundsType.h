//
//  SelectFundsType.h
//  rry
//
//  Created by zz on 14-7-7.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol zzSelectFundsTypeDelegate <NSObject>

-(void)GetFundsType:(int)type name:(NSString*)name;

@end

@interface SelectFundsType : UIView<UIPickerViewDataSource,UIPickerViewDelegate>
{
}

@property (strong, nonatomic) IBOutlet UIPickerView *pickView;
@property (retain, nonatomic) id delegate;
@end
