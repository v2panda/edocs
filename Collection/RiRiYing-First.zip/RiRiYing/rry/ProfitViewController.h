//
//  ProfitViewController.h
//  rry
//
//  Created by Ren Guohua on 14-6-4.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ArrayDataSource;

@interface ProfitViewController : UIViewController<UITableViewDelegate>
{
    ArrayDataSource *dataSource;
    NSMutableArray *dataArray;
}
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSString *titleString;
@property (nonatomic, strong) NSString *tag;
@property (nonatomic, strong) UILabel *hintLabel;

@end
