//
//  UserInfoTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-23.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoTableViewController : UITableViewController
{
    NSArray *dataArray;
}

@end
