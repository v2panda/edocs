//
//  AddressCell.m
//  fanfan
//
//  Created by Ren Guohua on 14-2-27.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import "AddressCell.h"

@implementation AddressCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.textLabel.text = dic[@"area_name"];
        if(IOS7)
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    }

}

@end
