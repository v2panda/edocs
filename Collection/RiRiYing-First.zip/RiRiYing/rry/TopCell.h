//
//  TopCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopCell : UICollectionViewCell

@property (nonatomic, strong) UILabel *leftTopLabel;
@property (nonatomic, strong) UILabel *middleLabel;
@property (nonatomic ,strong) UILabel *rightBottomLabel;

- (void)bindData:(id)data;

@end
