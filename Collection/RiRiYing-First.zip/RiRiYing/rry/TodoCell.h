//
//  TodoCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TodoCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subTitleLabel;
@property (nonatomic, strong) UILabel *errorMsg;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UIImageView *hintView;

- (void)bindData:(id)data;

@end
