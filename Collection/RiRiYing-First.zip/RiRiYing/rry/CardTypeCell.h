//
//  CardTypeCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  Block  - 存储cell里输入数据的block
 *
 *  @param cellString cell里的输入的数据
 */
typedef void(^SaveCellString)(NSString *cellString);

@interface CardTypeCell : UITableViewCell<UITextFieldDelegate>

- (void)bindData:(id)data;
- (void)bindInput:(NSString*)inputString;

@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) id delegate;
@property (nonatomic, strong) SaveCellString saveCellString;
@property (nonatomic, strong) UILabel *detailLabel;

@end
