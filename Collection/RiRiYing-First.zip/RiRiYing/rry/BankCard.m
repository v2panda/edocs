//
//  BankCard.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "BankCard.h"

@implementation BankCard


- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    // subclass implementation should set the correct key value mappings for custom keys
    if ([key isEqualToString:@"card_number"])
    {
        self.cardNumber = value;
    }
    else if ([key isEqualToString:@"bank_name"])
    {
        self.bankName = value;
    }
    else if ([key isEqualToString:@"bank_address"])
    {
        self.bank_address = value;
    }
    else if ([key isEqualToString:@"bank_name_id"])
    {
        self.bank_name_id = value;
    }
    else if ([key isEqualToString:@"id"])
    {
        self.c_id = value;
    }
    else if ([key isEqualToString:@"sta"])
    {
        self.sta = value;
    }
    else if ([key isEqualToString:@"sta_info"])
    {
        self.sta_info = value;
    }
    else
    {
        [super setValue:value forUndefinedKey:key];
    }
}

@end
