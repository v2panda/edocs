//
//  RedeemTopCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RedeemTopCell : UITableViewCell

/**
 *  绑定数据
 *
 *  @param data 要绑定的数据
 */
- (void)bindData:(id)data;

@end
