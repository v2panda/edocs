//
//  NotificationCell.m
//  rry
//
//  Created by Ren Guohua on 14-6-26.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "NotificationCell.h"

@implementation NotificationCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
       
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}
- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.textLabel.text = dic[@"title"];
        if(IOS7)
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
        self.textLabel.numberOfLines = 0;
    }
}

@end
