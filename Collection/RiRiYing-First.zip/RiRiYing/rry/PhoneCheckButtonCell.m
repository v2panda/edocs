//
//  PhoneCheckButtonCell.m
//  rry
//
//  Created by Ren Guohua on 14-6-14.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "PhoneCheckButtonCell.h"

@implementation PhoneCheckButtonCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.textLabel.text = @"验证手机号";
        self.textLabel.textColor = UIColorFromRGB(0x08b2f0);
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
