//
//  PlotCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CorePlot-CocoaTouch.h"

@interface PlotCell : UICollectionViewCell<CPTPlotDataSource, CPTAxisDelegate>
{
    NSArray *dicArray;
    NSMutableArray *yArray;
}

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) CPTGraphHostingView *cptView;


- (void)bindData:(id)data;

@end
