//
//  RedeemInputCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RedeemInputCell.h"
#import "RedeemTableViewController.h"

@implementation RedeemInputCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        [self initTextField];
    }
    return self;
}

/**
 *  初始化TextField
 */
- (void)initTextField
{
    _textField = [[UITextField alloc] initWithFrame:CGRectZero];
    _textField.delegate = self;
    
    [self addSubview:_textField];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/**
 *  cell 绑定数据
 *
 *  @param data 要绑定的数据
 */
- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.imageView.image = [UIImage imageNamed:dic[@"image"]];
        
        UILabel *leftLabel = [[UILabel alloc] initWithFrame:(CGRect){0.0f, 0.0f, 88.0f, 44.0f}];
        leftLabel.backgroundColor  = [UIColor clearColor];
        leftLabel.text = dic[@"title"];
        if(IOS7)
            leftLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        leftLabel.textColor = [UIColor grayColor];
        _textField.leftView = leftLabel;
        _textField.leftViewMode = UITextFieldViewModeAlways;
        _textField.frame = (CGRect){54.0f,0.0f,200.0f, 44.0f};
        if ([dic[@"security"] isEqualToString:@"1"])
        {
            _textField.secureTextEntry = YES;
        }
        else
        {
            _textField.secureTextEntry = NO;
        }
    }
}

/**
 *  绑定输入框数据
 *
 *  @param inputString 输入框字符串
 */
- (void)bindInput:(NSString *)inputString
{
    _textField.text = inputString;
}


#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if ([self.delegate isKindOfClass:[RedeemTableViewController class]])
    {
        RedeemTableViewController *redeemVC = (RedeemTableViewController*)self.delegate;
        redeemVC.textField = _textField;
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
   // _saveInputString(textField.text);
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        return NO;
    }
    NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    _saveInputString(toBeString);
    return YES;
}

@end
