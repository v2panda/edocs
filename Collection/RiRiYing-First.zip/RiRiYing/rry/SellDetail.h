//
//  SellDetail.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "JSONModel.h"

@interface SellDetail : JSONModel


@property (nonatomic, strong) NSNumber *amount;
@property (nonatomic, strong) NSString *time;
@property (nonatomic, strong) NSString *fee;
@property (nonatomic, strong) NSString *sta;

@end
