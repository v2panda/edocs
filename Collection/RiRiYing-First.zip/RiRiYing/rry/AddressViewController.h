//
//  AddressViewController.h
//  fanfan
//
//  Created by Ren Guohua on 14-2-27.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddressViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{

    NSArray *addressArray;
}
@property (nonatomic, strong)UITableView *tableView;


@property (nonatomic, strong)NSString *parentId;
@property (nonatomic, strong)NSString *parentName;
@property (nonatomic, strong)NSString *titleText;
@property (nonatomic, assign)NSInteger buttonTag;
@property (nonatomic, strong)id delegate;
@end
