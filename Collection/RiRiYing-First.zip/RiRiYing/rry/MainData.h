//
//  MainData.h
//  rry
//
//  Created by Ren Guohua on 14-5-23.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "JSONModel.h"

@interface MainData : JSONModel

@property (nonatomic, strong) NSString *totalAmount;
@property (nonatomic, strong) NSString *yerIncom;
@property (nonatomic, strong) NSString *manCount;
@property (nonatomic, strong) NSString *wanIncom;

@property (nonatomic, strong) NSString *totalIncom;
@property (nonatomic, strong) NSString *weekIncom;
@property (nonatomic, strong) NSString *monthIncom;
@end
