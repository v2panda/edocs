//
//  TodoViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ArrayDataSource;
@interface TodoViewController : UIViewController<UITableViewDelegate>
{
    ArrayDataSource *dataSource;
    NSArray *dataArray;
    NSDictionary *dataDic;
}
@property (nonatomic, strong) UITableView *tableView;

@end
