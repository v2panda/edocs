//
//  AccountCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "AccountCell.h"
#import "UserData.h"
#import "GlobleData.h"
#import "MainData.h"

@implementation AccountCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        //[self setBackgroundColor:UIColorFromRGB(0xe1412b)];
        [self initLeftTopLabel];
        [self initMiddleLabel];
        //[self initRightBottomLabel];
    }
    return self;
}



- (void)initLeftTopLabel
{
    _leftTopLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, 18.0f, 200.0f, 15.0f)];
    _leftTopLabel.textColor = [UIColor grayColor];
    _leftTopLabel.font = [UIFont systemFontOfSize:15.0f];
    [self addSubview:_leftTopLabel];
}

- (void)initMiddleLabel
{
    
    _middleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, 50.0f, 290.0f, 55.0f)];
    _middleLabel.textColor = UIColorFromRGB(0xe1412b);
    _middleLabel.font = [UIFont boldSystemFontOfSize:57.0f];
    [self addSubview:_middleLabel];
}

- (void)initRightBottomLabel
{
    _rightBottomLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, 110.0f, 290.0f, 13.0f)];
    _rightBottomLabel.textAlignment = NSTextAlignmentRight;
    
    _rightBottomLabel.font = [UIFont systemFontOfSize:13.0f];
    [self addSubview:_rightBottomLabel];
    
}
/**
 *  绑定数据
 *
 *  @param data
 */
- (void)bindData:(id)data
{
    _leftTopLabel.text = @"资金总额(元)";
    
    if ([data isKindOfClass:[MainData class]])
    {
        MainData *mainData = (MainData*)data;
        if ([mainData.totalAmount isEqualToString:@""] || mainData.totalAmount == nil)
        {
            _middleLabel.text = @"0.00";

        }
        else
        {
             _middleLabel.text = mainData.totalAmount;
        }
    }
    else
    {
        _middleLabel.text = @"0.00";
    }

}

@end
