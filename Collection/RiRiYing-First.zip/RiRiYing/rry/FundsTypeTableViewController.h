//
//  FundsTypeTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-7-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FundsTypeTableViewController : UITableViewController
{
    NSArray *dataArray;
}

@property (nonatomic, strong) id delegate;

@end
