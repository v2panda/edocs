//
//  ArrayDataSource.m
//  fanfan
//
//  Created by Ren Guohua on 14-3-29.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import "ArrayDataSource.h"

@implementation ArrayDataSource

/**
 *  初始化tableView数据源
 *
 *  @param itemArray       数据
 *  @param identifierDic   特殊的cell和标识
 *  @param otherIdentifier 一般的cell和标识
 *  @param configureCell   配置cell
 *
 *  @return 返回生成的数据源
 */
- (id)initWithItems:(NSArray*)itemArray
  cellIdentifierDic:(NSDictionary*)identifierDic
    otherIdentifier:(NSString*)otherIdentifier
 configureCellBlock:(void (^)(id, id))configureCell
{
    self = [super init];
    if (self)
    {
        _items = itemArray;
        _cellIdentifierDic = identifierDic;
        configureCellBlock = configureCell;
        _otherIdentifier = otherIdentifier;
    }
    return self;
}


- (id)itemAtIndexPath:(NSIndexPath*)indexPath {
    
    if (_items == nil || [_items count] == 0)
    {
        return nil;
    }
    if( [_items[(NSUInteger)indexPath.section] isKindOfClass:[NSArray class]])
    {
        return _items[(NSUInteger)indexPath.section][(NSUInteger)indexPath.row];
    }
        
    return _items[(NSUInteger)indexPath.row];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (_items == nil ||[_items count] == 0)
    {
        return 0;
    }
    if( [_items[0] isKindOfClass:[NSArray class]])
    {
        return _items.count;
    }
    return 1;
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    if( [_items[section] isKindOfClass:[NSArray class]])
    {
        NSArray *array = _items[section];
        return array.count;
    }
    return _items.count;
}

- (UITableViewCell*)tableView:(UITableView*)tableView
        cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    NSString *identifier = [_cellIdentifierDic objectForKey:indexPath];
    if (identifier == nil)
    {
        identifier = _otherIdentifier;
    }
    id cell = [tableView dequeueReusableCellWithIdentifier :identifier
                                              forIndexPath:indexPath];
    id item = [self itemAtIndexPath:indexPath];
    
    SEL selector = NSSelectorFromString(@"index");
    if ([cell respondsToSelector:selector])
    {
         [cell setValue:indexPath forKey:@"index"];
    }
    configureCellBlock(cell,item);
    return cell;
}


@end
