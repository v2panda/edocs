//
//  PlotCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "PlotCell.h"
#import "NSArray+Compare.h"
#import "GlobleData.h"

//#define PERFORMANCE_TEST
#define GREEN_PLOT_IDENTIFIER       @"Green Plot"
#define BLUE_PLOT_IDENTIFIER        @"Blue Plot"

@interface PlotCell ()
{
    CPTXYGraph * _graph;
    NSMutableArray * _dataForPlot;
    NSArray *dataArray;
    NSTimer *timer;
}
- (void)setupCoreplotViews;

-(CPTPlotRange *)CPTPlotRangeFromFloat:(float)location length:(float)length;

@end

@implementation PlotCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self initTitleLabel];
        [self setupCoreplotViews];
    }
    return self;
}

- (void)initTitleLabel
{

    _titleLabel = [[UILabel alloc] initWithFrame:(CGRect){15.0f,20.0f,200.0f,15.0f}];
    
    _titleLabel.textColor = [UIColor grayColor];
    _titleLabel.text = @"七日年化收益率(%)";
    [self addSubview:_titleLabel];
}

/**
 *  初始化折线图
 */

- (void)setupCoreplotViews
{
  
    
    _cptView = [[CPTGraphHostingView alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_titleLabel.frame), 320.0f, 226.0f - CGRectGetMaxY(_titleLabel.frame) -25.0f)];
    
    [self addSubview:_cptView];
    CPTMutableLineStyle *lineStyle = [CPTMutableLineStyle lineStyle];
    
    _graph = [[CPTXYGraph alloc] initWithFrame:CGRectZero];

    
    CPTGraphHostingView * hostingView = (CPTGraphHostingView *)self.cptView;
    hostingView.collapsesLayers = NO; // Setting to YES reduces GPU memory usage, but can slow drawing/scrolling
    hostingView.hostedGraph = _graph;
    
    _graph.paddingLeft = 0.0f;
    _graph.paddingRight = 0.0;
    _graph.paddingTop = 20.0f;
    _graph.paddingBottom = 0.0f;
    
    _graph.plotAreaFrame.paddingLeft   = 45.0;
    _graph.plotAreaFrame.paddingBottom   = 20.0;
    _graph.plotAreaFrame.paddingRight = 20.0f;
    
    // Setup plot space: 设置一屏内可显示的x,y量度范围
    //
    CPTXYPlotSpace * plotSpace = (CPTXYPlotSpace *)_graph.defaultPlotSpace;
    plotSpace.allowsUserInteraction = NO;

    plotSpace.xRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromDouble(0.0f) length:CPTDecimalFromDouble(6.0f)];
    plotSpace.yRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0f) length:CPTDecimalFromFloat(4.5f)];
    
    // Grid line styles
    CPTMutableLineStyle *majorGridLineStyle = [CPTMutableLineStyle lineStyle];
    majorGridLineStyle.lineWidth = 1.0f;
    majorGridLineStyle.lineColor = [CPTColor grayColor];
    
    CPTMutableLineStyle *minorGridLineStyle = [CPTMutableLineStyle lineStyle];
    minorGridLineStyle.lineWidth = 0.5f;
    minorGridLineStyle.lineColor = [[CPTColor whiteColor] colorWithAlphaComponent:0.1];
    
    
    // Axes: 设置x,y轴属性，如原点，量度间隔，标签，刻度，颜色等
    //
    CPTXYAxisSet *axisSet = (CPTXYAxisSet *)_graph.axisSet;
    
    lineStyle.miterLimit = 1.0f;
    lineStyle.lineWidth = 1.0;
    lineStyle.lineColor = [CPTColor grayColor];
    
    CPTXYAxis * x = axisSet.xAxis;
    x.orthogonalCoordinateDecimal = CPTDecimalFromString(@"0.0"); // 原点的 x 位置
   // x.majorIntervalLength = CPTDecimalFromString(@"1.0");   // x轴主刻度：显示数字标签的量度间隔
    x.minorTicksPerInterval = 0;    // x轴细分刻度：每一个主刻度范围内显示细分刻度的个数
    x.axisLineStyle = lineStyle;
    x.majorGridLineStyle = majorGridLineStyle;
    x.minorGridLineStyle = minorGridLineStyle;
    

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init] ;
    dateFormatter.dateStyle = kCFDateFormatterShortStyle;
   // CPTTimeFormatter *timeFormatter = [[CPTTimeFormatter alloc] initWithDateFormatter:dateFormatter] ;
    //timeFormatter.referenceDate = [NSDate dateWithTimeInterval:(oneDay * 5 * -1) sinceDate:[NSDate date]];
    //x.labelFormatter            = timeFormatter;
    x.majorIntervalLength         = CPTDecimalFromDouble(1.0f);
    x.delegate = self;
    
    
    CPTXYAxis * y = axisSet.yAxis;
    y.orthogonalCoordinateDecimal = CPTDecimalFromString(@"0.0"); // 原点的 y 位置
    //y.orthogonalCoordinateDecimal = CPTDecimalFromDouble(oneDay);
    //y.majorIntervalLength = CPTDecimalFromString(@"2.0f");   // y轴主刻度：显示数字标签的量度间隔
    y.minorTicksPerInterval = 0;    // y轴细分刻度：每一个主刻度范围内显示细分刻度的个数

    y.axisLineStyle = lineStyle;
    y.majorGridLineStyle = majorGridLineStyle;
    y.minorGridLineStyle = minorGridLineStyle;
    y.delegate = self;
    
    // Create a red-blue plot area
    //
    lineStyle.miterLimit        = 1.0f;
    lineStyle.lineWidth         = 2.0f;
    lineStyle.lineColor         = [CPTColor redColor];
   // lineStyle.lineColor         = [CPTColor colorWithComponentRed:116.0f / 255.0f green:116.0f / 255.0f blue:116.0f / 255.0f alpha:1.0f];
    CPTScatterPlot * boundLinePlot  = [[CPTScatterPlot alloc] init];
    boundLinePlot.dataLineStyle = lineStyle;
    boundLinePlot.identifier    = BLUE_PLOT_IDENTIFIER;
    boundLinePlot.dataSource    = self;
    
    // Do a red-blue gradient: 渐变色区域
    //
    CPTColor * blueColor        = [CPTColor colorWithComponentRed:0.3 green:0.3 blue:1.0 alpha:0.8];
    CPTColor * redColor         = [CPTColor colorWithComponentRed:1.0 green:0.3 blue:0.3 alpha:0.8];
    CPTGradient * areaGradient1 = [CPTGradient gradientWithBeginningColor:blueColor
                                                              endingColor:redColor];
    areaGradient1.angle = -90.0f;
    CPTFill * areaGradientFill  = [CPTFill fillWithGradient:areaGradient1];
    //boundLinePlot.areaFill      = areaGradientFill;
    boundLinePlot.areaBaseValue = [[NSDecimalNumber numberWithFloat:1.0] decimalValue]; // 渐变色的起点位置
    
    // Add plot symbols: 表示数值的符号的形状
    //
    CPTMutableLineStyle * symbolLineStyle = [CPTMutableLineStyle lineStyle];
    symbolLineStyle.lineColor = [CPTColor redColor];
    symbolLineStyle.lineWidth = 1.0f;
    
    CPTPlotSymbol * plotSymbol = [CPTPlotSymbol ellipsePlotSymbol];
    plotSymbol.fill          = [CPTFill fillWithColor: [CPTColor colorWithComponentRed:1.0 green:1.0f blue:1.0f alpha:1.0f]];
    plotSymbol.lineStyle     = symbolLineStyle;
    plotSymbol.size          = CGSizeMake(8.0, 8.0);
    boundLinePlot.plotSymbol = plotSymbol;
    
    [_graph addPlot:boundLinePlot];
    
    // Create a green plot area: 画破折线
    //
    lineStyle                = [CPTMutableLineStyle lineStyle];
    lineStyle.lineWidth      = 3.f;
    lineStyle.lineColor      = [CPTColor greenColor];
    //    lineStyle.dashPattern    = [NSArray arrayWithObjects:
    //                                [NSNumber numberWithFloat:5.0f],
    //                                [NSNumber numberWithFloat:5.0f], nil];
    
    CPTScatterPlot * dataSourceLinePlot = [[CPTScatterPlot alloc] init];
    dataSourceLinePlot.dataLineStyle = lineStyle;
    dataSourceLinePlot.identifier = GREEN_PLOT_IDENTIFIER;
    dataSourceLinePlot.dataSource = self;
    
    // Put an area gradient under the plot above
    //
    CPTColor * areaColor            = [CPTColor colorWithComponentRed:0.3 green:1.0 blue:0.3 alpha:0.8];
    CPTGradient * areaGradient      = [CPTGradient gradientWithBeginningColor:areaColor
                                                                  endingColor:[CPTColor clearColor]];
    areaGradient.angle              = -90.0f;
    areaGradientFill                = [CPTFill fillWithGradient:areaGradient];
    dataSourceLinePlot.areaFill     = areaGradientFill;
    //dataSourceLinePlot.areaBaseValue= CPTDecimalFromString(@"1.75");
    
    // Animate in the new plot: 淡入动画
    dataSourceLinePlot.opacity = 0.0f;
    
    CABasicAnimation *fadeInAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    fadeInAnimation.duration            = 3.0f;
    fadeInAnimation.removedOnCompletion = NO;
    fadeInAnimation.fillMode            = kCAFillModeForwards;
    fadeInAnimation.fromValue             = [NSNumber numberWithFloat:0.0];
    fadeInAnimation.toValue             = [NSNumber numberWithFloat:1.0];
    [dataSourceLinePlot addAnimation:fadeInAnimation forKey:@"animateOpacity"];
    
    //[_graph addPlot:dataSourceLinePlot];
    
}

-(void)changePlotRange
{
    if ([_dataForPlot count] < [dataArray count])
    {
        CPTGraph *theGraph = _graph;
        CPTPlot *thePlot   = [theGraph plotWithIdentifier:BLUE_PLOT_IDENTIFIER];
        [_dataForPlot addObject:dataArray[_dataForPlot.count]];
        [thePlot insertDataAtIndex:_dataForPlot.count - 1 numberOfRecords:1];
    }
    else
    {
        [timer invalidate];
    }

}

-(CPTPlotRange *)CPTPlotRangeFromFloat:(float)location length:(float)length
{
    return [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(location) length:CPTDecimalFromFloat(length)];
}

#pragma mark -
#pragma mark Plot Data Source Methods

-(NSUInteger)numberOfRecordsForPlot:(CPTPlot *)plot
{
    return [_dataForPlot count];
}

-(NSNumber *)numberForPlot:(CPTPlot *)plot field:(NSUInteger)fieldEnum recordIndex:(NSUInteger)index
{
    NSString * key = (fieldEnum == CPTScatterPlotFieldX ? @"x" : @"y");
    NSNumber * num = [[_dataForPlot objectAtIndex:index] valueForKey:key];
    return num;
}

#pragma mark -
#pragma mark Axis Delegate Methods

-(BOOL)axis:(CPTAxis *)axis shouldUpdateAxisLabelsAtLocations:(NSSet *)locations
{
    
    CPTXYAxisSet *axisSet = (CPTXYAxisSet *)_graph.axisSet;
    if ([axis isEqual:axisSet.xAxis])
    {
        NSNumberFormatter * formatter   = (NSNumberFormatter*)axis.labelFormatter;
        CGFloat labelOffset             = axis.labelOffset;
        
        NSMutableSet * newLabels        = [NSMutableSet set];
        
        for (NSDecimalNumber * tickLocation in locations) {
            
            NSString * labelString      = [formatter stringForObjectValue:tickLocation];
            
            NSInteger xNumber =  [labelString intValue];
            NSArray *dateArray;
            if (dicArray)
            {
                dateArray = [self getDateArrayWithArray:dicArray];
                labelString      = dateArray[xNumber];
            }

            CPTTextLayer * newLabelLayer= [[CPTTextLayer alloc] initWithText:labelString style:[axis.labelTextStyle mutableCopy]];
            
            CPTAxisLabel * newLabel     = [[CPTAxisLabel alloc] initWithContentLayer:newLabelLayer];
            newLabel.tickLocation       = tickLocation.decimalValue;
            newLabel.offset             = labelOffset;
            
            [newLabels addObject:newLabel];
        }
        
        axis.axisLabels = newLabels;
        
        
        return NO;
    }
    NSNumberFormatter * formatter   = (NSNumberFormatter*)axis.labelFormatter;
    CGFloat labelOffset             = axis.labelOffset;

    
    NSMutableSet * newLabels        = [NSMutableSet set];
    
    for (NSDecimalNumber * tickLocation in locations) {
        
        NSString * labelString      = [formatter stringForObjectValue:tickLocation];
        
        NSInteger yNumber =  [labelString integerValue];
        
        if (yArray)
        {
            labelString  = [NSString stringWithFormat:@"%.2f",[yArray[yNumber] floatValue] / 10000.0f * 100];
        }
        CPTTextLayer * newLabelLayer= [[CPTTextLayer alloc] initWithText:labelString style:[axis.labelTextStyle mutableCopy]];
        
        CPTAxisLabel * newLabel     = [[CPTAxisLabel alloc] initWithContentLayer:newLabelLayer];
        newLabel.tickLocation       = tickLocation.decimalValue;
        newLabel.offset             = labelOffset;
        
        [newLabels addObject:newLabel];
    }
    
    axis.axisLabels = newLabels;
    
    return NO;
}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSArray class]])
    {
        NSMutableArray *mutableArray = [NSMutableArray array];
        NSArray *array = (NSArray*)data;
        
        NSArray *rateArray = [self getRateArratWithArray:array];
        
        NSNumber *max =  [rateArray getMaxItem];
        float maxY = [max floatValue] *10000;
        NSNumber *min = [rateArray getMinItem];
        float minY = [min floatValue] *10000;
        
        double intevel = (maxY - minY) / 4;
        for (NSDictionary *dic in array)
        {
            NSInteger n = [array indexOfObject:dic];
            [mutableArray addObject:@{@"x":@(n),@"y":[NSNumber numberWithFloat:([dic[@"rate"]floatValue] * 10000 - minY + intevel) / intevel]}];

        }
        
        dicArray = array;
        
        [self resetPlotWithArray:array];
        dataArray = [NSArray arrayWithArray:mutableArray];
        _dataForPlot = [NSMutableArray array];
        timer =  [NSTimer scheduledTimerWithTimeInterval:0.04 target:self selector:@selector(changePlotRange) userInfo:nil repeats:YES];
    }
    
}

/**
 *  重载折线图
 *
 *  @param array 折线图数据
 */

- (void)resetPlotWithArray:(NSArray*)array
{
    NSArray *rateArray = [self getRateArratWithArray:array];
    
    NSNumber *max =  [rateArray getMaxItem];
    float maxY = [max floatValue] *10000;
    NSNumber *min = [rateArray getMinItem];
    float minY = [min floatValue] *10000;
  
    CPTGraphHostingView * hostingView = (CPTGraphHostingView *)self.cptView;
    hostingView.collapsesLayers = NO; // Setting to YES reduces GPU memory usage, but can slow drawing/scrolling
    hostingView.hostedGraph = _graph;
    
    // Setup plot space: 设置一屏内可显示的x,y量度范围
    //
    CPTXYPlotSpace * plotSpace = (CPTXYPlotSpace *)_graph.defaultPlotSpace;
    plotSpace.allowsUserInteraction = NO;

    plotSpace.xRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromDouble(0.0f) length:CPTDecimalFromDouble([array count] - 1)];
    
    double yStart = minY - (maxY - minY) / 4;
    NSString *yStartString = [NSString stringWithFormat:@"%.4f",yStart];
    yStart = [yStartString doubleValue];

    CPTXYAxisSet *axisSet = (CPTXYAxisSet *)_graph.axisSet;

    CPTXYAxis * y = axisSet.yAxis;
    double intever = ((double)maxY - (double)minY)  / (double)4.0f;
    
    plotSpace.yRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromString(@"0") length:CPTDecimalFromFloat(6.5f)];
    
    y.majorIntervalLength  = CPTDecimalFromDouble(1.0f);
    
    CPTXYAxis * x = axisSet.xAxis;
    x.orthogonalCoordinateDecimal = CPTDecimalFromFloat(0);
    
    if (!yArray)
    {
        yArray = [NSMutableArray array];
    }
    else
    {
        [yArray removeAllObjects];
    }
    
    for (NSInteger n = 0; n <= 7; n++)
    {
        double yNumber = yStart + intever * n;
        [yArray addObject: [NSNumber numberWithDouble:yNumber]];
    }

}


- (NSArray*)getDateArrayWithArray:(NSArray*)array
{
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array)
    {
        [mutableArray addObject:dic[@"date"]];
    }
    
    return [NSArray arrayWithArray:mutableArray];
}

- (NSArray*)getRateArratWithArray:(NSArray*)array
{
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array)
    {
        [mutableArray addObject:[NSNumber numberWithFloat:[dic[@"rate"] floatValue]]];
    }
    
    return [NSArray arrayWithArray:mutableArray];
}


@end
