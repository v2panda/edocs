//
//  RegAdditionViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface RegAdditionViewController : UIViewController<UITextFieldDelegate>
{
    NSTimer *verifyTimer;
    NSInteger verifiedTime;
}
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UITextField *phoneTextField;
@property (nonatomic, strong) UITextField *verifiedCodeField;
@property (nonatomic, strong) UIButton *getVerifiedCodeButton;
@property (nonatomic, strong) UITextField *nameTextField;
@property (nonatomic, strong) UITextField *loginPwdTextField;
@property (nonatomic, strong) UITextField *getCashPwdTextField;
@property (nonatomic, strong) UITextField *emailTextField;
@property (nonatomic, strong) UITextField *invitePeople;

@property (nonatomic, strong) UIButton *nextButton;
@property (nonatomic, strong) UIAlertView *loadingAlert;
@property (nonatomic, strong) MBProgressHUD *hud;

@property (nonatomic, strong) UILabel *verifiedRightLabel;

@property (nonatomic, strong) NSString *verifiedCode;

@property (nonatomic, strong) NSString *userId;

@property (nonatomic, strong) NSString *regFlag;
@property (nonatomic, strong) UIImage *leftImage;
@property (nonatomic, strong) UIImage *rightImage;
@property (nonatomic, strong) NSString *leftBase64String;
@property (nonatomic, strong) NSString *rightBase64String;

@end
