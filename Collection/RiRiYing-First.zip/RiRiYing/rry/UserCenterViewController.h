//
//  UserCenterViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ArrayDataSource;
@class BankCard;
@interface UserCenterViewController : UIViewController<UITableViewDelegate>
{
    ArrayDataSource *dataSource;
    NSArray *dataArray;
}
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIRefreshControl *refreshControl;
@property (nonatomic, strong) BankCard *bankCard;

@end
