//
//  GesturePwdViewAnimation.h
//  rry
//
//  Created by Ren Guohua on 14-6-10.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GesturePwdViewAnimation : NSObject<UIViewControllerAnimatedTransitioning>


@end
