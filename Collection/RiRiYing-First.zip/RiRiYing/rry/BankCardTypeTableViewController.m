//
//  BankCardTypeTableViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "BankCardTypeTableViewController.h"
#import "UserCenterViewController.h"
#import "BanksTableViewController.h"
#import "MainViewController.h"
#import "AddressViewController.h"
#import "AddAddressViewController.h"
#import "CardTypeCell.h"
#import "GlobleData.h"
#import "UserData.h"
#import "TodoViewController.h"

@interface BankCardTypeTableViewController ()

@end

@implementation BankCardTypeTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavigationBar];
    [self initFinishButton];
    
    [self registerCell];
    [self addTap];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self initData];
    [self.tableView reloadData];
}

/**
 *  注册tableViewCell
 */
- (void)registerCell
{
       [self.tableView registerClass:[CardTypeCell class] forCellReuseIdentifier:@"Cell"];
}
/**
 *  初始化界面初始数据
 */

- (void)initData
{
    
    if (_bankName == nil)
    {
        _bankName = @"";
    }
    if (_bankAdress == nil)
    {
        _bankAdress = @"";
    }

    dataArray = @[@{@"sectionTitle":@"请选择银行卡类型",
                    @"info":@[
                                @{@"title":@"卡类型",
                                  //@"placeholder":@"例如:招商银行 储蓄卡",
                                  @"subTitle":_bankName,
                                  @"isChoose":@"YES",
                                  @"titleColor":@0x08b2f0
                                  }
                            ]
                    },
                  
                  @{@"sectionTitle":@"请填写银行详细信息",
                    @"info":@[
                                @{@"title":@"地区",
                                  @"isChoose":@"YES",
                                  @"subTitle":_bankAdress,
                                  @"titleColor":@0x08b2f0
                                  },
                                @{@"title":@"支行信息",
                                  @"isChoose":@"NO"
                                  }
                             ]
                    }
                  ];

}
/**
 *  初始化导航栏
 */
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"填写银行卡信息";

    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
/**
 *  导航栏返回按钮
 *
 *  @param sender
 */
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
/**
 *  确认按钮
 */

- (void)initFinishButton
{
    _finishButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _finishButton.frame = CGRectInset(CGRectMake(0.0f, 260, 320.0f, 44.0f), 20.0f, 5.0f);
    
    _finishButton.backgroundColor = UIColorFromRGB(0x36a41d);
    _finishButton.tintColor = UIColorFromRGB(0xffffff);
    _finishButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_finishButton setTitle:@"确定" forState:UIControlStateNormal];
    [_finishButton addTarget:self action:@selector(finishButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _finishButton.layer.cornerRadius = 3.0f;
    
    [self.tableView addSubview:_finishButton];
}

/**
 *  确定按钮点击事件
 *
 *  @param sender
 */
- (void)finishButtonClicked:(id)sender
{
    [_textField resignFirstResponder];
    
    if ([self inputIsIlligal])
    {
        return;
    }
    [self getDataFromNetwork];

}

/**
 *  绑定银行卡
 */

- (void)getDataFromNetwork
{
    UIAlertView *loadingAlert=[[UIAlertView alloc] initWithTitle:@"正在绑定..." message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:nil,nil];
    loadingAlert.alertViewStyle=UIAlertViewStyleDefault;
    [loadingAlert show];
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *parameters = [self getParameters];
    NSLog(@"%@",parameters);
//    [sessionManager POST:@"BindBankCard" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
        [sessionManager POST:@"api/member/bindBankCard" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:parameters path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        
        
   
        [loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
      
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"绑定成功" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                alert.tag = 1;
                [alert show];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }

        }
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        [loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
    
}

/**
 *  http请求参数
 *
 *  @return  http请求参数
 */
- (NSDictionary*)getParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    NSLog(_bankName);
    _cardNumber = [_cardNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    return  @{@"user_id":[userData.userId stringValue],
              @"card_number":_cardNumber,
              @"area_code":_bankAdressCode,
              @"bank_address":_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]],
              @"bank_name_id":_bank_name_id
              };
}

/**
 *  判断输入是否合法
 *
 *  @return YES－非法 NO－合法
 */
- (BOOL)inputIsIlligal
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(self.bankName.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入卡类型" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(self.bankAdress.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入银行地区" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(((NSString*)_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]]).length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入支行信息" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
}

-( void)tap:(UIGestureRecognizer *)recognizer
{
    [_textField resignFirstResponder];
}

#pragma  Gesture delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 若为UITableViewCellContentView（即点击了tableViewCell），则不截获Touch事件
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    return  YES;
}



#pragma UIAlert delegate
//根据被点击按钮的索引处理点击事件
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (alertView.tag == 1)
    {
        if (buttonIndex == 0)
        {
            [self.navigationController popToViewController:self.navigationController.viewControllers[self.navigationController.viewControllers.count-4] animated:YES];
            
//            for (UIViewController *viewController in self.navigationController.viewControllers)
//            {
//                if ([viewController isKindOfClass:[TodoViewController class]])
//                {
//                    [self.navigationController popToViewController:viewController animated:YES];
//                    break;
//                }
//            }
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [dataArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [dataArray[section][@"info"] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CardTypeCell *cell = (CardTypeCell*)[tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    cell.saveCellString = ^(NSString *cellString){
        
        if (_cellStringDic == nil)
        {
            _cellStringDic = [NSMutableDictionary dictionary];
        }
        _cellStringDic[indexPath] = cellString;
    };
    
    cell.delegate = self;
    [cell bindData:dataArray[indexPath.section][@"info"][indexPath.row]];

    [cell bindInput:_cellStringDic[indexPath]];
    return cell;
}

- (NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return dataArray[section][@"sectionTitle"];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0)
    {
        BanksTableViewController *banksVC = [[BanksTableViewController alloc] init];
        banksVC.delegate = self;
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:banksVC];
        [self presentViewController:nav animated:YES completion:nil];
        
        return;
    }
    if (indexPath.section == 1 && indexPath.row == 0)
    {
        AddAddressViewController *addAddressVC = [[AddAddressViewController alloc] init];
        addAddressVC.delegate = self;
        [self.navigationController pushViewController:addAddressVC animated:YES];
    }
    
    
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
