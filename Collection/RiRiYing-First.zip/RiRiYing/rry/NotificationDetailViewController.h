//
//  NotificationDetailViewController.h
//  rry
//
//  Created by Ren Guohua on 14-6-26.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationDetailViewController : UIViewController

@property (nonatomic, strong) NSString *notificationId;
@property (nonatomic, strong) UIWebView *webView;
@end
