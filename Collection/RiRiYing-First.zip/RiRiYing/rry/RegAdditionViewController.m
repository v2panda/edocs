//
//  RegAdditionViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//


#import "RegAdditionViewController.h"
#import "RegLastStepViewController.h"
#import "MainViewController.h"
#import "GlobleData.h"
#import "NSData+Base64.h"

@interface RegAdditionViewController ()

@end

@implementation RegAdditionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyview];
    [self setNavigationBar];
    [self initScrollView];
    [self initNameTextField];
    [self initEmailTextField];
    [self initInvitePeople];
    
    [self initLoginPwdTextField];
    [self initGetCashPwdTextField];
    [self initPhoneTextField];
    [self initVerifiedCodeFiled];
    [self initNextButton];
    [self addTap];
    [self addNotifications];
    
}

- (void)setMyview
{
    self.view.backgroundColor = UIColorFromRGB(0xf7f7f7);
}
- (void)setNavigationBar
{

    self.navigationItem.title = @"账户信息";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle     = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor    = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent  = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem       = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
}
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initScrollView
{
    _scrollView = [[UIScrollView alloc] initWithFrame:(CGRect){
        
        .origin.x    = 0.0f,
        .origin.y    = 0.0f,
        .size.width  = self.view.frame.size.width,
        .size.height = self.view.frame.size.height - 64.0f,
    
    }];
    _scrollView.contentSize = (CGSize){self.view.frame.size.width,self.view.frame.size.height - 64.0f};
    [self.view addSubview:_scrollView];

}

- (void)initPhoneTextField
{
    _phoneTextField              = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, CGRectGetMaxY(_getCashPwdTextField.frame) + 20.0f, 320.0f, 44.0f)];
    UIImageView *leftView        = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image               = [UIImage imageNamed:@"shoujihao.png"];
    if(IOS7)
    {
        leftView.image               = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        leftView.tintColor           = UIColorFromRGB(0x909090);
    }
    _phoneTextField.leftView     = leftView;
    _phoneTextField.leftViewMode = UITextFieldViewModeAlways;

    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 14.0f, 16.0f, 16.0f)];

    imageView.image        = [UIImage imageNamed:@"star.png"];


    UIView *rightView      = [[UIView alloc] initWithFrame:CGRectMake(284.0f, 0.0f, 36.0f, 44.0f)];
    [rightView addSubview:imageView];
    
    
    _phoneTextField.rightView     = rightView;
    _phoneTextField.rightViewMode = UITextFieldViewModeAlways;


    _phoneTextField.borderStyle   = UITextBorderStyleRoundedRect;
    _phoneTextField.delegate      = self;
    _phoneTextField.placeholder   = @"手机号(用来重置密码)";
    _phoneTextField.keyboardType  = UIKeyboardTypeNumberPad;
    _phoneTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _phoneTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _phoneTextField.font          = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    [self.scrollView addSubview:_phoneTextField];
}


- (void)initVerifiedCodeFiled
{
    _verifiedCodeField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f,CGRectGetMaxY(_phoneTextField.frame) - 1.0f, self.view.frame.size.width, 44.0f)];
    _verifiedCodeField.textColor = UIColorFromRGB(0x4a4a4a);
    _verifiedCodeField.placeholder = @"验证码";
    _verifiedCodeField.borderStyle = UITextBorderStyleRoundedRect;
    _verifiedCodeField.delegate = self;
    _verifiedCodeField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _verifiedCodeField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [self.scrollView addSubview:_verifiedCodeField];
    
    UIImageView *leftView           = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image                  = [UIImage imageNamed:@"yanzhengma.png"];
    if(IOS7)
    {
        leftView.image                  = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        leftView.tintColor              = UIColorFromRGB(0x909090);
    }
    _verifiedCodeField.leftView     = leftView;
    _verifiedCodeField.leftViewMode = UITextFieldViewModeAlways;
    
    
    _getVerifiedCodeButton                 = [UIButton buttonWithType:UIButtonTypeCustom];
    _getVerifiedCodeButton.backgroundColor = [UIColor clearColor];
    _getVerifiedCodeButton.frame           = CGRectMake(0.0f, 00.0f, 80.0f, 44.0f);
    [_getVerifiedCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [_getVerifiedCodeButton setTintColor:UIColorFromRGB(0x2fb610)];
    [_getVerifiedCodeButton setTitleColor:UIColorFromRGB(0x2fb610) forState:UIControlStateNormal];
    _getVerifiedCodeButton.titleLabel.font = [UIFont systemFontOfSize:14];
    
    [_getVerifiedCodeButton addTarget:self action:@selector(getVerifiedCode:) forControlEvents:UIControlEventTouchUpInside];
    _verifiedCodeField.rightView     = _getVerifiedCodeButton;
    _verifiedCodeField.rightViewMode = UITextFieldViewModeAlways;
    if(IOS7)
        _verifiedCodeField.font          = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    
}

- (void)getVerifiedCode:(id)sender
{
    ///验证手机号
    if(![GlobleData isPureInt:_phoneTextField.text])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"错误" message:@"手机号格式不正确" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alert show];
        return;
    }
    if ([self inputIsIlligalForVerifiedCode])
    {
        return;
    }
    
    NSDictionary *dic = [self getVerifiedParameters];
    
    UIButton *button = (UIButton *)sender;
    button.userInteractionEnabled = NO;
    
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager GET:@"GetValiCode" parameters:[self getVerifiedParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/login/getRegVerifyCode"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:dic path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
    
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                _verifiedCode = dic[@"data"];
                NSLog(@"%@",dic[@"data"]);
                verifiedTime = 180;
                if (_verifiedRightLabel == nil)
                {
                    _verifiedRightLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 100.0f, 48.0f)];
                }
                _verifiedRightLabel.text          = [NSString stringWithFormat:@"%ld",(long)verifiedTime];
                _verifiedRightLabel.textColor     = [UIColor redColor];
                _verifiedRightLabel.textAlignment = NSTextAlignmentCenter;
                _verifiedCodeField.rightView      = _verifiedRightLabel;
                verifyTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(handleTimer:) userInfo:nil repeats:YES];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }

        }
        button.userInteractionEnabled = YES;
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        button.userInteractionEnabled = YES;
        
    }];
    
}


- (BOOL)inputIsIlligalForVerifiedCode
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (_phoneTextField.text.length < 11)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"手机号码不正确" message:@"请输入正确的绑定手机号接收验证码" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}



- (NSDictionary*)getVerifiedParameters
{
    if (_phoneTextField.text.length != 11)
    {
        return nil;
    }
//    return @{@"mobile":[[GlobleData shareInfo] zipString:_phoneTextField.text]};
    return @{@"mobile":_phoneTextField.text};
}


- (void)handleTimer:(NSTimer*)timer
{
    
    verifiedTime --;
    if (verifiedTime == 0)
    {
        _verifiedCodeField.rightView = _getVerifiedCodeButton;
        [verifyTimer invalidate];
    }
    else
    {
        _verifiedRightLabel.text = [NSString stringWithFormat:@"%ld秒",(long)verifiedTime];
    }
}


- (void)initNameTextField
{
    _nameTextField          = [[UITextField alloc] initWithFrame:CGRectMake(0.0f,15.0f, 320.0f, 44.0f)];
    UIImageView *leftView   = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image          = [UIImage imageNamed:@"pic_xingming.png"];
    if(IOS7)
    {    leftView.image          = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    leftView.tintColor      = UIColorFromRGB(0x909090);
    }
    _nameTextField.leftView = leftView;
    _nameTextField.leftViewMode = UITextFieldViewModeAlways;

    UIImageView *imageView      = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 14.0f, 16.0f, 16.0f)];

    imageView.image             = [UIImage imageNamed:@"star.png"];


    UIView *rightView           = [[UIView alloc] initWithFrame:CGRectMake(284.0f, 0.0f, 36.0f, 44.0f)];
    [rightView addSubview:imageView];
    _nameTextField.rightView     = rightView;
    _nameTextField.rightViewMode = UITextFieldViewModeAlways;

    _nameTextField.borderStyle   = UITextBorderStyleRoundedRect;
    _nameTextField.delegate      = self;
    _nameTextField.placeholder   = @"姓名(必须与身份证保持一致)";
    _nameTextField.keyboardType  = UIKeyboardTypeNamePhonePad;
    _nameTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _nameTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _nameTextField.font          = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    [self.scrollView addSubview:_nameTextField];
}

- (void)initEmailTextField
{
    _emailTextField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f,CGRectGetMaxY(_nameTextField.frame) - 1.0f, 320.0f, 44.0f)];
    UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image = [UIImage imageNamed:@"email.png"];
    if(IOS7)
    {    leftView.image = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    leftView.tintColor = UIColorFromRGB(0x909090);
    }
    _emailTextField.leftView = leftView;
    _emailTextField.leftViewMode = UITextFieldViewModeAlways;
    
    
    _emailTextField.borderStyle = UITextBorderStyleRoundedRect;
    _emailTextField.delegate = self;
    _emailTextField.placeholder = @"邮箱(用于验证)";
    _emailTextField.keyboardType = UIKeyboardTypeEmailAddress;
    _emailTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _emailTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _emailTextField.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    [self.scrollView addSubview:_emailTextField];
}

- (void)initInvitePeople
{
    _invitePeople = [[UITextField alloc] initWithFrame:CGRectMake(0.0f,CGRectGetMaxY(_emailTextField.frame) - 1.0f, 320.0f, 44.0f)];
    UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image = [UIImage imageNamed:@"pic_sfz.png"];
    if(IOS7)
    {    leftView.image = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        leftView.tintColor = UIColorFromRGB(0x909090);
    }
    _invitePeople.leftView = leftView;
    _invitePeople.leftViewMode = UITextFieldViewModeAlways;
    
    
    _invitePeople.borderStyle = UITextBorderStyleRoundedRect;
    _invitePeople.delegate = self;
    _invitePeople.placeholder = @"请输入邀请人身份证号（可选）";
    _invitePeople.keyboardType = UIKeyboardTypeEmailAddress;
    _invitePeople.clearButtonMode = UITextFieldViewModeWhileEditing;
    _invitePeople.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _invitePeople.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    [self.scrollView addSubview:_invitePeople];
}


- (void)initLoginPwdTextField
{
    _loginPwdTextField              = [[UITextField alloc] initWithFrame:CGRectMake(0.0f,CGRectGetMaxY(_invitePeople.frame) + 20.0f, 320.0f, 44.0f)];
    UIImageView *leftView           = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image                  = [UIImage imageNamed:@"mima.png"];
    if(IOS7)
    {    leftView.image                  = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    leftView.tintColor              = UIColorFromRGB(0x909090);
    }
    _loginPwdTextField.leftView     = leftView;
    _loginPwdTextField.leftViewMode = UITextFieldViewModeAlways;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 14.0f, 16.0f, 16.0f)];

    imageView.image        = [UIImage imageNamed:@"star.png"];


    UIView *rightView      = [[UIView alloc] initWithFrame:CGRectMake(284.0f, 0.0f, 36.0f, 44.0f)];
    [rightView addSubview:imageView];
    
    _loginPwdTextField.rightView     = rightView;
    _loginPwdTextField.rightViewMode = UITextFieldViewModeAlways;
    
    _loginPwdTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;

    _loginPwdTextField.borderStyle   = UITextBorderStyleRoundedRect;
    _loginPwdTextField.delegate      = self;
    _loginPwdTextField.placeholder   = @"登录密码(用于登录)";
    _loginPwdTextField.keyboardType  = UIKeyboardTypeAlphabet;
    _loginPwdTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _loginPwdTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _loginPwdTextField.font          = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    [self.scrollView addSubview:_loginPwdTextField];
}

- (void)initGetCashPwdTextField
{
    _getCashPwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f,CGRectGetMaxY(_loginPwdTextField.frame) - 1.0f, 320.0f, 44.0f)];
    UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image = [UIImage imageNamed:@"pic_tixianmima.png"];
    if(IOS7)
    {   leftView.image = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    leftView.tintColor = UIColorFromRGB(0x909090);
    }
    _getCashPwdTextField.leftView = leftView;
    _getCashPwdTextField.leftViewMode = UITextFieldViewModeAlways;
    
    UIImageView *imageView =  [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 14.0f, 16.0f, 16.0f)];
    
    imageView.image = [UIImage imageNamed:@"star.png"];
    
    
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(284.0f, 0.0f, 36.0f, 44.0f)];
    [rightView addSubview:imageView];
    
    _getCashPwdTextField.rightView = rightView;
    _getCashPwdTextField.rightViewMode = UITextFieldViewModeAlways;
    
    _getCashPwdTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    
    _getCashPwdTextField.borderStyle = UITextBorderStyleRoundedRect;
    _getCashPwdTextField.delegate = self;
    _getCashPwdTextField.placeholder = @"提现密码(用于赎回)";
    _getCashPwdTextField.keyboardType = UIKeyboardTypeAlphabet;
    _getCashPwdTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _getCashPwdTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _getCashPwdTextField.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    [self.scrollView addSubview:_getCashPwdTextField];
}


- (void)initNextButton
{
    _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _nextButton.frame = CGRectInset(CGRectMake(0.0f,CGRectGetMaxY(_verifiedCodeField.frame) + 20.0f, 320.0f, 44.0f), 20.0f, 5.0f);
    
    _nextButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
    _nextButton.tintColor = UIColorFromRGB(0xffffff);
    _nextButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_nextButton setTitle:@"完成" forState:UIControlStateNormal];
    [_nextButton addTarget:self action:@selector(nextButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _nextButton.layer.cornerRadius = 3.0f;
    _nextButton.enabled = NO;
    [self.scrollView addSubview:_nextButton];
    
}

- (void)setNextButtonEnable
{
    _nextButton.enabled = YES;
    _nextButton.backgroundColor = UIColorFromRGB(0x2fb610);
}
- (void)setNextButtonUnable
{
    _nextButton.enabled = NO;
    _nextButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
}


- (void)nextButtonClicked:(id)sender
{
    if ([self inputIsIlligal])
    {
        return;
    }
    
    _hud = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:_hud];
	_hud.detailsLabelText = @"正在注册...";
    _hud.square = YES;
    [_hud show:YES];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSDictionary *parameters = [self getParametersWithRegFlag:_regFlag];

        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self regWithParameters:parameters];
        });
    });

}
- (NSString*)convertToBase64StringWithImage:(UIImage*)image
{
    NSData *data = UIImageJPEGRepresentation(image, 0.2);//UIImagePNGRepresentation(image);
    NSString *base64String = [data base64EncodedStringWithOptions:0];
    return base64String;
}


- (void)regWithParameters:(NSDictionary*)parameters
{
    
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    [sessionManager POST:@"RegisterUser" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/login/register"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:parameters path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        [_hud hide:YES];
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"注册成功！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                alert.tag = 2;
                [alert show];
                
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
       
        [_hud hide:YES];
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
}

- (NSDictionary*)getParametersWithRegFlag:(NSString*)regFlag
{

    NSDictionary *parameters;
//    if ([regFlag isEqualToString:@"0"])
//    {
//        parameters =   @{@"idcard":[[GlobleData shareInfo] zipString:_userId],
//                         @"mobile":[[GlobleData shareInfo] zipString:_phoneTextField.text],
//                         @"real_name":[[GlobleData shareInfo] zipString:_nameTextField.text],
//                         @"app_login_pwd":[[GlobleData shareInfo] zipString:_loginPwdTextField.text],
//                         @"trade_pwd":[[GlobleData shareInfo] zipString:_getCashPwdTextField.text],
//                         @"idcard_img_flag_s":[[GlobleData shareInfo] zipString:regFlag],
//                         @"valiCode":[[GlobleData shareInfo] zipString:_verifiedCodeField.text],
//                 // @"email":[[GlobleData shareInfo] zipString:_emailTextField.text]
//                  };
//    }
//    else
//    {
//        NSLog(_leftBase64String);
//        NSLog(_rightBase64String);
//        parameters =   @{@"idcard":[[GlobleData shareInfo] zipString:_userId],
//                         @"mobile":[[GlobleData shareInfo] zipString:_phoneTextField.text],
//                         @"real_name":[[GlobleData shareInfo] zipString:_nameTextField.text],
//                         @"app_login_pwd":[[GlobleData shareInfo] zipString:_loginPwdTextField.text],
//                         @"trade_pwd":[[GlobleData shareInfo] zipString:_getCashPwdTextField.text],
//                         @"idcard_img":[[GlobleData shareInfo] zipString:_leftBase64String],
//                         @"idcard_img_EndName":[[GlobleData shareInfo]zipString:@"png"],
//                         @"idcard_img_back":[[GlobleData shareInfo] zipString:_rightBase64String],
//                         @"idcard_img_back_EndName":[[GlobleData shareInfo]zipString:@"png"],
//                         @"idcard_img_flag_s":[[GlobleData shareInfo] zipString:regFlag],
//                         @"valiCode":[[GlobleData shareInfo] zipString:_verifiedCodeField.text],
//                 // @"email":[[GlobleData shareInfo] zipString:_emailTextField.text]
//                  };
//    }
//    if ([regFlag isEqualToString:@"0"])
//    {
    if ([_invitePeople.text length] == 0) {
        parameters =   @{@"idcard":_userId,
                         @"mobile":_phoneTextField.text,
                         @"email":_emailTextField.text,
                         @"real_name":_nameTextField.text,
                         @"pwd":_loginPwdTextField.text,
                         @"trade_pwd":_getCashPwdTextField.text,
                         @"verify_code":_verifiedCodeField.text,
//                         @"invite_idcard": _invitePeople.text,
                         @"platform": @"ios"
                         };
    } else {
        parameters =   @{@"idcard":_userId,
                         @"mobile":_phoneTextField.text,
                         @"email":_emailTextField.text,
                         @"real_name":_nameTextField.text,
                         @"pwd":_loginPwdTextField.text,
                         @"trade_pwd":_getCashPwdTextField.text,
                         @"verify_code":_verifiedCodeField.text,
                         @"invite_idcard": _invitePeople.text,
                         @"platform": @"ios"
                         };
    }
    
//    }
//    else
//    {
////        NSLog(_leftBase64String);
////        NSLog(_rightBase64String);
//        parameters =   @{@"idcard":[[GlobleData shareInfo] zipString:_userId],
//                         @"mobile":[[GlobleData shareInfo] zipString:_phoneTextField.text],
//                         @"real_name":[[GlobleData shareInfo] zipString:_nameTextField.text],
//                         @"app_login_pwd":[[GlobleData shareInfo] zipString:_loginPwdTextField.text],
//                         @"trade_pwd":[[GlobleData shareInfo] zipString:_getCashPwdTextField.text],
//                         @"idcard_img":[[GlobleData shareInfo] zipString:_leftBase64String],
//                         @"idcard_img_EndName":[[GlobleData shareInfo]zipString:@"png"],
//                         @"idcard_img_back":[[GlobleData shareInfo] zipString:_rightBase64String],
//                         @"idcard_img_back_EndName":[[GlobleData shareInfo]zipString:@"png"],
//                         @"idcard_img_flag_s":[[GlobleData shareInfo] zipString:regFlag],
//                         @"valiCode":[[GlobleData shareInfo] zipString:_verifiedCodeField.text],
//                         // @"email":[[GlobleData shareInfo] zipString:_emailTextField.text]
//                         };
//    }

    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:parameters];
    if (_emailTextField.text.length > 0)
    {
        ///_emailTextField.text
        [dic setObject:_emailTextField.text forKey:@"email"];
    }
    
    return dic;
}



- (BOOL)inputIsIlligal
{
    if(_phoneTextField.text.length != 11)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入11位手机号码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(_verifiedCodeField.text.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输验证码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(_nameTextField.text.length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入真实姓名" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(_loginPwdTextField.text.length < 6)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"登录密码必须为6位" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(_getCashPwdTextField.text.length < 6)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"提现密码必须为6位" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if ([_getCashPwdTextField.text isEqualToString:_loginPwdTextField.text])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"提现密码不能与登录密码相同" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (_emailTextField.text.length > 0&&[_emailTextField.text rangeOfString:@"@"].location == NSNotFound)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入正确的邮箱地址" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}

#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{

    if (textField == _loginPwdTextField || textField == _getCashPwdTextField)
    {
        textField.secureTextEntry = NO;
        return;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == _loginPwdTextField || textField == _getCashPwdTextField)
    {
        textField.secureTextEntry = YES;
        return;
    }
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        return NO;
    }
    if (textField == _phoneTextField)
    {
        if ((range.location > 10 || textField.text.length > 10) && string.length > 0)
        {
            return NO;
        }
        NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (toBeString.length > 10 && _nameTextField.text.length > 0 &&
            _loginPwdTextField.text.length > 5 && _getCashPwdTextField.text.length > 5 && _verifiedCodeField.text.length > 0)
        {
            [self setNextButtonEnable];
        }
        else
        {
            [self setNextButtonUnable];
        }
    }
    
//    if (textField == _nameTextField)
//    {
//        if ((range.location > 9 || textField.text.length > 9) && string.length > 0)
//        {
//            return NO;
//        }
//        NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
//        
//        if (toBeString.length > 0 &&
//            _loginPwdTextField.text.length > 5 && _getCashPwdTextField.text.length > 5 && _verifiedCodeField.text.length > 0 && _phoneTextField.text.length > 10)
//        {
//            [self setNextButtonEnable];
//        }
//        else
//        {
//            [self setNextButtonUnable];
//        }
//    }
    
    if (textField == _verifiedCodeField)
    {
        NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (toBeString.length > 0 &&
            _loginPwdTextField.text.length > 5 && _getCashPwdTextField.text.length > 5 && _phoneTextField.text.length > 10 && _nameTextField.text.length > 0)
        {
            [self setNextButtonEnable];
        }
        else
        {
            [self setNextButtonUnable];
        }
    }
    
//    if (textField == _emailTextField)
//    {
//         NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
//        if (toBeString.length > 0 &&
//            _loginPwdTextField.text.length > 5 && _getCashPwdTextField.text.length > 5 && _phoneTextField.text.length > 10 && _nameTextField.text.length > 0 && _verifiedCodeField.text.length > 0)
//        {
//            [self setNextButtonEnable];
//        }
//        else
//        {
//            [self setNextButtonUnable];
//        }
//    }
    
    if (textField == _loginPwdTextField)
    {
        NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (toBeString.length > 5 &&
             _getCashPwdTextField.text.length > 5 && _phoneTextField.text.length > 10 && _nameTextField.text.length > 0 && _verifiedCodeField.text.length > 0)
        {
            [self setNextButtonEnable];
        }
        else
        {
            [self setNextButtonUnable];
        }
    }
    
    if (textField == _getCashPwdTextField)
    {
        NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (toBeString.length > 5 &&
           _loginPwdTextField.text.length > 5 && _phoneTextField.text.length > 10 && _nameTextField.text.length > 0 && _verifiedCodeField.text.length > 0)
        {
            [self setNextButtonEnable];
        }
        else
        {
            [self setNextButtonUnable];
        }
    }
    return YES;
}


- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.view addGestureRecognizer:tap];
}

-( void)tap:(UIGestureRecognizer *)recognizer
{
    [self makeKeyBoardMiss];
}

- (void)makeKeyBoardMiss
{
    for (id textField in [self.scrollView subviews])
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            UITextField *theTextField = (UITextField*)textField;
            [theTextField resignFirstResponder];
        }
    }
}



- (void)login
{
//
//    if (![GlobleData shareInfo].key) {
//        [GlobleData shareInfo].key = [GlobleData createRandomKey];
//    }
//    
//    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL];
//    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [sessionManager POST:@"LoginUser" parameters:[self getLoginParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
//        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
//        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
//        
//        if ([dic[@"StateCode"] isEqualToNumber:@1] )
//        {
//            [[NSUserDefaults standardUserDefaults] setObject:responseObject forKey:@"userData"];
//            [[NSUserDefaults standardUserDefaults] setObject:_userId forKey:@"userName"];
//            [[NSUserDefaults standardUserDefaults] setObject:_loginPwdTextField.text forKey:@"zzuserPass"];
//            [[NSUserDefaults standardUserDefaults] synchronize];
//            
//            MainViewController *mainVC = [[MainViewController alloc] init];
//            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:mainVC];
//            [self.navigationController presentViewController:nav animated:NO completion:nil];
//        }
//    } failure:^(AFHTTPRequestOperation *task, NSError *error){
//        
//        [self.navigationController popToRootViewControllerAnimated:YES];
//    }];
}

- (NSDictionary*)getLoginParameters
{
    return  @{@"idcard":[[GlobleData shareInfo] zipString:_userId],
              @"app_login_pwd":[[GlobleData shareInfo] zipString:_loginPwdTextField.text]
              };
}

#pragma mark - UIAlert delegate
//根据被点击按钮的索引处理点击事件
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1)
    {
        if (buttonIndex == 0)
        {
            [self login];
        }
    } else if (alertView.tag == 2) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}

#pragma mark - keyBoard
- (void)addNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)removeNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}


- (void)keyboardWillShow:(NSNotification*)notification
{
    CGRect keyboardFrame;
    [[notification.userInfo valueForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardFrame];
    keyboardFrame = [self.view convertRect:keyboardFrame toView:nil];
    
    double keyboardHeight = keyboardFrame.size.height;
    double animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[notification.userInfo valueForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    
    [[notification.userInfo valueForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    
    [UIView animateWithDuration:animationDuration
                          delay:0.0f
                        options:animationOptionsWithCurve(animationCurve)
                     animations:^{
                         
                         CGRect frame = self.scrollView.frame;
                         frame.size.height = self.view.frame.size.height - keyboardHeight;
                         self.scrollView.frame = frame;
                     }
                     completion:^(BOOL finished){
                         
                     }];
}


- (void)keyboardWillHide:(NSNotification*)notification
{
    CGRect keyboardFrame;
    [[notification.userInfo valueForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardFrame];
    keyboardFrame = [self.view convertRect:keyboardFrame toView:nil];
    
    double keyboardHeight = keyboardFrame.size.height;
    double animationDuration;
    UIViewAnimationCurve animationCurve;
    
    [[notification.userInfo valueForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    
    [[notification.userInfo valueForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    
    [UIView animateWithDuration:animationDuration
                          delay:0.0f
                        options:animationOptionsWithCurve(animationCurve)
                     animations:^{
                         
                         CGRect frame = self.scrollView.frame;
                         frame.size.height += keyboardHeight;
                         self.scrollView.frame = frame;
                     }
                     completion:^(BOOL finished){
                         
                     }];
}



static inline UIViewAnimationOptions animationOptionsWithCurve(UIViewAnimationCurve curve)
{
    UIViewAnimationOptions opt = (UIViewAnimationOptions)curve;
    return opt << 16;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}

- (void)delloc
{
    [self removeNotifications];
}

@end
