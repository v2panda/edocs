//
//  MainViewController.h
//  rry
//
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BankCard;
@class MainData;

@interface MainViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
{
    NSArray *plotDataArray;
    MainData *mainData;
}

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) BankCard *bankCard;
@property (nonatomic, strong) UIButton *leftBottomButton;
@property (nonatomic, strong) UIButton *rightBottomButton;

@end
