//
//  UserData.h
//  jkt
//
//  Created by Ren Guohua on 14-5-13.
//  Copyright (c) 2014年 ghren. All rights reserved.
//

#import "JSONModel.h"

@interface UserData : JSONModel


//@property (nonatomic, strong) NSString *totalAmount;
//@property (nonatomic, strong) NSString *yerIncom;
//@property (nonatomic, strong) NSString *manCount;
//@property (nonatomic, strong) NSString *wanIncom;
//
//@property (nonatomic, strong) NSString *totalIncom;
//@property (nonatomic, strong) NSString *weekIncom;
//@property (nonatomic, strong) NSString *monthIncom;
//@property (nonatomic, strong) NSString *userYear;
@property (nonatomic, strong) NSString *realName; //
@property (nonatomic, strong) NSString *phoneNumber;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *idcard; // 身份证

@property (nonatomic, strong) NSNumber *bank_sta;// 银行卡
@property (nonatomic, strong) NSNumber *realNameVerified; // 实名
@property (nonatomic, strong) NSNumber *emailVerified; // 邮箱
@property (nonatomic, strong) NSNumber *phoneNumberVerified; // 手机


@property (nonatomic, strong) NSNumber *userId; // 用户id


@property (nonatomic, strong) NSString *secret_key; // 密匙

@property (nonatomic, strong) NSString *idcard_img;


@end
