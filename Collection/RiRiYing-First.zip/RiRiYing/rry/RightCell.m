//
//  RightCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RightCell.h"
#import "SellDetail.h"

@implementation RightCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self initLeftTopLabel];
        [self initLeftMiddleLabel];
        [self initLeftBottomLabel];
        [self initRightTopLabel];
        [self initRightMiddleLabel];
        [self initRightBottomLabel];
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)initLeftTopLabel
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:(CGRect){15.0f,15.0f,50.0f,15.0f}];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"类型";
    if(IOS7) {
        titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    } else {
        titleLabel.font = [UIFont systemFontOfSize:13];
    }
    titleLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:titleLabel];
    
    
    _leftTopLabel = [[UILabel alloc] initWithFrame:(CGRect){70.0f,10.0f,100.0f,20.0f}];
    _leftTopLabel.backgroundColor = [UIColor clearColor];
    
    if(IOS7) {
        _leftTopLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    } else {
        _leftTopLabel.font = [UIFont systemFontOfSize:14];
    }
    _leftTopLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:_leftTopLabel];
}

- (void)initLeftMiddleLabel
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:(CGRect){15.0f,38.0f,60.0f,15.0f}];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"交易金额";
    if(IOS7) {
        titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    } else {
        titleLabel.font = [UIFont systemFontOfSize:13];
    }
    titleLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:titleLabel];
    
    
    _leftMiddleLabel = [[UILabel alloc] initWithFrame:(CGRect){70.0f,38.0f,100.0f,15.0f}];
    _leftMiddleLabel.backgroundColor = [UIColor clearColor];
    _leftMiddleLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:_leftMiddleLabel];
}
- (void)initLeftBottomLabel
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:(CGRect){15.0f,58.0f,50.0f,15.0f}];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"手续费";
    if(IOS7) {
        titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    } else {
        titleLabel.font = [UIFont systemFontOfSize:13];
    }
    titleLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:titleLabel];
    
    
    _leftBottomLabel = [[UILabel alloc] initWithFrame:(CGRect){70.0f,58.0f,100.0f,15.0f}];
    _leftBottomLabel.backgroundColor = [UIColor clearColor];
    if(IOS7) {
        _leftBottomLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    } else {
        _leftBottomLabel.font = [UIFont systemFontOfSize:13];
    }
    _leftBottomLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:_leftBottomLabel];
}


- (void)initRightTopLabel
{
    _rightTopLabel = [[UILabel alloc] initWithFrame:(CGRect){230.0f,_leftTopLabel.frame.origin.y,75.0f,_leftTopLabel.frame.size.height}];
    _rightTopLabel.backgroundColor = [UIColor clearColor];
    _rightTopLabel.textAlignment = NSTextAlignmentRight;
    
    
    _rightTopLabel.text = @"交易状态";
    _rightTopLabel.textColor = [UIColor lightGrayColor];
    if(IOS7) {
        _rightTopLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    } else {
        _rightTopLabel.font = [UIFont systemFontOfSize:13];
    }
    [self addSubview:_rightTopLabel];
}

- (void)initRightMiddleLabel
{
    _rightMiddleLabel = [[UILabel alloc] initWithFrame:(CGRect){130.0f,_leftMiddleLabel.frame.origin.y,175.0f,_leftMiddleLabel.frame.size.height}];
    _rightMiddleLabel.backgroundColor = [UIColor clearColor];
    _rightMiddleLabel.textAlignment = NSTextAlignmentRight;
    
    _rightMiddleLabel.text = @"申请通过";
    _rightMiddleLabel.textColor = [UIColor lightGrayColor];
    if(IOS7) {
        _rightMiddleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    } else {
        _rightMiddleLabel.font = [UIFont systemFontOfSize:14];
    }

    [self addSubview:_rightMiddleLabel];
}
- (void)initRightBottomLabel
{
    _rightBottomLabel = [[UILabel alloc] initWithFrame:(CGRect){150.0f,_leftBottomLabel.frame.origin.y,155.0f,_leftBottomLabel.frame.size.height}];
    _rightBottomLabel.backgroundColor = [UIColor clearColor];
    _rightBottomLabel.textAlignment = NSTextAlignmentRight;
    
    _rightBottomLabel.text = @"";
    _rightBottomLabel.textColor = [UIColor lightGrayColor];
    if(IOS7) {
        _rightBottomLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    } else {
        _rightBottomLabel.font = [UIFont systemFontOfSize:14];
    }
    [self addSubview:_rightBottomLabel];
}


/**
 *  绑定数据
 *
 *  @param data data
 */
- (void)bindData:(id)data
{
    if ([data isKindOfClass:[SellDetail class]])
    {
        SellDetail *sell = (SellDetail*)data;
        _leftTopLabel.text = @"债权名";
        
        
//        float tradeAmount = [sell.amount floatValue];
        NSString *tradString = [NSString stringWithFormat:@"%@", sell.amount];
        
        NSDictionary *attributes;
//        NSDictionary *attributes1;
        if(IOS7)
        {
          attributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0x5b3c99),NSFontAttributeName:[UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline]};
//            attributes1 = @{NSForegroundColorAttributeName:[UIColor lightGrayColor],NSFontAttributeName:[UIFont preferredFontForTextStyle:UIFontTextStyleCaption2]};
        }
        else
        {
            attributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0x5b3c99),NSFontAttributeName:[UIFont systemFontOfSize:14]};
//            attributes1 = @{NSForegroundColorAttributeName:[UIColor lightGrayColor],NSFontAttributeName:[UIFont systemFontOfSize:14]};
        }
        NSMutableAttributedString *tradAttributedString = [[NSMutableAttributedString alloc] initWithString:tradString];
        
//        [tradAttributedString addAttributes:attributes range:(NSRange){0,tradString.length - 1}];
        [tradAttributedString addAttributes:attributes range:(NSRange){0,tradString.length}];
        
//        [tradAttributedString addAttributes:attributes1 range:(NSRange){tradString.length - 1,1}];
        
        _leftMiddleLabel.attributedText = tradAttributedString;

//        float fee = [sell.fee floatValue];
        NSString *feeString = [NSString stringWithFormat:@"%@" ,sell.fee];
        _leftBottomLabel.text = feeString;
        _rightBottomLabel.text = sell.time;
        
//        if ([sell.sta isEqualToNumber:@-1])
//        {
//            _rightMiddleLabel.text = @"申请未通过";
//            _rightMiddleLabel.textColor = UIColorFromRGB(0xe04527);
//        }
//        else if ([sell.sta isEqualToNumber:@0])
//        {
//            _rightMiddleLabel.text = @"待审核";
//            _rightMiddleLabel.textColor = UIColorFromRGB(0x5b3c99);
//        }
//        else if ([sell.sta isEqualToNumber:@1])
//        {
//            _rightMiddleLabel.text = @"处理中";
//            _rightMiddleLabel.textColor = UIColorFromRGB(0x4677a5);
//        }
//        else if ([sell.sta isEqualToNumber:@2])
//        {
//            _rightMiddleLabel.text = @"已提现";
//            _rightMiddleLabel.textColor = UIColorFromRGB(0x3fa41a);
//        }
        _rightMiddleLabel.textColor = UIColorFromRGB(0xe04527);
        _rightMiddleLabel.text = sell.sta;
        if ([sell.sta isEqualToString:@"审核未通过"]) {
            _rightMiddleLabel.textColor = UIColorFromRGB(0xe04527);
            
        } else if ([sell.sta isEqualToString:@"待审核"]) {
            _rightMiddleLabel.textColor = UIColorFromRGB(0x5b3c99);
            
        } else if ([sell.sta isEqualToString:@"审核通过"]) {
            _rightMiddleLabel.textColor = UIColorFromRGB(0x3fa41a);
            
        } else if ([sell.sta isEqualToString:@"处理中"]) {
            
            _rightMiddleLabel.textColor = UIColorFromRGB(0x4677a5);
        } else if ([sell.sta isEqualToString:@"已提现"]) {
            
            _rightMiddleLabel.textColor = UIColorFromRGB(0x3fa41a);
        }
        
    }
}

@end
