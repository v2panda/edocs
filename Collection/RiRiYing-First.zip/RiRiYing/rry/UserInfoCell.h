//
//  UserInfoCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-23.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoCell : UITableViewCell

- (void)bindData:(id)data;

@end
