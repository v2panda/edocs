//
//  LeftCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *rightLabel;

- (void)bindData:(id)data;

@end
