//
//  RedeemTableViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RedeemTableViewController.h"
#import "ResetRedeemViewController.h"
#import "RedeemInputCell.h"
#import "RedeemTopCell.h"
#import "GlobleData.h"
#import "UserData.h"
#import "BankCard.h"
#import "BankCardBindViewController.h"

@interface RedeemTableViewController ()

@end

@implementation RedeemTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavigationBar];
    [self initData];
    [self registerCell];
    [self addTap];
    [self initFinishButton];
    [self initLeftBottmLabel];
    [self initRightBottomButton];
    
}
- (void)initData
{
    dataArray = @[@{@"image":@"qian.png",@"title":@"金额",@"security":@"0"},
                  @{@"image":@"mima.png",@"title":@"提现密码",@"security":@"1"}
                 ];
    [self getCardNumberFromNetwork];
}

/**
 *  从网络获取银行卡相关信息
 */
- (void)getCardNumberFromNetwork
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    [sessionManager GET:@"GetCardNumber" parameters:[self getCardNumParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/member/getBankInfo"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getCardNumParameters]  path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                dataDic = dic[@"data"];
                if ([dataDic[@"sta"] intValue] == 0 || [dataDic[@"sta"] intValue] == -1) {
                    BankCardBindViewController *banVC = [[BankCardBindViewController alloc] init];
                    [self.navigationController pushViewController:banVC animated:YES];
                }
                [self.tableView reloadData];
            }
            else
            {
                
            }
        }
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
}

/**
 *  得到从网络获取银行卡信息时 需要的http参数
 *
 *  @return http请求参数
 */
- (NSDictionary*)getCardNumParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
//    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//              };
    return  @{@"user_id":[userData.userId stringValue],
              };
}
/**
 *  注册tableView 的cell
 */
- (void)registerCell
{
    [self.tableView registerClass:[RedeemInputCell class] forCellReuseIdentifier:@"RedeemInputCell"];
    
    [self.tableView registerClass:[RedeemTopCell class] forCellReuseIdentifier:@"RedeemTopCell"];
}
/**
 *  设置导航栏
 */
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"赎回";
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
/**
 *  导航栏左边按钮点击事件
 *
 *  @param sender
 */
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  初始化确认按钮
 */
- (void)initFinishButton
{
    _finishButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _finishButton.frame = CGRectInset(CGRectMake(0.0f, 280.0f, 320.0f, 44.0f), 20.0f, 5.0f);
    
    _finishButton.backgroundColor = UIColorFromRGB(0xe1412b);
    _finishButton.tintColor = UIColorFromRGB(0xffffff);
    _finishButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_finishButton setTitle:@"确认" forState:UIControlStateNormal];
    [_finishButton addTarget:self action:@selector(finishButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _finishButton.layer.cornerRadius = 3.0f;
    
    [self.tableView addSubview:_finishButton];
}

/**
 *  确认按钮点击事件
 *
 *  @param sender
 */

- (void)finishButtonClicked:(id)sender
{
    [_textField resignFirstResponder];
    
    if ([self inputIsIlligal])
    {
        return;
    }
    [self getDataFromNetwork];
    
}


- (void)initLeftBottmLabel
{
    _leftBottomLabel = [[UILabel alloc]initWithFrame:(CGRect){10.0f,250.0f,180.0f,20.0f}] ;
    _leftBottomLabel.text = @"预计一个工作日内到账";
    _leftBottomLabel.backgroundColor  = [UIColor clearColor];
    if(IOS7)
        _leftBottomLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    _leftBottomLabel.textColor = [UIColor lightGrayColor];
    [self.tableView addSubview:_leftBottomLabel];
}

/**
 *  初始化忘记密码按钮
 */
- (void)initRightBottomButton
{
    _rightBottomButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightBottomButton.frame = (CGRect){220.0f,250.0f,90.0f,20.0f};
    
    NSDictionary *attributes;
    if(IOS7)
    {
       attributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0xe04527),NSFontAttributeName:[UIFont preferredFontForTextStyle:UIFontTextStyleCaption2],NSUnderlineStyleAttributeName:[NSNumber numberWithInteger:NSUnderlineStyleSingle]};
    }
    else
    {
        attributes = @{NSForegroundColorAttributeName:UIColorFromRGB(0xe04527),NSFontAttributeName:[UIFont systemFontOfSize:12],NSUnderlineStyleAttributeName:[NSNumber numberWithInteger:NSUnderlineStyleSingle]};
    }
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:@"忘记提现密码?" attributes:attributes];
    [_rightBottomButton setAttributedTitle:attributedString forState:UIControlStateNormal];
    [_rightBottomButton addTarget:self action:@selector(rightBottomButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.tableView addSubview:_rightBottomButton];
}

/**
 *  忘记密码按钮点击事件
 *
 *  @param sender
 */
- (void)rightBottomButtonClicked:(id)sender
{
    ResetRedeemViewController *resetRedeemViewController = [[ResetRedeemViewController alloc] init];
    [self.navigationController pushViewController:resetRedeemViewController animated:YES];
}

/**
 *  赎回申请
 */
- (void)getDataFromNetwork
{
    UIAlertView *loadingAlert=[[UIAlertView alloc] initWithTitle:@"正在申请..." message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:nil,nil];
    loadingAlert.alertViewStyle=UIAlertViewStyleDefault;
    [loadingAlert show];
    //zzzili14
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    [sessionManager.requestSerializer setTimeoutInterval:20.0];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *parameters = [self getParameters];
    NSLog(@"%@",parameters);
//    [sessionManager POST:@"Withdraw" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/money/withdraw"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:parameters path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
    
        [loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@",dic);
        if (dic) {
            if ([dic[@"sta"] intValue] == 1)
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"您的赎回申请已经提交，请耐心等待处理" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                alert.tag = 1;
                [alert show];
            }
            else
            {
                NSLog([dic objectForKey:@"msg"]);
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"申请失败" message:[dic objectForKey:@"msg"] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }

        }
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        [loadingAlert dismissWithClickedButtonIndex:0 animated:NO];
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
}

/**
 *   得到赎回申请的http请求参数
 *
 *  @return http请求参数
 */
- (NSDictionary*)getParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    
    if ([dataDic[@"card_number"] isEqual:[NSNull null]])
    {
        return nil;
    }
    
    NSString *cardNumber = dataDic[@"card_number"];
    if (cardNumber.length <= 0 )
    {
        return nil;
    }
    
//    NSLog(@"%@",[userData.userId stringValue]);
//    NSLog(@"%@",cardNumber);
//    NSLog(@"%@",[NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:0 inSection:1]]]);
//    NSLog(@"%@",[NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]]]);
//    
//    NSString *string = [NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]]];
//    NSLog(string);
//    string = [[GlobleData shareInfo] zipString:string];
//    string = [[GlobleData shareInfo] unZipString:string];
//    NSLog(string);
    //[[GlobleData shareInfo] zipString:cardNumber]
    
//    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//              @"bank_id_s":cardNumber,
//              @"amount_s":[[GlobleData shareInfo] zipString:[NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:0 inSection:1]]]],
//              @"trade_pwd":[[GlobleData shareInfo] zipString:[NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]]]]
//              };
    
    return  @{@"user_id":[userData.userId stringValue],
//              @"bank_id":cardNumber,
              @"amount":[NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:0 inSection:1]]],
              @"trade_pwd":[NSString stringWithString:_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]]]
              };

}

/**
 *  网络访问之前判断是否满足网络访问的条件，包括参数是否合法，网络是否正常等
 *
 *  @return YES － 非法 NO - 合法
 */
- (BOOL)inputIsIlligal
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(((NSString*)_cellStringDic[[NSIndexPath indexPathForRow:0 inSection:1]]).length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入金额" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(((NSString*)_cellStringDic[[NSIndexPath indexPathForRow:1 inSection:1]]).length <= 0)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入提现密码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if( [dataDic[@"card_number"] isEqual:[NSNull null]] ||  ((NSString*)dataDic[@"card_number"]).length <= 0 )
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"未查找到绑定银行卡" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


/**
 *  增加点击按钮
 */
- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.view addGestureRecognizer:tap];
}

/**
 *  点击事件
 *
 *  @param recognizer 
 */
-(void)tap:(UIGestureRecognizer *)recognizer
{
    [_textField resignFirstResponder];
}


#pragma UIAlert delegate
//根据被点击按钮的索引处理点击事件
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (alertView.tag == 1)
    {
        if (buttonIndex == 0)
        {
            
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 1;
    }
    return [dataArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        RedeemTopCell *cell = (RedeemTopCell*)[tableView dequeueReusableCellWithIdentifier:@"RedeemTopCell" forIndexPath:indexPath];
        
        [cell bindData:dataDic];
        return cell;
    }
    
    RedeemInputCell *cell = (RedeemInputCell*)[tableView dequeueReusableCellWithIdentifier:@"RedeemInputCell" forIndexPath:indexPath];
    cell.saveInputString = ^(NSString *cellString){
        
        if (_cellStringDic == nil)
        {
            _cellStringDic = [NSMutableDictionary dictionary];
        }
        _cellStringDic[indexPath] = cellString;
    };
    
    cell.delegate = self;
    [cell bindInput:_cellStringDic[indexPath]];
    [cell bindData:dataArray[indexPath.row]];
    return cell;
}

#pragma mark - Table view data delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        return 80.0f;
    }
    return 44.0f;
}

@end
