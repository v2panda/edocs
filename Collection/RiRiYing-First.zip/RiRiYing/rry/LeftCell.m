//
//  LeftCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "LeftCell.h"
#import "BuyDetail.h"

@implementation LeftCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self initRightLabel];
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)initRightLabel
{
    _rightLabel = [[UILabel alloc] initWithFrame:(CGRect){150.0f,0.0f,150.0f,44.0f}];
    _rightLabel.backgroundColor = [UIColor clearColor];
    _rightLabel.textAlignment = NSTextAlignmentRight;
    _rightLabel.font = [UIFont systemFontOfSize:13];
    self.accessoryView = _rightLabel;
}
- (void)bindData:(id)data
{
    
//    self.textLabel.text = @"债权名";
//    self.textLabel.textColor = UIColorFromRGB(0xe04527);
//    if(IOS7)
//        self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
//    if ([data isKindOfClass:[BuyDetail class]])
//    {
//        BuyDetail *buy = (BuyDetail*)data;
//        self.detailTextLabel.text = buy.time;
//        self.detailTextLabel.textColor = [UIColor lightGrayColor];
//        
//        self.rightLabel.text = [buy.amount stringValue];
//    }
    
    if(IOS7)
        self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    if ([data isKindOfClass:[BuyDetail class]])
    {
        BuyDetail *buy = (BuyDetail*)data;
        self.rightLabel.text = buy.invest_time;
        
        self.textLabel.text = [NSString stringWithFormat:@"%@", buy.name];
        self.textLabel.textColor = UIColorFromRGB(0xe04527);
        
        self.detailTextLabel.text = buy.amount;
        self.detailTextLabel.textColor = [UIColor lightGrayColor];
        
    }

}

@end
