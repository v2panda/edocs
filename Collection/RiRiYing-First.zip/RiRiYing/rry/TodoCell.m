//
//  TodoCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "TodoCell.h"

@implementation TodoCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self initHintLabel];
        [self initTitleLabel];
        [self initSubtitleLabel];
        [self initHintView];
        
        
    }
    return self;
}

- (void)initHintLabel
{
    _hintLabel = [[UILabel alloc] initWithFrame:(CGRect){15.0f, 19.0f,35.0f,17.0f}];
    _hintLabel.layer.cornerRadius = 3.0f;
    _hintLabel.layer.masksToBounds = YES;
    _hintLabel.textAlignment = NSTextAlignmentCenter;
    if(IOS7)
        _hintLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
    else
        _hintLabel.font = [UIFont systemFontOfSize:10];
    [self addSubview:_hintLabel];
}
- (void)initTitleLabel
{
    _titleLabel =  [[UILabel alloc] initWithFrame:(CGRect){CGRectGetMaxX(_hintLabel.frame)+5.0f, 17.0f,200.0f,20.0f}];;
    if(IOS7)
        _titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    else
        _titleLabel.font = [UIFont systemFontOfSize:14];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.textColor = [UIColor blackColor];
    [self addSubview:_titleLabel];
}

- (void)initSubtitleLabel
{
    _subTitleLabel =  [[UILabel alloc] initWithFrame:(CGRect){15.0f, 44.0f,230.0f,15.0f}];
    if(IOS7)
       _subTitleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    else
       _subTitleLabel.font = [UIFont systemFontOfSize:14];
    _subTitleLabel.backgroundColor = [UIColor clearColor];
    _subTitleLabel.textColor = [UIColor lightGrayColor];
    [self addSubview:_subTitleLabel];

    _errorMsg =  [[UILabel alloc] initWithFrame:(CGRect){15.0f, 44+20.0f,230.0f,15.0f}];
    if(IOS7)
        _errorMsg.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    else
        _errorMsg.font = [UIFont systemFontOfSize:14];
    _errorMsg.backgroundColor = [UIColor clearColor];
//    _errorMsg.numberOfLines = 0;
    _errorMsg.textColor = [UIColor redColor];
    [self addSubview:_errorMsg];
    
}

- (void)initHintView
{
    _hintView = [[UIImageView alloc] initWithFrame:CGRectInset((CGRect){250.0f,0.0f,50.0f,72.0f}, 6.5f, 21.0f)];
    [self addSubview:_hintView];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

/**
 *  绑定数据
 *
 *  @param data 绑定数据
 */
- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.titleLabel.text = dic[@"title"];
        self.subTitleLabel.text = dic[@"detail"];
        self.errorMsg.text = dic[@"error_msg"];
//        if ([dic[@"done"] isEqualToString:@"1"])
//        {
//            self.hintView.image = [UIImage imageNamed:@"duihao.png"];
//            self.hintLabel.text = @"完成";
//            self.hintLabel.backgroundColor = UIColorFromRGB(0x35a51d);
//        }
//        else if([dic[@"done"] isEqualToString:@"-1"])
//        {
//            self.hintView.image = nil;
//            self.hintLabel.text = @"审核中";
//            self.hintLabel.backgroundColor = UIColorFromRGB(0xa8a8a8);
//        }
//        else
//        {
//            self.hintView.image = nil;
//            self.hintLabel.text = @"待办";
//            self.hintLabel.backgroundColor = UIColorFromRGB(0xa8a8a8);
//        }
        if ([dic[@"done"] isEqualToString:@"1"])
        {
            self.hintView.image = [UIImage imageNamed:@"duihao.png"];
            self.hintLabel.text = @"已认证";
            self.hintLabel.backgroundColor = UIColorFromRGB(0x35a51d);
        }
        else if([dic[@"done"] isEqualToString:@"-1"])
        {
            self.hintView.image = nil;
            self.hintLabel.text = @"未通过";
            self.hintLabel.backgroundColor = UIColorFromRGB(0xa8a8a8);
        }
        else if([dic[@"done"] isEqualToString:@"0"])
        {
            self.hintView.image = nil;
            self.hintLabel.text = @"未认证";
            self.hintLabel.backgroundColor = UIColorFromRGB(0xa8a8a8);
        }
        else if([dic[@"done"] isEqualToString:@"2"])
        {
            self.hintView.image = nil;
            self.hintLabel.text = @"待审核";
            self.hintLabel.backgroundColor = UIColorFromRGB(0xa8a8a8);
        }
//        else
//        {
//            self.hintView.image = nil;
//            self.hintLabel.text = @"待办";
//            self.hintLabel.backgroundColor = UIColorFromRGB(0xa8a8a8);
//        }

    }
}

@end
