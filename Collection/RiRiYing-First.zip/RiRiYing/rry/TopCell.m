//
//  TopCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "TopCell.h"
#import "UserData.h"
#import "GlobleData.h"
#import "MainData.h"

@implementation TopCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self setBackgroundColor:UIColorFromRGB(0xe1412b)];
        [self initLeftTopLabel];
        [self initMiddleLabel];
//        [self initRightBottomLabel];
    }
    return self;
}


- (void)initLeftTopLabel
{
    _leftTopLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, 27.0f, 200.0f, 15.0f)];
    _leftTopLabel.textColor = [UIColor whiteColor];
    _leftTopLabel.backgroundColor = [UIColor clearColor];
    _leftTopLabel.font = [UIFont systemFontOfSize:15.0f];
    [self addSubview:_leftTopLabel];
}

- (void)initMiddleLabel
{
    _middleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, 58.0f, 200.0f, 55.0f)];
    _middleLabel.backgroundColor = [UIColor clearColor];
    _middleLabel.textColor = [UIColor whiteColor];
    _middleLabel.font = [UIFont boldSystemFontOfSize:57.0f];
    [self addSubview:_middleLabel];
}

- (void)initRightBottomLabel
{
    _rightBottomLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, 110.0f, 290.0f, 13.0f)];
    _rightBottomLabel.backgroundColor = [UIColor clearColor];
    _rightBottomLabel.textAlignment = NSTextAlignmentRight;
 
    _rightBottomLabel.font = [UIFont systemFontOfSize:13.0f];
    [self addSubview:_rightBottomLabel];
    
}

/**
 *  绑定数据
 *
 *  @param data
 */
- (void)bindData:(id)data
{
    _leftTopLabel.text = @"昨日收益(元)";
    
    if ([data isKindOfClass:[MainData class]])
    {
        MainData *mainData = (MainData*)data;
        NSLog(@"%@",mainData);
        if ([mainData.yerIncom isEqualToString:@""] || mainData.yerIncom == nil)
        {
            _middleLabel.text = @"0.00";
        }
        else
        {
            _middleLabel.text = mainData.yerIncom;
        }
        
        if ([mainData.manCount isEqualToString:@""] || mainData.manCount == nil)
        {
             _rightBottomLabel.text = [NSString stringWithFormat:@"您的收益已经战胜0人"];
        }
        else
        {
            _rightBottomLabel.text = [NSString stringWithFormat:@"您的收益已经战胜%ld人",(long)[mainData.manCount integerValue]];
        }
    }
    else
    {
        _middleLabel.text = @"0.00";
        _rightBottomLabel.text = [NSString stringWithFormat:@"您的收益已经战胜0人"];
    
    }
}

@end
