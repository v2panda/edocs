//
//  RightCell.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightCell : UITableViewCell

- (void)bindData:(id)data;
@property (nonatomic, strong) UILabel *leftTopLabel;
@property (nonatomic, strong) UILabel *leftMiddleLabel;
@property (nonatomic, strong) UILabel *leftBottomLabel;

@property (nonatomic, strong) UILabel *rightTopLabel;
@property (nonatomic, strong) UILabel *rightMiddleLabel;
@property (nonatomic, strong) UILabel *rightBottomLabel;

@end
