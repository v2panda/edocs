//
//  PhoneCheckFooterView.h
//  rry
//
//  Created by Ren Guohua on 14-6-30.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^ClickeButon)();

@interface PhoneCheckFooterView : UIView
{
    ClickeButon clickCheckEvent;
}

@property (nonatomic, strong) UIButton *checkButton;

- (void)configCheckButtonEvent:(ClickeButon)clickButtonClock;

@end
