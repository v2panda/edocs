//
//  UserAvatarCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "UserAvatarCell.h"

@implementation UserAvatarCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.accessoryType  = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.imageView.image = [UIImage imageNamed:dic[@"image"]];
        self.textLabel.text = dic[@"title"];
        self.detailTextLabel.text = dic[@"subTitle"];
        self.detailTextLabel.textColor = UIColorFromRGB(0x989898);
    }
}

@end
