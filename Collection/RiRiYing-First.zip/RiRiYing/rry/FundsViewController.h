//
//  FundsViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SelectFundsType.h"

@class ArrayDataSource;

@interface FundsViewController : UIViewController<UITableViewDelegate,zzSelectFundsTypeDelegate>
{

    NSMutableArray *dataArray;
    ArrayDataSource *dataSource;
    
    UITextField *hasNoneDataText;
}

@property (nonatomic, strong) UISegmentedControl *segment;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSString *type;

@end
