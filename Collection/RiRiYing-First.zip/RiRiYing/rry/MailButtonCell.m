//
//  MailButtonCell.m
//  rry
//
//  Created by Ren Guohua on 14-6-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "MailButtonCell.h"

@implementation MailButtonCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.textLabel.text = @"验证邮箱";
        self.textLabel.textColor = UIColorFromRGB(0x08b2f0);
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
