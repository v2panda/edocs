//
//  LoginViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-13.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "LoginViewController.h"
#import "RegViewController.h"
#import "UserCenterViewController.h"
#import "MainViewController.h"
#import "AFNetworking.h"
#import "GlobleData.h"
#import "ResetPwdViewController.h"
#import "GesturePwdViewController.h"
#import "MBProgressHUD.h"
#import "GesturePwdViewAnimation.h"
#import "NSString+XXTEA.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

-(NSString*)URLdecode1:(NSString*)originalString stringEncoding:(NSStringEncoding)stringEncoding
{
    NSArray *escapeChars = [NSArray arrayWithObjects:@"%3B" , @"%2F", @"%3F" , @"%3A" , @"%40" , @"%26" , @"%3D" , @"%2B" , @"%24" , @"%2C" ,@"%21", @"%27", @"%28", @"%29", @"%2A", nil];
    NSArray *replaceChars = [NSArray arrayWithObjects:@";", @"/" , @"?" , @":",@"@" , @"&" , @"=" , @"+" ,@"$", @",",@"!", @"'", @"(", @")", @"*", nil];
    int len =[escapeChars count];
    NSMutableString *temp = [originalString  mutableCopy];
    int i;
    for(i = 0; i < len; i++)
    {
        [temp replaceOccurrencesOfString:[escapeChars objectAtIndex:i] withString:[replaceChars objectAtIndex:i] options:NSLiteralSearch range:NSMakeRange(0, [temp length])];
    }
    NSString *outStr = [NSString stringWithString:temp];
    return outStr;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyview];
    [self setNavigationBar];
    [self initUserNameTextField];
    [self initPwdTextField];
    [self initLoginButton];
    [self initForgetPwdButton];
//    [self initVersionLabel];
    [self addTap];
}

- (void)setMyview
{
    self.view.backgroundColor = UIColorFromRGB(0xf7f7f7);
}
- (void)setNavigationBar
{
    [self.navigationItem setHidesBackButton:YES];
    
    self.navigationItem.title = @"日日盈";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
       self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setFrame:CGRectMake(0.0f, 0.0f, 44.0f, 32.0f)];

    [rightButton setTitle:@"注册" forState:UIControlStateNormal];
    [rightButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rightButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
    rightButton.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [rightButton addTarget:self action:@selector(rightButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    
    self.navigationItem.rightBarButtonItem = rightButtonItem;
    
    
}

- (void)rightButtonClicked:(id)sender
{
    
    RegViewController *regVC =[[RegViewController alloc] init];
    [self.navigationController pushViewController:regVC animated:YES];
}


- (void)initVersionLabel
{
    _versionLabel = [[UILabel alloc] initWithFrame:(CGRect){
    
        .origin.x = 0.0f,
        .origin.y = CGRectGetHeight(self.view.frame) - 44.0f - 64.0f,
        .size.width = 320.0f,
        .size.height = 44.0f
    }];
    
    //NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];

    // app版本
    //NSString *appVersion = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    _versionLabel.backgroundColor = [UIColor clearColor];
    _versionLabel.text = versionStr;//[NSString stringWithFormat:@"V%@",appVersion];
    if(IOS7)
    {
      _versionLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    }
    _versionLabel.textAlignment = NSTextAlignmentCenter;
    _versionLabel.textColor = UIColorFromRGB(0xff0000);

    [self.view addSubview:_versionLabel];
}

/**
 *  输入用户名
 */
- (void)initUserNameTextField
{
    _userNameTextField    = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 15.0f, 320.0f, 44.0f)];
    UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image        = [UIImage imageNamed:@"pic_sfz.png"];
    if(IOS7)
    {
        leftView.image        = [leftView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        leftView.tintColor    = UIColorFromRGB(0x909090);
    }
    
    _userNameTextField.leftView        = leftView;
    _userNameTextField.leftViewMode    = UITextFieldViewModeAlways;
    _userNameTextField.borderStyle     = UITextBorderStyleRoundedRect;
    _userNameTextField.delegate        = self;
    _userNameTextField.placeholder     = @"请输入身份证号码";
    _userNameTextField.keyboardType    = UIKeyboardTypeAlphabet;
    _userNameTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _userNameTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
//    _userNameTextField.text = @"510723197801231912";
//    _userNameTextField.text = @"640121198505125611";
//     _userNameTextField.text = @"410203196902158362";
//    _userNameTextField.text = @"360428198608140017";
//    _userNameTextField.text = @"350583198704257723";
    
    [self.view addSubview:_userNameTextField];
    
    NSString *userName = [[NSUserDefaults standardUserDefaults] objectForKey:@"userName"];
    if (userName != nil)
    {
        _userNameTextField.text = userName;
    }
    
}
/**
 *  输入密码
 */

- (void)initPwdTextField
{
    _pwdTextField         = [[UITextField alloc] initWithFrame:CGRectOffset(_userNameTextField.frame, 0.0f, 43.0f)];
    UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    leftView.image        = [UIImage imageNamed:@"mima.png"];

    _pwdTextField.leftView        = leftView;
    _pwdTextField.leftViewMode    = UITextFieldViewModeAlways;
    _pwdTextField.borderStyle     = UITextBorderStyleRoundedRect;
    _pwdTextField.delegate        = self;
    _pwdTextField.secureTextEntry = YES;
    _pwdTextField.placeholder     = @"请输入密码";
    _pwdTextField.keyboardType    = UIKeyboardTypeAlphabet;
//    _pwdTextField.text = @"123456";
    _pwdTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [self.view addSubview:_pwdTextField];
}

/**
 *  忘记密码按钮
 */
- (void)initForgetPwdButton
{
    _forgetPwdButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _forgetPwdButton.frame = (CGRect){250.0f, CGRectGetMaxY(_pwdTextField.frame) + 16.0f, 60.0f, 15.0f} ;
    
    [_forgetPwdButton setTitleColor:RGB(179, 184, 188) forState:UIControlStateNormal];
    _forgetPwdButton.titleLabel.font = [UIFont systemFontOfSize:13.0f];
    
    [_forgetPwdButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
    [_forgetPwdButton addTarget:self action:@selector(forgetPwdButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:_forgetPwdButton];
}

/**
 *  忘记密码按钮点击事件
 *
 *  @param sender
 */

- (void)forgetPwdButtonClicked:(id)sender
{
    ResetPwdViewController *resetViewController = [[ResetPwdViewController alloc] init];
    [self.navigationController pushViewController:resetViewController animated:YES];
}

/**
 *  登录按钮
 */
- (void)initLoginButton
{
    _loginButton                    = [UIButton buttonWithType:UIButtonTypeCustom];
    _loginButton.frame              = CGRectInset(CGRectOffset(_pwdTextField.frame, 0.0f, 89.0f), 20.0f, 5.0f) ;

    _loginButton.backgroundColor    = UIColorFromRGB(0xb3b8bc);
    _loginButton.tintColor          = UIColorFromRGB(0xffffff);
    _loginButton.titleLabel.font    = [UIFont systemFontOfSize:21.0f];

    [_loginButton setTitle:@"登 录" forState:UIControlStateNormal];
    [_loginButton addTarget:self action:@selector(loginButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _loginButton.layer.cornerRadius = 3.0f;
    _loginButton.enabled            = NO;

    [self.view addSubview:_loginButton];
}

/**
 *  使能登录按钮
 */
- (void)setLoginButtonEnable
{
    _loginButton.enabled = YES;
    _loginButton.backgroundColor = UIColorFromRGB(0x2fb610);
}
/**
 *  去使能登录按钮
 */
- (void)setLoginButtonUnable
{
    _loginButton.enabled = NO;
    _loginButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
}

/**
 *  登录按钮点击事件
 *
 *  @param sender
 */
- (void)loginButtonClicked:(id)sender
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
    if ([self inputIsIlligal])
    {
        return;
    }
    [self login] ;
}

/**
 *  登录
 */
- (void)login
{
    
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:hud];
	hud.detailsLabelText = @"正在登录...";
    hud.square = YES;
    [hud show:YES];

    
    NSDictionary *dic = @{@"username": _userNameTextField.text, @"pwd":_pwdTextField.text};
    
    NSURL *url = [[GlobleData shareInfo] encrytUrlWithParam:dic path:@"login"];
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    NSDictionary *dic = [self getParameters];
    
//    [sessionManager POST:@"LoginUser" parameters:dic success:^(AFHTTPRequestOperation *task, id responseObject){
//    [sessionManager POST:@"" parameters:nil success:^(AFHTTPRequestOperation *task, id responseObject){
//    [sessionManager POST:@"" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:dic path:@"login"] success:^(AFHTTPRequestOperation *task, id responseObject){
    if (![GlobleData shareInfo].key) {
        [GlobleData shareInfo].key = [GlobleData createRandomKey];
    }
    
    
        [sessionManager POST:@"api/login/index"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:dic path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
    
        NSLog(@"%@", task.request.URL);
        [hud hide:YES];
         
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
         
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
            if (dic) {
                if ([dic[@"sta"] isEqualToNumber:@1] )
                {
                    [GlobleData shareInfo].key = dic[@"data"][@"encrypt_key"];
                    
                    
                    [[NSUserDefaults standardUserDefaults] setObject:responseObject forKey:@"userData"];
                    [[NSUserDefaults standardUserDefaults] setObject:_userNameTextField.text forKey:@"userName"];
                    //            [[NSUserDefaults standardUserDefaults] setObject:_pwdTextField.text forKey:@"zzuserPass"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    _userNameTextField.text =@"";
                    _pwdTextField.text = @"";
                    MainViewController *mainVC = [[MainViewController alloc] init];
                    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:mainVC];
                    GesturePwdViewController *gestureVC = [[GesturePwdViewController alloc] init];
                    if(IOS7)
                    {
                        gestureVC.transitioningDelegate = gestureVC;
                    }
                    gestureVC.parentController = self;
                    
                    if (_isHomePage)
                    {
                        [self presentViewController:nav animated:NO completion:^{
                            
                            [nav presentViewController:gestureVC animated:NO completion:nil];
                        }];
                    }
                    else
                    {
                        if ([self.delegate isKindOfClass:[UserCenterViewController class]])
                        {
                            UserCenterViewController *userCenterVC = (UserCenterViewController*)self.delegate;
                            UINavigationController *userNav = userCenterVC.navigationController;
                            [userNav popToRootViewControllerAnimated:NO];
                            
                            [self.navigationController dismissViewControllerAnimated:NO completion:^{
                                
                                [userNav presentViewController:gestureVC animated:NO completion:nil];
                            }];
                        }
                        else if ([self.delegate isKindOfClass:[GesturePwdViewController class]])
                        {
                            //                    GesturePwdViewController *userCenterVC = (GesturePwdViewController*)self.delegate;
                            //                    UINavigationController *userNav = userCenterVC.navigationController;
                            //[self.navigationController pushViewController:gestureVC animated:NO];
                            
                            //                    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"gesturePwd"];
                            //                    [[NSUserDefaults standardUserDefaults]synchronize];
                            
                            [self.navigationController presentViewController:gestureVC animated:NO completion:nil];
                            [self.navigationController popViewControllerAnimated:NO];
                        }
                    }
                }
                else
                {
                    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                    alert.alertViewStyle=UIAlertViewStyleDefault;
                    [alert show];
                }

            }
            
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
//        NSLog([error localizedDescription]);
        [hud hide:YES];
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        
     }];
}

- (NSDictionary*)getParameters
{
    if (_userNameTextField.text == nil)
    {
        return nil;
    }
    
    if (_pwdTextField.text == nil)
    {
        return nil;
    }
    return  @{@"idcard":[[GlobleData shareInfo] zipString:_userNameTextField.text],
              @"app_login_pwd":[[GlobleData shareInfo] zipString:_pwdTextField.text]
              };
}

- (BOOL)inputIsIlligal
{
    if(![[GlobleData shareInfo] idNumberIsvalidWithString:_userNameTextField.text])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请输入正确身份证号码" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if(_pwdTextField.text.length < 6)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"密码至少为6位" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}



#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.frame.origin.y+textField.frame.size.height > self.view.frame.size.height -216.0f-22.0f)
    {
        CGFloat offY = (self.view.frame.size.height-216.0f)-textField.frame.size.height-textField.frame.origin.y-22.0f;//屏幕总高度-键盘高度-UITextField高度
        [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
        [UIView setAnimationDuration:0.3];//设置动画时间 秒为单位
        self.view.frame = CGRectMake(self.view.frame.origin.x, offY-44.0f, self.view.frame.size.width, self.view.frame.size.height);//UITextField位置的y坐标移动到offY
        [UIView commitAnimations];//开始动画效果
    }
    else
    {
        [self recoverFrame];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        [self recoverFrame];
        return NO;
    }
    if (textField == _userNameTextField)
    {
        if ((range.location > 17 ||textField.text.length > 17) && string.length > 0)
        {
            return NO;
        }
         NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (toBeString.length > 14 && _pwdTextField.text.length > 5)
        {
            [self setLoginButtonEnable];
        }
        else
        {
            [self setLoginButtonUnable];
        }
        if ([string isEqualToString:@"x"])
        {
            textField.text = [NSString stringWithFormat:@"%@X",textField.text];
            return NO;
        }
    }
    if (textField == _pwdTextField)
    {
         NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (toBeString.length > 5 && _userNameTextField.text.length > 14)
        {
            [self setLoginButtonEnable];
        }
        else
        {
            [self setLoginButtonUnable];
        }
    }
    return YES;
}

-(void)recoverFrame
{
    [UIView beginAnimations:nil context:NULL];//此处添加动画，使之变化平滑一点
    [UIView setAnimationDuration:0.3];
    //UITextField位置复原
    
    self.view.frame = CGRectMake(0.0f,self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height);
    [UIView commitAnimations];
}


- (void)addTap
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.view addGestureRecognizer:tap];
}

-( void)tap:(UIGestureRecognizer *)recognizer
{
    [self makeKeyBoardMiss];
    [self recoverFrame];
}

- (void)makeKeyBoardMiss
{
    for (id textField in [self.view subviews])
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            UITextField *theTextField = (UITextField*)textField;
            [theTextField resignFirstResponder];
        }
    }
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}


@end
