//
//  NSArray+Compare.m
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "NSArray+Compare.h"

@implementation NSArray (Compare)

- (NSNumber*)getMaxItem
{

    NSComparator cmptr = ^(id obj1, id obj2){
        if ([obj1 floatValue] > [obj2 floatValue]) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        
        if ([obj1 floatValue] < [obj2 floatValue]) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    };
    
    NSArray *resultArray = [self sortedArrayUsingComparator:cmptr];
    
    NSNumber *max = [resultArray lastObject];
    
    return max;
}

- (NSNumber*)getMinItem
{
    NSComparator cmptr = ^(id obj1, id obj2){
        if ([obj1 floatValue] > [obj2 floatValue]) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        
        if ([obj1 floatValue] < [obj2 floatValue]) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    };
    
    NSArray *resultArray = [self sortedArrayUsingComparator:cmptr];
    
    NSNumber *min = [resultArray firstObject];
    
    return min;
}
@end
