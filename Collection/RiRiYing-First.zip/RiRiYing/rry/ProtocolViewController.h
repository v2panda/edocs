//
//  ProtocolViewController.h
//  rry
//
//  Created by dld on 14-9-25.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProtocolViewController : UIViewController

@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) UIWebView *webView;

@end
