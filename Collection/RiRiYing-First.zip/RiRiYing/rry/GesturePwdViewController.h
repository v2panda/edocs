//
//  GesturePwdViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-27.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KKGestureLockView.h"

@class  FBShimmeringView;

@interface GesturePwdViewController : UIViewController<KKGestureLockViewDelegate,UIViewControllerTransitioningDelegate>
{
    NSInteger setCount;
    NSInteger inputCount;
    NSString *gestureString;
    int entErrorNum;
    BOOL isCheckOldPassOk;
}

@property (retain,nonatomic) UIViewController *parentController;

@property (nonatomic, assign) BOOL isChangePW;
@property (nonatomic, strong) KKGestureLockView *lockView;
@property (nonatomic, strong) UIImageView *bgView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) FBShimmeringView *shimmeringView;
@property (nonatomic, strong) CABasicAnimation *bgAnimation;

@end
