//
//  HelpViewController.h
//  rry
//
//  Created by Ren Guohua on 14-6-5.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpViewController : UITableViewController
{
    NSMutableArray *dataArray;
}

@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) UILabel *hintLabel;

@end
