//
//  UserInfoCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-23.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "UserInfoCell.h"

@implementation UserInfoCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
    }
    return self;
}

- (void)awakeFromNib
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.textLabel.text = dic[@"title"];
        if(IOS7)
        {
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
            self.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        }
        self.detailTextLabel.text = dic[@"subTitle"];
        
        
        if (dic[@"avatar"] != nil)
        {
            UIImageView *avatarView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:dic[@"avatar"]]];
            self.accessoryView = avatarView;
        }
    }

}

@end
