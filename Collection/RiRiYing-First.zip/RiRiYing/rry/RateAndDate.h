//
//  RateAndDate.h
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "JSONModel.h"

@interface RateAndDate : JSONModel

@property (nonatomic, strong) NSString *day;
@property (nonatomic, strong) NSString *rate;

@end
