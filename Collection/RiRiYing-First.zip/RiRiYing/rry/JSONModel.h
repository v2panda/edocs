//
//  ModelBase.h
//  Steinlogic
//
//  Created by Mugunth Kumar on 26-Jul-10.
//  Copyright 2011 Steinlogic All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONModel : NSObject <NSCoding, NSCopying, NSMutableCopying> {

}
/**
 *  从字典转换为对象
 *
 *  @param jsonObject 字典
 *
 *  @return 返回对象
 */
-(id) initWithDictionary:(NSMutableDictionary*) jsonObject;

@end
