//
//  MailCheckInputCell.h
//  rry
//
//  Created by Ren Guohua on 14-6-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SaveInputString)(NSString *cellString);

@interface MailCheckInputCell : UITableViewCell<UITextFieldDelegate>
{
    NSTimer *verifyTimer;
    NSInteger verifiedTime;
}

- (void)bindData:(id)data;
- (void)bindInput:(NSString*)inputString;

@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) id delegate;
@property (nonatomic, strong) SaveInputString saveInputString;

@property (nonatomic, strong) UIButton *getVerifiedCodeButton;
@property (nonatomic, strong) UILabel *verifiedRightLabel;

@property (nonatomic, strong) NSString *emailString;
@property (nonatomic, strong) NSString *verifiedCode;

@property (nonatomic, strong) NSIndexPath *index;

@end
