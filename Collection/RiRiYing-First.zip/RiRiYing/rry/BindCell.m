//
//  BindCel.m
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "BindCell.h"

@implementation BindCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}


- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.imageView.image = [UIImage imageNamed:dic[@"image"]];
        self.textLabel.text = dic[@"title"];
        self.detailTextLabel.text = dic[@"detail"];
        self.detailTextLabel.textColor = [UIColor lightGrayColor];
    }

}

@end
