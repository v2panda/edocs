    //
//  MailCheckInputCell.m
//  rry
//
//  Created by Ren Guohua on 14-6-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "MailCheckInputCell.h"
#import "MailCheckTableViewController.h"
#import "GlobleData.h"

@implementation MailCheckInputCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        [self initTextField];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}


- (void)initTextField
{
    _textField = [[UITextField alloc] initWithFrame:CGRectZero];
    _textField.delegate = self;
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [self addSubview:_textField];
}


- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.imageView.image = [UIImage imageNamed:dic[@"image"]];
        
        UILabel *leftLabel = [[UILabel alloc] initWithFrame:(CGRect){0.0f, 0.0f, 66.0f, 44.0f}];
        leftLabel.backgroundColor  = [UIColor clearColor];
        leftLabel.text = dic[@"title"];
        if(IOS7)
           leftLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        leftLabel.textColor = [UIColor grayColor];
        _textField.leftView = leftLabel;
        _textField.leftViewMode = UITextFieldViewModeAlways;
        _textField.frame = (CGRect){54.0f,0.0f,260.0f, 44.0f};
        
        if ([dic[@"title"] isEqualToString:@"验证码"])
        {
            _getVerifiedCodeButton = [UIButton buttonWithType:UIButtonTypeCustom];
            _getVerifiedCodeButton.frame = CGRectMake(0.0f, 0.0f, 100.0f, 48.0f);
            [_getVerifiedCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
            [_getVerifiedCodeButton setTintColor:UIColorFromRGB(0x2fb610)];
            [_getVerifiedCodeButton setTitleColor:UIColorFromRGB(0x2fb610) forState:UIControlStateNormal];
            _getVerifiedCodeButton.titleLabel.font = [UIFont systemFontOfSize:14];
            
            [_getVerifiedCodeButton addTarget:self action:@selector(getVerifiedCode:) forControlEvents:UIControlEventTouchUpInside];
            _textField.rightView = _getVerifiedCodeButton;
            _textField.rightViewMode = UITextFieldViewModeAlways;
        }
        else
        {
            _textField.keyboardType = UIKeyboardTypeEmailAddress;
            _textField.text = dic[@"mail"];
            _saveInputString(_textField.text);
        }
    }

}

/**
 *  获取验证码
 *
 *  @param sender 按钮
 */
- (void)getVerifiedCode:(id)sender
{
    
    
    if ([self inputIsIlligalForVerifiedCode])
    {
        return;
    }
    
    
    
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *dic = [self getVerifiedParameters];
    NSLog(@"%@",dic);
//    [sessionManager GET:@"GetEmailValiCode" parameters:dic success:^(AFHTTPRequestOperation *task, id responseObject){
    
    UIButton *button = (UIButton *)sender;
    button.userInteractionEnabled = NO;
    
    [sessionManager POST:@"api/member/GetEmailVerifyCode" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:dic path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){

//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSLog(@"aaa:%@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"dic == %@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                _verifiedCode = dic[@"data"];
                verifiedTime = 180;
                if (_verifiedRightLabel == nil)
                {
                    _verifiedRightLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 100.0f, 48.0f)];
                }
                _verifiedRightLabel.text = [NSString stringWithFormat:@"%ld秒",(long)verifiedTime];
                _verifiedRightLabel.textColor = [UIColor redColor];
                _verifiedRightLabel.textAlignment = NSTextAlignmentCenter;
                _textField.rightView = _verifiedRightLabel;
                verifyTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(handleTimer:) userInfo:nil repeats:YES];
            }
            else
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"请求失败" message:dic[@"msg"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alert show];
            }

        }
        
        button.userInteractionEnabled = YES;
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        button.userInteractionEnabled = YES;
        NSLog(@"error == %@",error.description);
    }];
    
    
}

/**
 *  获取验证码请求的网络接口参数
 *
 *  @return 网络接口参数
 */
- (NSDictionary*)getVerifiedParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    if ([self.delegate isKindOfClass:[MailCheckTableViewController class]])
    {
        MailCheckTableViewController *checkVC = (MailCheckTableViewController*)self.delegate;
        NSString * string = checkVC.cellStringDic[[NSIndexPath indexPathForRow:0 inSection:0]];
        if (string.length <= 0)
        {
            return nil;
        }
        //[[GlobleData shareInfo] zipString:string]
        return @{@"email":string,
                 @"user_id":[userData.userId stringValue]};
    }
    
    return nil;
}

/**
 *  处理验证码定时器
 *
 *  @param timer 定时器
 */
- (void)handleTimer:(NSTimer*)timer
{
    
    verifiedTime --;
    if (verifiedTime == 0)
    {
        _textField.rightView = _getVerifiedCodeButton;
        [verifyTimer invalidate];
    }
    else
    {
        _verifiedRightLabel.text = [NSString stringWithFormat:@"%ld秒",(long)verifiedTime];
    }
}



- (BOOL)inputIsIlligalForVerifiedCode
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    
    if ([self.delegate isKindOfClass:[MailCheckTableViewController class]])
    {
        MailCheckTableViewController *checkVC = (MailCheckTableViewController*)self.delegate;
        NSString * string = checkVC.cellStringDic[[NSIndexPath indexPathForRow:0 inSection:0]];
        if (string.length <= 0||[string rangeOfString:@"@"].location==NSNotFound)
        {
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"邮箱不正确" message:@"请输入正确邮箱地址" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
            alert.alertViewStyle=UIAlertViewStyleDefault;
            [alert show];
            return YES;
        }
    }
    return NO;
}


- (void)bindInput:(NSString *)inputString
{
    _textField.text = inputString;
}


#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if ([self.delegate isKindOfClass:[MailCheckTableViewController class]])
    {
        MailCheckTableViewController *checkVC = (MailCheckTableViewController*)self.delegate;
        checkVC.textField = _textField;
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
   
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        return NO;
    }
    
    NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    _saveInputString(toBeString);
    return YES;
}


@end
