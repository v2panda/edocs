//
//  RegLastStepViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-16.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RegLastStepViewController.h"
#import "LoginViewController.h"
#import "MainViewController.h"
#import "RegAdditionViewController.h"
#import "GlobleData.h"

@interface RegLastStepViewController ()

@end

@implementation RegLastStepViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyview];
    [self setNavigationBar];
    [self initTopLabel];
    [self initLeftImageView];
    [self initRightImageView];
    [self initHintLabel];
    [self initNextButton];
    [self initSkipButton];
}


- (void)setMyview
{
    self.view.backgroundColor = UIColorFromRGB(0xf7f7f7);
}
- (void)setNavigationBar
{
    self.navigationItem.title = @"上传身份证";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setFrame:CGRectMake(0.0f, 0.0f, 60.0f, 32.0f)];
    [rightButton setTitle:@"跳过" forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(rightButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem = rightButtonItem;

}
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightButtonClicked:(id)sender
{
    RegAdditionViewController *additionVC = [[RegAdditionViewController alloc] init];
    additionVC.regFlag = @"0";
    additionVC.userId = _userId;
    [self.navigationController pushViewController:additionVC animated:YES];
    
}



- (void)popToLogin
{
    for (UIViewController *viewController in self.navigationController.viewControllers)
    {
        if ([viewController isKindOfClass:[LoginViewController class]])
        {
            [self.navigationController popToViewController:viewController animated:YES];
            break;
        }
    }
}

- (void)initTopLabel
{
    _topLabel = [[UILabel alloc] initWithFrame:(CGRect){20.0f,0.0f,280.0f,44.0f}];
    _topLabel.text = @"上传身份证正面和背面两张照片";
    _topLabel.font = [UIFont systemFontOfSize:13.0f];
    _topLabel.textColor = [UIColor lightGrayColor];
    [self.view addSubview:_topLabel];
}

- (void)initLeftImageView
{
    _leftImageView = [[UIImageView alloc] initWithFrame:(CGRect){20.0f,CGRectGetMaxY(_topLabel.frame) + 10.0f, 64.0f, 64.0f}];
    _leftImageView.backgroundColor = [UIColor lightGrayColor];
    _leftImageView.image = [UIImage imageNamed:@"正面.png"];
    [self.view addSubview:_leftImageView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapLeft:)];
    [_leftImageView addGestureRecognizer:tap];
    _leftImageView.userInteractionEnabled = YES;
}

- (void)tapLeft:(UIGestureRecognizer *)recognizer
{
    isRightImage = NO;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                 initWithTitle:nil
                                 delegate:self
                                 cancelButtonTitle:@"取消"
                                 destructiveButtonTitle:nil
                                 otherButtonTitles:@"相册", @"拍照",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
    
}
- (void)initRightImageView
{
    _rightImageView = [[UIImageView alloc] initWithFrame:(CGRect){CGRectGetMaxX(_leftImageView.frame) + 20.0f,CGRectGetMaxY(_topLabel.frame) + 10.0f, 64.0f, 64.0f}];
    _rightImageView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:_rightImageView];
    _rightImageView.image = [UIImage imageNamed:@"背面.png"];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapRight:)];
    [_rightImageView addGestureRecognizer:tap];
    _rightImageView.userInteractionEnabled = YES;

}

- (void)tapRight:(UIGestureRecognizer *)recognizer
{
    isRightImage = YES;
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"相册", @"拍照",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
    
}

- (void)pickImageFromPhotoLibrary
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    imagePicker.allowsEditing = NO;
    
    [self presentViewController:imagePicker animated:YES completion:nil];
}
- (void)pickImageFromCamera
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    imagePicker.allowsEditing = NO;
    imagePicker.showsCameraControls = YES;
    
    [self presentViewController:imagePicker animated:YES completion:nil];
}


- (NSString*)convertToBase64StringWithImage:(UIImage*)image
{
    NSData *data = UIImageJPEGRepresentation(image, 0.2);//UIImagePNGRepresentation(image);
    NSString *base64String = [data base64EncodedStringWithOptions:0];
    return base64String;
}

- (void)initHintLabel
{
    _hintLabel = [[UILabel alloc] initWithFrame:(CGRect){40.0f,CGRectGetMaxY(_leftImageView.frame) + 30.0f,260.0f,66.0f}];
    _hintLabel.text = @"需要提交身份证之后才能进行提现(赎回)操作，你也可以选择跳过这步完成注册，需要时候再完成。";
    _hintLabel.font = [UIFont systemFontOfSize:13.0f];
    _hintLabel.numberOfLines = 0;
    _hintLabel.textColor = [UIColor lightGrayColor];
    [self.view addSubview:_hintLabel];
}

- (void)initNextButton
{
    _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    CGRect frame = CGRectInset(CGRectMake(0.0f,CGRectGetMaxY(_hintLabel.frame) + 20.0f, 320.0f, 44.0f), 80.0f, 5.0f);
    frame = CGRectOffset(frame, -60.0f, 0.0f);
    _nextButton.frame = frame;
    
    _nextButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
    _nextButton.tintColor = UIColorFromRGB(0xffffff);
    _nextButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_nextButton setTitle:@"下一步" forState:UIControlStateNormal];
    [_nextButton addTarget:self action:@selector(finishButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _nextButton.layer.cornerRadius = 3.0f;
    _nextButton.enabled = NO;
    [self.view addSubview:_nextButton];
}

- (void)setNextButtonEnable
{
    _nextButton.enabled = YES;
    _nextButton.backgroundColor = UIColorFromRGB(0x2fb610);
}
- (void)setNextButtonUnable
{
    _nextButton.enabled = NO;
    _nextButton.backgroundColor = UIColorFromRGB(0xb3b8bc);
}


- (void)finishButtonClicked:(id)sender
{
    if ([self inputIsIlligal])
    {
        return;
    }
    RegAdditionViewController *additionVC = [[RegAdditionViewController alloc] init];
    additionVC.regFlag = @"1";
    additionVC.userId = _userId;
    additionVC.leftImage = leftImage;
    additionVC.rightImage = rightImage;
    additionVC.leftBase64String = leftBase64String;
    additionVC.rightBase64String = rightBase64String;
    [self.navigationController pushViewController:additionVC animated:YES];
    
}

- (void)initSkipButton
{
    _skipButton = [UIButton buttonWithType:UIButtonTypeCustom];
    CGRect frame = CGRectInset(_nextButton.frame,35.0f,0.0f);
    frame = CGRectOffset(frame, 140.0f, 0.0f);
    _skipButton.frame = frame;
    _skipButton.backgroundColor = UIColorFromRGB(0x2fb610);
    _skipButton.tintColor = UIColorFromRGB(0xffffff);
    _skipButton.titleLabel.font = [UIFont systemFontOfSize:21.0f];
    
    [_skipButton setTitle:@"跳过" forState:UIControlStateNormal];
    [_skipButton addTarget:self action:@selector(skipButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    _skipButton.layer.cornerRadius = 3.0f;
    [self.view addSubview:_skipButton];

}

- (void)skipButtonClicked:(id)sender
{
    RegAdditionViewController *additionVC = [[RegAdditionViewController alloc] init];
    additionVC.regFlag = @"0";
    additionVC.userId = _userId;
    [self.navigationController pushViewController:additionVC animated:YES];
}

- (BOOL)inputIsIlligal
{
    if(![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网路无法连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (leftImage == nil)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请上传身份证照片" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (rightImage == nil)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请上传身份证照片" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


- (BOOL)inputIsIlligalWithOutImage
{
    if(![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网路无法连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}


- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    // 返回新的改变大小后的图片
    return scaledImage;
}

#pragma mark - UIImage picker

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    ////zzzili14
    UIImage *image= [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    NSData *imgData = UIImageJPEGRepresentation(image, 0.1);
    image = [UIImage imageWithData:imgData];
    image = [self scaleToSize:image size:CGSizeMake(448, 600)];
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    }
    if (!isRightImage)
    {
        leftImage = image;
        _leftImageView.image = image;
        _leftImageView.bounds = (CGRect){
            .origin.x = 0,
            .origin.y = 0,
            .size.width = 64.0f,
            .size.height = 64.0f * image.size.height / image.size.width,
        };
        leftBase64String = [self convertToBase64StringWithImage:leftImage];
        if (rightImage != nil)
        {
            [self setNextButtonEnable];
        }
    }
    else
    {
        rightImage = image;
        _rightImageView.image = image;
        _rightImageView.bounds = (CGRect){
            .origin.x = 0,
            .origin.y = 0,
            .size.width = 64.0f,
            .size.height = 64.0f * image.size.height / image.size.width,
        };
        rightBase64String = [self convertToBase64StringWithImage:rightImage];
        if (leftImage != nil)
        {
            [self setNextButtonEnable];
        }
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}



#pragma mark - UIActionSheet delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        [self pickImageFromPhotoLibrary];
    }
    else if (buttonIndex == 1)
    {
        [self pickImageFromCamera];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

@end
