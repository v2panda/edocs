//
//  BankCardTypeTableViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BankCardTypeTableViewController : UITableViewController<UIGestureRecognizerDelegate>
{
    NSArray *dataArray;
}

@property (nonatomic, strong) UIButton *finishButton;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) NSMutableDictionary *cellStringDic;
@property (nonatomic, strong) NSString *cardNumber;
@property (nonatomic, strong) NSString *bankName;
@property (nonatomic, strong) NSString *bank_name_id;
@property (nonatomic, strong) NSString *bankAdress;
@property (nonatomic, strong) NSString *bankAdressCode;

@end
