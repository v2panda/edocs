//
//  FundsTypeCell.m
//  rry
//
//  Created by Ren Guohua on 14-7-6.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "FundsTypeCell.h"

@implementation FundsTypeCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
       
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSString class]])
    {
        NSString *string = (NSString*)data;
        self.textLabel.text = string;
    }

}

@end
