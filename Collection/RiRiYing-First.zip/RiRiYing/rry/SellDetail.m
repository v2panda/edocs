//
//  SellDetail.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "SellDetail.h"

@implementation SellDetail


- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    // subclass implementation should set the correct key value mappings for custom keys
    if ([key isEqualToString:@"add_time_s"])
    {
        self.time = value;
    }
    else
    {
        [super setValue:value forUndefinedKey:key];
    }
}

@end
