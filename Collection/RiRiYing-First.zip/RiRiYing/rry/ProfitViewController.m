//
//  ProfitViewController.m
//  rry
//
//  Created by Ren Guohua on 14-6-4.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "ProfitViewController.h"
#import "ProfitCell.h"
#import "ArrayDataSource.h"
#import "UserData.h"
#import "GlobleData.h"
#import "EGORefreshTableHeaderView.h"
#import "FundsCell.h"
@interface ProfitViewController ()<EGORefreshTableHeaderDelegate>
{
    BOOL _isFinished;
    int _page;
    
    EGORefreshTableHeaderView * _refreshHeaderView;
    BOOL _reloading;
    
    UIButton *moreBtn;
}

@end

@implementation ProfitViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
    [self initTableView];
    [self initHintLabel];
    [self getDataFromNetwork];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

/**
 *  获取网络数据
 */
- (void)getDataFromNetwork
{
//    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL];
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *parameters = [self getParameters];
    
//    [sessionManager POST:@"userIncome" parameters:parameters success:^(AFHTTPRequestOperation *task, id responseObject){
    

    [sessionManager POST:@"api/money/getMoneyLog" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        


    
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"pwdDic == %@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                if (![dic[@"data"] isEqual:[NSNull null]])
                {
                    
                    if (_page <= 1) {
                        [dataArray removeAllObjects];
                    }
                    [dataArray addObjectsFromArray:dic[@"data"][@"rows"] ];
                    
                    if (dataArray.count >= [dic[@"data"][@"total"] intValue] ) {
                        _isFinished = YES;
                        self.tableView.tableFooterView = nil;
                    } else {
                        _isFinished = NO;
                        self.tableView.tableFooterView = moreBtn;
                    }
                    
                    [self reloadData];
                }
                
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
        }
        
        [self doneLoadingTableViewData];
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        
        [self doneLoadingTableViewData];
    }];
    
}
/**
 *  获取参数
 *
 *  @return 网络参数
 */
- (NSDictionary*)getParameters
{
//    UserData *userData = [[GlobleData shareInfo] getUserData];
//    
//    return @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//             @"flag":[[GlobleData shareInfo] zipString:_tag]
//             };
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    return  @{@"user_id":[userData.userId stringValue],
              @"time_type": self.tag,
              @"type":@"3,7",
              @"page": @(_page)
              };
    
}

/**
 *  重新加载数据
 */
- (void)reloadData
{
    if ([dataArray count] > 0)
    {
        dataSource.items = dataArray;
        [_tableView reloadData];
//        _tableView.hidden = NO;
        _hintLabel.hidden = YES;
    }
    else
    {
//        _tableView.hidden = YES;
        _hintLabel.hidden = NO;
    }
    
}
/**
 *  设置viewController的View
 */
- (void)setMyView
{
    self.view.backgroundColor = UIColorFromRGB(0xffffff);
    
}
/**
 *  设置导航栏
 */
- (void)setNavigationBar
{
    self.navigationItem.title = _titleString;
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
/**
 *  导航栏做按钮点击事件
 *
 *  @param sender 按钮
 */
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  初始化TableView
 */

- (void)initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height - 64.0f) style:UITableViewStyleGrouped];
    _tableView.backgroundView = nil;
    _tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
//    [_tableView registerClass:[ProfitCell class] forCellReuseIdentifier:@"ProfitCell"];
    [_tableView registerClass:[FundsCell class] forCellReuseIdentifier:@"FundsCell"];
//    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:nil otherIdentifier:@"ProfitCell" configureCellBlock:^(id cell, id data){
    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:nil otherIdentifier:@"FundsCell" configureCellBlock:^(id cell, id data){
        [cell bindData:data];
    }];
    
    self.tableView.dataSource = dataSource;
    _tableView.delegate = self;
//    _tableView.hidden = YES;
    [self.view addSubview:_tableView];
    
    _page = 1;
    _isFinished = NO;
    dataArray = [[NSMutableArray alloc] init];
    
    if (_refreshHeaderView ==  nil)
    {
        _refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame:
                              CGRectMake(0.0f, -10.0f - self.view.bounds.size.height,
                                         self.view.frame.size.width, self.view.bounds.size.height)];
        _refreshHeaderView.delegate = self;
        [self.tableView addSubview:_refreshHeaderView];
    }
    
    moreBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    moreBtn.frame=CGRectMake(0, 0, 320, 40);
    moreBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
    moreBtn.backgroundColor=[UIColor clearColor];
    [moreBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [moreBtn setTitle:@"上拉加载更多" forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(loadMore) forControlEvents:UIControlEventTouchUpInside];
}
/**
 *  初始化提示Label
 */
- (void)initHintLabel
{
    _hintLabel = [[UILabel alloc] initWithFrame:(CGRect){
    
        .origin.x =   0.0f,
        .origin.y =   0.0f,
        .size.width = 320.0f,
        .size.height = self.view.frame.size.height - 64.0f,
    
    }];
    if (IOS7) {
        _hintLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline]
        ;

    } else {
        _hintLabel.font = [UIFont systemFontOfSize:15];
        ;

    }
        _hintLabel.textColor = [UIColor lightGrayColor];
    _hintLabel.textAlignment = NSTextAlignmentCenter;
    _hintLabel.text = @"暂无收益";
    [_tableView addSubview:_hintLabel];
    _hintLabel.hidden = YES;
}


#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65.0f;
}


-(void)loadMore
{
    if (!_isFinished)
    {
        _page += 1;
        
        [moreBtn setTitle:@"正在加载..." forState:UIControlStateNormal];
        
        [self getDataFromNetwork];
    }
}

#pragma mark -- tableView delegate method
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
    if (_reloading) {
        [moreBtn setTitle:@"正在加载..." forState:UIControlStateNormal];
    } else {
        float offset = scrollView.contentOffset.y;
        float contentHeight = scrollView.contentSize.height ;
        float sub = contentHeight - offset-scrollView.frame.size.height;
        
        if (((iPhone5 ? sub :  sub) < -44) && contentHeight >= scrollView.frame.size.height )
        {
            [moreBtn setTitle:@"松开加载更多" forState:UIControlStateNormal];
        } else {
            [moreBtn setTitle:@"上拉加载更多" forState:UIControlStateNormal];
        }
    }
    
    
}


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    
    if (!_reloading) {
        float offset = scrollView.contentOffset.y ;
        float  contentHeight = scrollView.contentSize.height;
        float sub = contentHeight  - offset-scrollView.frame.size.height;
        if ((iPhone5 ? sub : sub) < -44 && contentHeight >= scrollView.frame.size.height)
        {
            [self loadMore];
        }
    }
    
	
}
#pragma mark --EGORefreshTableHeaderDelegate method
- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view
{
    return _reloading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view
{
    return [NSDate date];
}

- (void)reloadTableViewDataSource
{
	_reloading = YES;
    _page = 1;
    _isFinished = NO;
	[self getDataFromNetwork];
}

- (void)doneLoadingTableViewData
{
    _reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
    
    if (_isFinished) {
        self.tableView.tableFooterView = nil;
    } else {
        self.tableView.tableFooterView = moreBtn;
    }
}

@end
