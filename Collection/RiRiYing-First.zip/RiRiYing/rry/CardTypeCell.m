//
//  CardTypeCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-20.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "CardTypeCell.h"
#import "BankCardTypeTableViewController.h"

@implementation CardTypeCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {

        [self initTextField];
    }
    return self;
}

- (void)initTextField
{
    _textField = [[UITextField alloc] initWithFrame:CGRectZero];
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if(IOS7)
        _textField.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    
    _textField.delegate = self;
    [self addSubview:_textField];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        self.textLabel.text = dic[@"title"];
        if(IOS7)
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        if (dic[@"titleColor"])
        {
            self.textLabel.textColor = UIColorFromRGB([dic[@"titleColor"] integerValue]);
        }
        
        _textField.frame = (CGRect){100.0f,0.0f,200.0f, 44.0f};
    
       
        if (dic[@"placeholder"]  != nil && (dic[@"subTitle"] == nil || [dic[@"subTitle"] isEqualToString:@""]) )
        {
            _textField.placeholder = dic[@"placeholder"];
        }
        else
        {
            _textField.placeholder = nil;
            _textField.text = dic[@"subTitle"];
            _textField.textColor = [UIColor blackColor];
        }

        
        if ([dic[@"isChoose"] isEqualToString:@"YES"])
        {
            _textField.enabled = NO;
        }
        else
        {
            [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        }
        
    }
}

- (void)bindInput:(NSString *)inputString
{
    if (inputString != nil && ![inputString isEqualToString:@""])
    {
        _textField.text = inputString;
    }
}


#pragma mark - Textfield Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if ([self.delegate isKindOfClass:[BankCardTypeTableViewController class]])
    {
        BankCardTypeTableViewController *typeVC = (BankCardTypeTableViewController*)self.delegate;
        typeVC.textField = _textField;
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    //_saveCellString(textField.text);
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        [textField resignFirstResponder];
        return NO;
    }
    NSString *toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    _saveCellString(toBeString);
    
    return YES;
}


@end
