//
//  SelectFundsType.m
//  rry
//
//  Created by zz on 14-7-7.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "SelectFundsType.h"

#import "GlobleData.h"

@interface SelectFundsType ()

@end

@implementation SelectFundsType

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        // Drawing code
        UIView *btnView = [[UIView alloc]init];
        btnView.backgroundColor = [UIColor whiteColor];
        if(iPhone5)
        {
            btnView.frame = CGRectMake(0, 274+88, 320, 206);
        }
        else
        {
            btnView.frame = CGRectMake(0, 274, 320, 206);
        }
        [self addSubview:btnView];
        
        ////////toolBar
        UIToolbar *tool = [[UIToolbar alloc]init];
        tool.frame = CGRectMake(0, 0, 320, 44);
        [btnView addSubview:tool];
        
        UIBarButtonItem *itemCancel = [[UIBarButtonItem alloc]initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(touchCancel)];
        UIBarButtonItem *itemLine = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
        UIBarButtonItem *itemOk = [[UIBarButtonItem alloc]initWithTitle:@"确定" style:UIBarButtonItemStyleDone target:self action:@selector(touchOK)];
        
        tool.items = [NSArray arrayWithObjects:itemCancel,itemLine,itemOk, nil];
        
        ////////picker
        self.pickView = [[UIPickerView alloc]init];
        self.pickView.frame = CGRectMake(0, 44, 320, 162);
        self.pickView.delegate = self;
        self.pickView.dataSource =self;
        [btnView addSubview:self.pickView];
        
    }
    return self;
}


- (IBAction)touchCancel {
    [self removeFromSuperview];
}

- (IBAction)touchOK {
    NSString *typeName;
    NSInteger selectType = [self.pickView selectedRowInComponent:0];
    switch (selectType) {
        case 0:
            typeName = @"资金明细▼";
            selectType = 0;
            break;
        case 1:
            typeName = @"返收益▼";
            selectType = 3;
            break;
        case 2:
            typeName = @"购买▼";
            selectType = 1;
            break;
        case 3:
            typeName = @"赎回▼";
            selectType = 2;
            break;
        case 4:
            typeName = @"奖励▼";
            selectType = 7;
            break;
        default:
            break;
    }
    
    [self.delegate  GetFundsType:(int)selectType name:typeName];
    [self removeFromSuperview];
}


// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return 5;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    switch (row) {
        case 0:
            return @"资金明细";
        case 1:
            return @"返收益";
        case 2:
            return @"购买";
        case 3:
            return @"赎回";
        case 4:
            return @"奖励";
        default:
            return @"";
    }
}

@end
