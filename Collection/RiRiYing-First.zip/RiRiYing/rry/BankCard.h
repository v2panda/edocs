//
//  BankCard.h
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "JSONModel.h"

@interface BankCard : JSONModel

@property (nonatomic, strong) NSString *cardNumber;
@property (nonatomic, strong) NSString *bankName;

@property (nonatomic, strong) NSString *bank_address;
@property (nonatomic, strong) NSNumber *bank_name_id;
@property (nonatomic, strong) NSNumber *c_id;
@property (nonatomic, strong) NSNumber *sta;
@property (nonatomic, strong) NSString *sta_info;

@end
