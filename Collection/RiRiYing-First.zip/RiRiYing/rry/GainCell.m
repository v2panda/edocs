//
//  GainCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-12.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "GainCell.h"
#import "UserData.h"
#import "GlobleData.h"
#import "MainData.h"
#import "ProfitViewController.h"
#import "MainViewController.h"

@implementation GainCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self setBackgroundColor:UIColorFromRGB(0xfffcf7)];
        [self initLabels];
        [self initButtons];
    }
    return self;
}


- (void)initLabels
{
    _leftTopNameLabel = [self setLabelWithFrame:(CGRect){15.0f,20.0f,120.0f,15.0f} textColor:[UIColor lightGrayColor]];
    _leftTopDataLabel = [self setLabelWithFrame:(CGRect){15.0f,43.0f,120.0f,22.0f} textColor:[UIColor darkGrayColor]];
    _leftTopDataLabel.font = [UIFont boldSystemFontOfSize:27.0f];
    
    _rightTopNameLabel = [self setLabelWithFrame:(CGRect){176.0f,20.0f,120.0f,15.0f} textColor:[UIColor lightGrayColor]];
    _rightTopDataLabel = [self setLabelWithFrame:(CGRect){176.0f,43.0f,120.0f,22.0f} textColor:[UIColor darkGrayColor]];
    _rightTopDataLabel.font = [UIFont boldSystemFontOfSize:27.0f];
    
    _leftBottomNameLabel = [self setLabelWithFrame:(CGRect){15.0f,91.0f,120.0f,15.0f} textColor:[UIColor lightGrayColor]];
    _leftBottomDataLabel = [self setLabelWithFrame:(CGRect){15.0f,114.0f,120.0f,22.0f} textColor:[UIColor darkGrayColor]];
    _leftBottomDataLabel.font = [UIFont boldSystemFontOfSize:27.0f];
    
    _rightBottomNameLabel = [self setLabelWithFrame:(CGRect){176.0f,91.0f,120.0f,15.0f} textColor:[UIColor lightGrayColor]];
    _rightBottomDataLabel = [self setLabelWithFrame:(CGRect){176.0f,114.0f,120.0f,22.0f} textColor:[UIColor darkGrayColor]];
    _rightBottomDataLabel.font = [UIFont boldSystemFontOfSize:27.0f];
}

- (UILabel*)setLabelWithFrame:(CGRect)frame textColor:(UIColor*)color
{
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.backgroundColor = [UIColor clearColor];
    
    label.textColor = color;
    [self addSubview:label];
    
    return label;
}


- (void)initButtons
{
    [self setButtonWithFrame:(CGRect){0.0f,0.0f,160.0f,80.0f} tag:0];
    [self setButtonWithFrame:(CGRect){160.0f,0.0f,160.0f,80.0f} tag:1];
    [self setButtonWithFrame:(CGRect){0.0f,80.0f,160.0f,80.0f} tag:2];
    [self setButtonWithFrame:(CGRect){160.0f,80.0f,160.0f,80.0f} tag:3];
}

- (UIButton*)setButtonWithFrame:(CGRect)frame tag:(NSInteger)tag
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.tag = tag;
    [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:button];
    return button;
}

- (void)buttonClicked:(id)sender
{
    NSLog(@"tag == %ld",(long)((UIButton*)sender).tag);
    ProfitViewController *profitVC = [[ProfitViewController alloc] init];
    switch (((UIButton*)sender).tag)
    {
        case 0:
        {
            return;
            profitVC.titleString = @"万份收益";
            profitVC.tag = @"4";
            break;
        }
        case 1:
        {
            profitVC.titleString = @"累计收益";
            profitVC.tag = @"0";
            break;
        }
        case 2:
        {
            profitVC.titleString = @"近一周收益";
            profitVC.tag = @"1";
            break;
        }
        case 3:
        {
            profitVC.titleString = @"近一月收益";
            profitVC.tag = @"2";
            break;
        }
        default:
            break;
    }
    
    if ([self.delegate isKindOfClass:[MainViewController class]])
    {
        MainViewController *mainVC = (MainViewController*)self.delegate;
        [mainVC.navigationController pushViewController:profitVC animated:YES];
    }
}

/**
 *  绑定数据
 *
 *  @param data
 */
- (void)bindData:(id)data
{
    
    _leftTopNameLabel.text = @"万份收益(元)";
    _rightTopNameLabel.text = @"累计收益(元)";
    _leftBottomNameLabel.text = @"近一周收益(元)";
    _rightBottomNameLabel.text = @"近一月收益(元)";
  
    if ([data isKindOfClass:[MainData class]])
    {
        MainData *mainData = (MainData*)data;
        if ([mainData.wanIncom isEqualToString:@""] || mainData.wanIncom == nil)
        {
            _leftTopDataLabel.text = @"0.00";
        }
        else
        {
            _leftTopDataLabel.text =[NSString stringWithFormat:@"%.2f",[mainData.wanIncom floatValue]];
        }
        
        if ([mainData.totalIncom isEqualToString:@""] || mainData.totalAmount ==nil)
        {
            _rightTopDataLabel.text = @"0.00";
        }
        else
        {
            _rightTopDataLabel.text = [NSString stringWithFormat:@"%.2f",[mainData.totalIncom floatValue]];
        }
        
        if ([mainData.weekIncom isEqualToString:@""] || mainData.weekIncom == nil)
        {
            _leftBottomDataLabel.text = @"0.00";
        }
        else
        {
            _leftBottomDataLabel.text = [NSString stringWithFormat:@"%.2f",[mainData.weekIncom floatValue]];
        }
        
        if ([mainData.monthIncom isEqualToString:@""] || mainData.monthIncom == nil)
        {
            _rightBottomDataLabel.text = @"0.00";
        }
        else
        {
            _rightBottomDataLabel.text = [NSString stringWithFormat:@"%.2f",[mainData.monthIncom floatValue]];
        }
        
    }
    else
    {
        _leftTopDataLabel.text = @"0.00";
        _rightTopDataLabel.text = @"0.00";
        _leftBottomDataLabel.text = @"0.00";
        _rightBottomDataLabel.text = @"0.00";
    }

}


- (void)drawRect:(CGRect)rect
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    [UIColorFromRGB(0xe7e3e0) set];
    
    [path moveToPoint:CGPointMake(0.0f, 0.0f)];
    [path addLineToPoint:CGPointMake(320.0f, 0.0f)];
    
    [path moveToPoint:CGPointMake(0.0f, 78.5f)];
    [path addLineToPoint:CGPointMake(320.0f, 78.5f)];
    
    [path moveToPoint:CGPointMake(0.0f, 157.0f)];
    [path addLineToPoint:CGPointMake(320.0f, 157.0f)];
    
    [path moveToPoint:CGPointMake(159.5f, 0.0f)];
    [path addLineToPoint:CGPointMake(159.5f, 158.0f)];
    
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineJoinRound;
    
    path.lineWidth = 1.0f;
    
    [path stroke];

}

@end
