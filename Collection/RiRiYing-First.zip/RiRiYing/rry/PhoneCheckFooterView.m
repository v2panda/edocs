//
//  PhoneCheckFooterView.m
//  rry
//
//  Created by Ren Guohua on 14-6-30.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "PhoneCheckFooterView.h"

@implementation PhoneCheckFooterView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self initCheckButton];
    }
    return self;
}

/**
 *  初始化验证按钮
 */
- (void)initCheckButton
{
    _checkButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    _checkButton.frame = (CGRect){
        
        .origin.x = 20.0f,
        .origin.y = 20.0f,
        .size.width = 280.0f,
        .size.height = 44.0f,
        
    };
    
    _checkButton.backgroundColor = UIColorFromRGB(0x2fb610);
    [_checkButton setTitle:@"验证手机号" forState:UIControlStateNormal];
    [_checkButton setTitleColor:UIColorFromRGB(0xffffff) forState:UIControlStateNormal];
    _checkButton.layer.cornerRadius = 3.0f;
    [_checkButton addTarget:self action:@selector(checkButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_checkButton];
}

/**
 *  验证按钮点击事件
 *
 *  @param sender checkButton
 */
- (void)checkButtonClicked:(id)sender
{
    if (clickCheckEvent)
    {
        clickCheckEvent();
    }
}
/**
 *  配置block 事件
 *
 *  @param clickButtonClock 
 */
- (void)configCheckButtonEvent:(ClickeButon)clickButtonClock;
{
    clickCheckEvent = clickButtonClock;
}

@end
