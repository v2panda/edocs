//
//  UserInfoTableViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-23.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "UserInfoTableViewController.h"
#import "UserInfoCell.h"
#import "UserData.h"
#import "GlobleData.h"
#import "MailCheckTableViewController.h"
#import "PhoneCheckTableViewController.h"
#import "UploadViewController.h"

@interface UserInfoTableViewController ()
{
    NSDictionary *dataDict;
    NSDictionary *staDict;
}

@end

@implementation UserInfoTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)initSomeData
{
    dataArray = @[@[
                      @{@"title":@"姓名",@"subTitle":@""},
                      @{@"title":@"账户名",@"subTitle":@""},
                      ],
                  @[
                      //                    @{@"title":@"实名认证",@"subTitle":realNameVerified},
                      @{@"title":@"绑定手机",@"subTitle":@""},
                      @{@"title":@"绑定邮箱",@"subTitle":@""},
                      ],
                  
                  ];
    [self.tableView reloadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
    [self registerCell];
    
    [self initSomeData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self refreshUserMsg];
    [self getDataFromNetwork];
}

-(void)refreshUserMsg
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *dic = [self getParameters];
    NSLog(@"%@",dic);
//    [sessionManager POST:@"LoginUser" parameters:dic success:^(AFHTTPRequestOperation *task, id responseObject){
    

    [sessionManager POST:@"api/member/getInfo"  parameters:[[GlobleData shareInfo] encrytUrlWithParam2:dic path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
//        NSData *data = [[GlobleData shareInfo] getRealDataWithData:responseObject];
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1] )
            {
                //            [GlobleData shareInfo].key = dic[@"data"][@"encrypt_key"];
                
                //            [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"userData"];
                //            [[NSUserDefaults standardUserDefaults] setObject:responseObject forKey:@"userData"];
                //            [[NSUserDefaults standardUserDefaults] synchronize];
                dataDict = dic[@"data"];
                [self initData];
                [self.tableView reloadData];
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:dic[@"msg"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
                alert.alertViewStyle=UIAlertViewStyleDefault;
                [alert show];
            }
        }
        
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"网络异常" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
    }];
}

/**
 *  从网络获取待办数据
 */
- (void)getDataFromNetwork
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    //    [sessionManager GET:@"GetAgent" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/member/GetSta" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters1] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        
        //        NSData *data = [[GlobleData shareInfo]getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                staDict = dic[@"data"];
                [self initData];
                [self.tableView reloadData];
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        NSLog(@"%@", task.request.URL);
    }];
}
/**
 *  生成http请求参数
 *
 *  @return http请求参数
 */
- (NSDictionary*)getParameters1
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    //    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
    //              };
    return  @{@"user_id":[userData.userId stringValue],
              };
}

- (NSDictionary*)getParameters
{
 
//    NSString *userName = [[NSUserDefaults standardUserDefaults]objectForKey:@"userName"];
//    NSString *userPass = [[NSUserDefaults standardUserDefaults]objectForKey:@"zzuserPass"];
    
//    return  @{@"idcard":[[GlobleData shareInfo] zipString:userName],
//              @"app_login_pwd":[[GlobleData shareInfo] zipString:userPass]
//              };
//    return  @{@"username":userName,
//              @"pwd":userPass
//              };
    
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
    return  @{@"user_id":[userData.userId stringValue],
              };
}

- (void)initData
{
    UserData *userData;
    NSString *realNameVerified = @"";
    NSString *emailVerified = @"";
    NSString *telVerified = @"";
    if (dataArray) {
        userData = [[UserData alloc] initWithDictionary:[dataDict mutableCopy]];
//        NSString *realNameVerified = @"";
//        NSString *emailVerified = @"";
//        NSString *telVerified = @"";
        switch ([staDict[@"mobile_sta"] integerValue])
        {
            case 0:
            {
                telVerified = @"(未认证)";
                break;
            }
            case 1:
            {
                telVerified = @"(已认证)";
                break;
            }
            case -1:
            {
                //            realNameVerified = @"认证未通过";
                telVerified = @"(未通过)";
                break;
            }
            default:
                break;
        }
        
        switch ([staDict[@"idcard_sta"] integerValue])
        {
            case 0:
            {
                realNameVerified = @"(未认证)";
                break;
            }
            case 1:
            {
                realNameVerified = @"(已认证)";
                break;
            }
            case 2:
            {
                realNameVerified = @"(待审核)";
                break;
            }
            case -1:
            {
                //            realNameVerified = @"认证未通过";
                realNameVerified = @"(未通过)";
                break;
            }
            default:
                break;
        }
        
        //    if ([userData.email length] > 0) {
        //        emailVerified = @"已认证";
        //        emailVerified = userData.email;
        //    } else {
        switch ([staDict[@"email_sta"] integerValue])
        {
            case 0:
            {
                emailVerified = @"(未认证)";
                break;
            }
            case 1:
            {
                emailVerified = @"(已认证)";
                //                emailVerified = userData.email;
                break;
            }
            case -1:
            {
                //                emailVerified = @"认证未通过";
                emailVerified = @"(未通过)";
                break;
            }
            default:
                break;
        }
        //    }

    } else {
        userData = [[GlobleData shareInfo] getUserData];
        
        switch ([userData.phoneNumberVerified integerValue])
        {
            case 0:
            {
                telVerified = @"(未认证)";
                break;
            }
            case 1:
            {
                telVerified = @"(已认证)";
                break;
            }
            case -1:
            {
                //            realNameVerified = @"认证未通过";
                telVerified = @"(未通过)";
                break;
            }
            default:
                break;
        }
        
        switch ([userData.realNameVerified integerValue])
        {
            case 0:
            {
                realNameVerified = @"(未认证)";
                break;
            }
            case 1:
            {
                realNameVerified = @"(已认证)";
                break;
            }
            case -1:
            {
                //            realNameVerified = @"认证未通过";
                realNameVerified = @"(未通过)";
                break;
            }
            default:
                break;
        }
        
        //    if ([userData.email length] > 0) {
        //        emailVerified = @"已认证";
        //        emailVerified = userData.email;
        //    } else {
        switch ([userData.emailVerified integerValue])
        {
            case 0:
            {
                emailVerified = @"(未认证)";
                break;
            }
            case 1:
            {
                emailVerified = @"(已认证)";
                //                emailVerified = userData.email;
                break;
            }
            case -1:
            {
                //                emailVerified = @"认证未通过";
                emailVerified = @"(未通过)";
                break;
            }
            default:
                break;
        }
        //    }

    }
    
    if (userData.idcard.length <= 0) {
        return;
    }
    
    NSString *tel;
    if (userData.phoneNumber.length>7)
    {
        NSString *star = @"";
        for (int i=0; i<userData.phoneNumber.length-7; i++) {
            star = [star stringByAppendingString:@"*"];
        }
        
        NSString *str=[NSString stringWithFormat:@"%@%@%@",[userData.phoneNumber substringToIndex:3], star,[userData.phoneNumber substringWithRange:NSMakeRange(userData.phoneNumber.length-4, 4)]];
        tel = str;
    }else
    {
        tel = userData.phoneNumber;
        
    }
    
    NSString *idcard;
    if (userData.idcard.length>10)
    {
        NSString *star = @"";
        for (int i=0; i<userData.idcard.length-10; i++) {
            star = [star stringByAppendingString:@"*"];
        }
        
        NSString *str=[NSString stringWithFormat:@"%@%@%@",[userData.idcard substringToIndex:6], star,[userData.idcard substringWithRange:NSMakeRange(userData.idcard.length-4, 4)]];
        idcard = str;
    }else
    {
        idcard = userData.idcard;
        
    }
    
    NSString * mail = [NSString stringWithFormat:@"%@",userData.email];
    NSRange userRange = [mail rangeOfString:@"@"];
    if (userRange.location != NSNotFound)
    {
        NSMutableString * mstr = [[NSMutableString alloc] initWithCapacity:userRange.location-2];
        if(userRange.location > 2 && userRange.location < 7)
        {
            for (int i=0; i<userRange.location-2; i++) {
                [mstr appendString:@"*"];
            }
            NSRange range = {0,userRange.location-2};
            mail = [mail stringByReplacingCharactersInRange:range withString:mstr];
        }
        else if (userRange.location >= 7)
        {
            NSRange range = {userRange.location-6,4};
            mail = [mail stringByReplacingCharactersInRange:range withString:@"****"];
        }
    }
    tel = (tel&&tel.length>0)?tel:@"暂无";
    mail = (mail&&mail.length>1)?mail:@"暂无";
    
    tel = [tel stringByAppendingString:telVerified];
    mail = [mail stringByAppendingString:emailVerified];
    idcard = [idcard stringByAppendingString:realNameVerified];
    
    dataArray = @[@[
                    @{@"title":@"姓名",@"subTitle":userData.realName},
                    @{@"title":@"账户名",@"subTitle":idcard},
                    ],
                  @[
//                    @{@"title":@"实名认证",@"subTitle":realNameVerified},
                      @{@"title":@"绑定手机",@"subTitle":tel},
                      @{@"title":@"绑定邮箱",@"subTitle":mail},
                    ],

                  ];
    [self.tableView reloadData];
}
- (void)setMyView
{
    self.tableView.backgroundView = nil;
    self.tableView.backgroundColor = UIColorFromRGB(0xf7f7f7);
}
- (void)setNavigationBar
{
    self.navigationItem.title = @"账户信息";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  注册Cell
 */
- (void)registerCell
{
    [self.tableView registerClass:[UserInfoCell class] forCellReuseIdentifier:@"Cell"];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return [dataArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [dataArray[section] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UserInfoCell *cell = (UserInfoCell*)[tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    [cell bindData:dataArray[indexPath.section][indexPath.row]];
    
    if ([staDict count] > 0) {
        if (indexPath.section == 0 && indexPath.row == 1)
        {
            if ([staDict[@"idcard_sta"] integerValue] == 0 || [staDict[@"idcard_sta"] integerValue] == -1)
            {
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            }
        }
        
        if (indexPath.section == 1 &&  indexPath.row == 0)
        {
            if ([staDict[@"mobile_sta"] integerValue] == 0 || [staDict[@"mobile_sta"] integerValue] == -1)
            {
               cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            }
        }
        
        if (indexPath.section == 1 && indexPath.row == 1)
        {
            //zzzili14
            if ([staDict[@"email_sta"] integerValue] == 0 || [staDict[@"email_sta"] integerValue] == -1)
            {
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            }
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([staDict count] > 0) {
        if (indexPath.section == 0 && indexPath.row == 1)
        {
            if ([staDict[@"idcard_sta"] integerValue] == 0 || [staDict[@"idcard_sta"] integerValue] == -1)
            {
                UploadViewController *uploadVC = [[UploadViewController alloc] init];
                [self.navigationController pushViewController:uploadVC animated:YES];
            }
        }
        
        if (indexPath.section == 1 &&  indexPath.row == 0)
        {
            if ([staDict[@"mobile_sta"] integerValue] == 0 || [staDict[@"mobile_sta"] integerValue] == -1)
            {
                PhoneCheckTableViewController *phoneCheckVC = [[PhoneCheckTableViewController alloc] init];
                [self.navigationController pushViewController:phoneCheckVC animated:YES];
            }
        }
        
        if (indexPath.section == 1 && indexPath.row == 1)
        {
            //zzzili14
            if ([staDict[@"email_sta"] integerValue] == 0 || [staDict[@"email_sta"] integerValue] == -1)
            {
                MailCheckTableViewController *mailCheckVC = [[MailCheckTableViewController alloc] init];
                [self.navigationController pushViewController:mailCheckVC animated:YES];
            }
        }
    }

}

#pragma mark - Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (indexPath.section == 0 && indexPath.row == 0)
//    {
//        return 88.0f;
//    }
    return 44.0f;
}

@end
