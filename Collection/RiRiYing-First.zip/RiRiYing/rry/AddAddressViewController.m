//
//  AddAddressViewController.m
//  fanfan
//
//  Created by Ren Guohua on 14-2-27.
//  Copyright (c) 2014年 yunfen. All rights reserved.
//

#import "AddAddressViewController.h"
#import "AddressViewController.h"
#import "BankCardTypeTableViewController.h"
#import "GlobleData.h"
#import "GHCache.h"

@interface AddAddressViewController ()

@end

@implementation AddAddressViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self setMyView];
    [self setNavigationBar];
    [self initButtons];

    [self initOKButton];
	
}
- (void)initData
{
    _buttonNameArray = @[@"选择省",@"选择市",@"选择区"];
}

- (void)setMyView
{
    self.view.backgroundColor = [UIColor whiteColor];
    
}
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"添加地址";
   
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back_hl.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(pop:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
- (void)pop:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initOKButton
{

    _okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    if (IOS7) {
        _okButton.frame = CGRectMake(0.0f, self.view.frame.size.height - 44.0f - 64.0f, 320.0f, 44.0f);
    } else {
        _okButton.frame = CGRectMake(0.0f, self.view.frame.size.height - 44.0f - 44.0f, 320.0f, 44.0f);
    }
    

    [_okButton addTarget:self action:@selector(okButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [_okButton setTitle:@"确定" forState:UIControlStateNormal];
    [_okButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_okButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateHighlighted];
    
    _okButton.backgroundColor = [UIColor blackColor];
    _okButton.titleLabel.font = [UIFont systemFontOfSize:17.0f];
    [self.view addSubview:_okButton];

}

- (void)okButtonClicked:(id)sender
{
    if ([self inputIsIlligal])
    {
        return;
    }
    if ([self.delegate isKindOfClass:[BankCardTypeTableViewController class]])
    {
        BankCardTypeTableViewController *bankCardTypeVC = (BankCardTypeTableViewController*)self.delegate;
        bankCardTypeVC.bankAdress = [self getAddress];
        bankCardTypeVC.bankAdressCode = [self getAdrresCode];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)inputIsIlligal
{
    if (![[GlobleData shareInfo] connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"无网络连接" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    if (![self addressButtonIsOk])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"请选择地址" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        alert.alertViewStyle=UIAlertViewStyleDefault;
        [alert show];
        return YES;
    }
    return NO;
}

/**
 *  获取最终的地址名称
 *
 *  @return 地址名称
 */
- (NSString*)getAddress
{
    NSMutableArray *addressStringArray = [[NSMutableArray alloc] init];
    if ([self addressButtonIsOk])
    {
        for (int n = 0;n <= 2; n++)
        {
            UIButton *button = [_buttonArray objectAtIndex:n];
            [addressStringArray addObject:button.titleLabel.text];
        }
        
        return [addressStringArray componentsJoinedByString:@" "];
    }
    
    return nil;
}
/**
 *  获取最终地址的代码
 *
 *  @return 地址代码
 */
- (NSString*)getAdrresCode
{
    if ([self addressButtonIsOk])
    {
        NSString *cacheFileName = _areaButton.titleLabel.text;
        NSString *addressName = _streetButton.titleLabel.text;
        
        NSString *code = [self getAddressCodeWithName:addressName withCacheFileName:cacheFileName];
        return code;
    }
    
    return nil;
}


/**
 *  判断地址是否选择完成，假如有按钮的名称还是初始化的按钮名称，则该按钮未选择地址
 *
 *  @return YES－选择完成 NO－选择未完成
 */
- (BOOL)addressButtonIsOk
{
    for (int n = 0;n <= 2; n++)
    {
        UIButton *button = [_buttonArray objectAtIndex:n];
        if ([_buttonNameArray containsObject:button.titleLabel.text])
        {
            return NO;
        }
    }
    return YES;
}

- (void)initButtons
{
    _cityButton =  [self setButtonWithFrame:CGRectMake(20.0f, 100.0f, 280.0f, 44.0f) title:_buttonNameArray[0] tag:0];
    //_cityButton.tintColor = UIColorFromRGB(0xf32203);
    
    _areaButton =  [self setButtonWithFrame:CGRectMake(20.0f, CGRectGetMaxY(_cityButton.frame) + 20.0f, 280.0f, 44.0f) title:_buttonNameArray[1] tag:1];
   // _areaButton.tintColor = UIColorFromRGB(0x34878f);
    
    _streetButton = [self setButtonWithFrame:CGRectMake(20.0f, CGRectGetMaxY(_areaButton.frame) + 20.0f, 280.0f, 44.0f) title:_buttonNameArray[2] tag:2];
    //_streetButton.tintColor = UIColorFromRGB(0x4983fe);
 
    
    _buttonArray = [NSMutableArray arrayWithObjects:_cityButton,_areaButton,_streetButton, nil];
    
}

/**
 *  初始化按钮
 *
 *  @param frame 按钮的大小位置
 *  @param title 按钮的标题
 *  @param tag   按钮的tag
 *
 *  @return <#return value description#>
 */
- (UIButton*)setButtonWithFrame:(CGRect)frame title:(NSString*)title tag:(NSInteger)tag
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.tag = tag;
    [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.tintColor = [UIColor blackColor];
    
    button.backgroundColor = UIColorFromRGB(0xf0f0f0);
    button.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [self.view addSubview:button];
    return button;
}

/**
 *  按钮的点击事件
 *
 *  @param sender
 */
- (void)buttonClicked:(id)sender
{
    UIButton *button = (UIButton*)sender;

    if (button.tag >= 1)
    {
        UIButton *previousButton = [_buttonArray objectAtIndex:button.tag - 1];
        NSString *previousButtonTitle = [_buttonNameArray objectAtIndex:button.tag - 1];
        if ([previousButton.titleLabel.text isEqualToString:previousButtonTitle])
        {
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"请%@",previousButtonTitle] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
            alert.alertViewStyle=UIAlertViewStyleDefault;
            [alert show];
            return;
        }
    }
    AddressViewController *addressViewController = [[AddressViewController alloc] init];
    addressViewController.parentName = [self getParentNameWithTag:button.tag];
    addressViewController.parentId = [self getParentIdWithTag:button.tag];
    addressViewController.titleText = [_buttonNameArray objectAtIndex:button.tag];
    addressViewController.buttonTag = button.tag;
    addressViewController.delegate = self;
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:addressViewController];
    [self presentViewController:navigationController animated:YES completion:nil];
}

/**
 *  重置地址按钮的名称
 *
 *  @param tag   按钮的tag
 *  @param title 按钮名称
 */
- (void)resetButtonWithTag:(NSInteger)tag title:(NSString*)title
{
    UIButton *button = [_buttonArray objectAtIndex:tag];
    [button setTitle:title forState:UIControlStateNormal];
    if (tag == 0)
    {
        button.tintColor = UIColorFromRGB(0xf32203);
    }
    else if(tag == 1)
    {
        button.tintColor = UIColorFromRGB(0x34878f);
    }
    else if (tag == 2)
    {
        button.tintColor = UIColorFromRGB(0x4983fe);
    }
    
    for (NSInteger n = tag + 1; n <= 2; n++)
    {
        UIButton *button = _buttonArray[n];
        [button setTitle:_buttonNameArray[n] forState:UIControlStateNormal];
        button.tintColor = [UIColor blackColor];
    }
}

/**
 *  获取地址代号
 *
 *  @param name 地址名称
 *  @param file 缓存文件
 *
 *  @return 地址代号
 */

- (NSString*)getAddressCodeWithName:(NSString *)name withCacheFileName:(NSString *)file
{
    NSData *data = [[GHCache shareCache] dataFromFile:file];
    
    if (data == nil)
    {
        return nil;
    }
    NSString *string;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    NSArray * array = dic[@"data"];
    
    for (NSDictionary *dic in array)
    {
        if ([name isEqualToString:[dic objectForKey:@"area_name"]])
        {
            string = [dic objectForKey:@"area_code"];
            
            break;
        }
    }
    return string;

}

/**
 *  获取地址的id
 *
 *  @param name 地址名称
 *  @param file 缓存文件
 *
 *  @return 地址id
 */
- (NSString*)getIdWithName:(NSString*)name withCacheFileName:(NSString*)file
{
    NSData *data = [[GHCache shareCache] dataFromFile:file];

    if (data == nil)
    {
        return nil;
    }
    NSString *idString;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    NSArray * array = dic[@"data"];

    for (NSDictionary *dic in array)
    {
        if ([name isEqualToString:[dic objectForKey:@"area_name"]])
        {
            idString = [dic objectForKey:@"area_code"];
            
            break;
        }
    }
    return idString;
}

/**
 *  获取地址的父id
 *
 *  @param tag 地址的id
 *
 *  @return  地址的父id
 */
- (NSString*)getParentIdWithTag:(NSInteger)tag
{
    if (tag == 0)
    {
//        return @"2";
        return @"101";
    }
    if (tag == 1)
    {
        UIButton *button = [_buttonArray objectAtIndex:tag - 1];
        NSString *parentIdString = [self getIdWithName:button.titleLabel.text withCacheFileName:[self getParentNameWithTag:tag - 1]];
        return parentIdString ? parentIdString : @"1";
    }
    if (tag == 2)
    {
        UIButton *button = [_buttonArray objectAtIndex:tag - 1];
        NSString *parentIdString = [self getIdWithName:button.titleLabel.text withCacheFileName:[self getParentNameWithTag:tag - 1]];
        return parentIdString ? parentIdString : @"2";
    }
    UIButton *button = [_buttonArray objectAtIndex:tag - 1];
    return [self getIdWithName:button.titleLabel.text withCacheFileName:[self getParentNameWithTag:tag - 1]];
    
}

/**
 *  获取地址的父地址
 *
 *  @param tag 地址id
 *
 *  @return 父地址名称
 */
- (NSString*)getParentNameWithTag:(NSInteger)tag
{
    if (tag == 0 )
    {
        return @"rootAddress";
//        return @"101";
    }
    
    UIButton *button = [_buttonArray objectAtIndex:tag - 1];
    return  button.titleLabel.text;
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

@end
