//
//  RedeemTopCell.m
//  rry
//
//  Created by Ren Guohua on 14-5-21.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "RedeemTopCell.h"

@implementation RedeemTopCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}
/**
 *  绑定数据
 *
 *  @param data 要绑定的数据
 */
- (void)bindData:(id)data
{
    if ([data isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*)data;
        if ([dic[@"bank_name"] isEqual:[NSNull null]] || dic[@"bank_name"] == nil)
        {
             self.textLabel.text = @"获取失败";
        }
        else
        {
            self.textLabel.text = dic[@"bank_name"];
        }
        
        if(IOS7)
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        if ([dic[@"card_number"] isEqual:[NSNull null]] || dic[@"card_number"] == nil)
        {
            self.textLabel.text = @"暂无";

        }
        else
        {
            NSString *string = dic[@"card_number"];
            if (string.length >= 4)
            {
                string = [string substringFromIndex:string.length - 4];
            }
            self.detailTextLabel.text = [NSString stringWithFormat:@"尾号%@",string];
        }
        self.detailTextLabel.textColor = [UIColor grayColor];
        self.imageView.image = [UIImage imageNamed:@"yinhangka.png"];
    }
    else
    {
        self.textLabel.text = @"正在获取银行卡信息...";
        if(IOS7)
            self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        
        self.detailTextLabel.text = @"暂无";
        self.detailTextLabel.textColor = [UIColor grayColor];
        self.imageView.image = [UIImage imageNamed:@"yinhangka.png"];
    }
}

@end
