//
//  MailCheckFooterView.m
//  rry
//
//  Created by Ren Guohua on 14-6-30.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "MailCheckFooterView.h"

@implementation MailCheckFooterView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self initCheckButton];
    }
    return self;
}


- (void)initCheckButton
{
    _checkButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    _checkButton.frame = (CGRect){
        
        .origin.x = 20.0f,
        .origin.y = 20.0f,
        .size.width = 280.0f,
        .size.height = 44.0f,
        
    };
    
    _checkButton.backgroundColor = UIColorFromRGB(0x2fb610);
    [_checkButton setTitle:@"验证邮箱" forState:UIControlStateNormal];
    [_checkButton setTitleColor:UIColorFromRGB(0xffffff) forState:UIControlStateNormal];
    _checkButton.layer.cornerRadius = 3.0f;
    [_checkButton addTarget:self action:@selector(checkButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_checkButton];
}

- (void)checkButtonClicked:(id)sender
{
    if (clickCheckEvent)
    {
        clickCheckEvent();
    }
}

- (void)configCheckButtonEvent:(ClickeButon)clickButtonClock;
{
    clickCheckEvent = clickButtonClock;
}


@end
