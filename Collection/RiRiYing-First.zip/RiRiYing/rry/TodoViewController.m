//
//  TodoViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "TodoViewController.h"
#import "TodoCell.h"
#import "ArrayDataSource.h"
#import "GlobleData.h"
#import "UserData.h"
#import "UploadViewController.h"
#import "BankCardBindViewController.h"
#import "MailCheckTableViewController.h"
#import "PhoneCheckTableViewController.h"

@interface TodoViewController ()

@end

@implementation TodoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
//    [self initData];
    [self initTableView];
}

- (void)initData
{
    [self getDataFromNetwork];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self initData];
}
/**
 *  从网络获取待办数据
 */
- (void)getDataFromNetwork
{
    AFHTTPRequestOperationManager *sessionManager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:BASEURL5];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
//    [sessionManager GET:@"GetAgent" parameters:[self getParameters] success:^(AFHTTPRequestOperation *task, id responseObject){
    [sessionManager POST:@"api/member/GetSta" parameters:[[GlobleData shareInfo] encrytUrlWithParam2:[self getParameters] path:nil key:[GlobleData shareInfo].key] success:^(AFHTTPRequestOperation *task, id responseObject){
        
        
//        NSData *data = [[GlobleData shareInfo]getRealDataWithData:responseObject];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@",dic);
        if (dic) {
            if ([dic[@"sta"] isEqualToNumber:@1])
            {
                dataDic = dic[@"data"];
                dataArray = [self getDataArrayWithDic:dataDic];
                [self reloadData];
            }
        }
        
        
    } failure:^(AFHTTPRequestOperation *task, NSError *error){
        NSLog(@"%@", task.request.URL);
    }];
}

- (void)reloadData
{
    dataSource.items = dataArray;
    [_tableView reloadData];
}

/**
 *  格式化从网络获取的待办数据
 *
 *  @param dic 从网络获取的json数据
 *
 *  @return 格式化为数组
 */
- (NSArray*)getDataArrayWithDic:(NSDictionary*)dic
{
    NSString *bankFlag;
    NSString *emailFlag;
    NSString *idcardFlag;
    NSString *mobileFlag;
    if  (dic[@"bank_sta"] != nil)
    {
        bankFlag = [((NSNumber*)dic[@"bank_sta"]) stringValue];
    }
    else
    {
        bankFlag = @"";
    }
    if  (dic[@"email_sta"] != nil)
    {
        emailFlag = [((NSNumber*)dic[@"email_sta"]) stringValue];
    }
    else
    {
        emailFlag = @"";
    }
//    if (dic[@"idcard_img_flag"] != nil)
//    {
//        idcardFlag = [((NSNumber*)dic[@"idcard_img_flag"]) stringValue];
//    }
    if (dic[@"idcard_sta"] != nil)
    {
        idcardFlag = [((NSNumber*)dic[@"idcard_sta"]) stringValue];
    }
    
    else
    {
        idcardFlag = @"";
    }
    if  (dic[@"mobile_sta"] != nil)
    {
        mobileFlag = [((NSNumber*)dic[@"mobile_sta"]) stringValue];
    }
    else
    {
        mobileFlag = @"";
    }
    
    return @[@{@"title":@"上传身份证图片",@"detail":@"必须提交身份证才能赎回资金",@"done":idcardFlag, @"error_msg": dic[@"idcard_error_msg"]},
             @{@"title":@"验证手机",@"detail":@"验证手机可用于找回密码",@"done":mobileFlag},
             @{@"title":@"完善银行卡信息",@"detail":@"必须完善银行卡才能赎回资金",@"done":bankFlag, @"error_msg": dic[@"bank_error_msg"]},
             @{@"title":@"验证邮箱",@"detail":@"验证邮箱可用于找回密码",@"done":emailFlag},
             ];
}

/**
 *  生成http请求参数
 *
 *  @return http请求参数
 */
- (NSDictionary*)getParameters
{
    UserData *userData = [[GlobleData shareInfo] getUserData];
    if (userData == nil)
    {
        return nil;
    }
//    return  @{@"user_id_s":[[GlobleData shareInfo] zipString:[userData.userId stringValue]],
//              };
    return  @{@"user_id":[userData.userId stringValue],
              };
}

- (void)setMyView
{
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
}

- (void)setNavigationBar
{
    
    self.navigationItem.title = @"待办事项";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)initTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f,self.view.frame.size.height - 64.0f) style:UITableViewStyleGrouped];
    _tableView.backgroundView = nil;    
    _tableView.backgroundColor = UIColorFromRGB(0xf7f7f7);
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.contentInset = UIEdgeInsetsMake(0.0f, 0.0f, 20.0f, 0.0f);
    [_tableView registerClass:[TodoCell class] forCellReuseIdentifier:@"TodoCell"];
    
    dataSource = [[ArrayDataSource alloc]initWithItems:dataArray cellIdentifierDic:nil otherIdentifier:@"TodoCell" configureCellBlock:^(id cell, id data){
        
        [cell bindData:data];
    }];
    
    self.tableView.dataSource = dataSource;
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}


#pragma - mark UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 1 || indexPath.row == 3) {
        return 75.0f;
    }
    if (indexPath.row == 0) {
        if ([dataDic[@"idcard_error_msg"] length] > 0) {
            return 95.0f;
        } else {
            return 75.0f;
        }
    }
    
    if (indexPath.row == 2) {
        if ([dataDic[@"bank_error_msg"] length] > 0) {
            return 95.0f;
        } else {
            return 75.0f;
        }
    }
    
    return 95.0f;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%@",dataArray[indexPath.row][@"title"]);
    if (indexPath.row == 0)
    {
        if (![dataArray[indexPath.row][@"done"] isEqualToString:@"1"] && ![dataArray[indexPath.row][@"done"] isEqualToString:@"2"])
        {
            UploadViewController *uploadVC = [[UploadViewController alloc] init];
            [self.navigationController pushViewController:uploadVC animated:YES];
        }
    }
    if (indexPath.row == 1)
    {
        if (![dataArray[indexPath.row][@"done"] isEqualToString:@"1"] && ![dataArray[indexPath.row][@"done"] isEqualToString:@"2"])
        {
            PhoneCheckTableViewController *phoneCheckVC = [[PhoneCheckTableViewController alloc] init];
            [self.navigationController pushViewController:phoneCheckVC animated:YES];
        }
    }

    if (indexPath.row == 2)
    {
        if (![dataArray[indexPath.row][@"done"] isEqualToString:@"1"] && ![dataArray[indexPath.row][@"done"] isEqualToString:@"2"])
        {
            BankCardBindViewController *banVC = [[BankCardBindViewController alloc] init];
            [self.navigationController pushViewController:banVC animated:YES];
        }
    }
    if (indexPath.row == 3)
    {
        //zzzili14
        if (![dataArray[indexPath.row][@"done"] isEqualToString:@"1"] && ![dataArray[indexPath.row][@"done"] isEqualToString:@"2"])
        {
            MailCheckTableViewController *mailCheckVC = [[MailCheckTableViewController alloc] init];
            [self.navigationController pushViewController:mailCheckVC animated:YES];
        }
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
