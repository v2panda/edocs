//
//  AboutUsViewController.m
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import "AboutUsViewController.h"

@interface AboutUsViewController ()

@end

@implementation AboutUsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setMyView];
    [self setNavigationBar];
    [self initImageView];
}

/**
 *  设置背景色
 */
- (void)setMyView
{
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
}
/**
 *  设置导航栏
 */
- (void)setNavigationBar
{
    
    self.navigationItem.title = @"关于我们";
    [self.navigationController.navigationBar setTitleTextAttributes:@{
                                                                      NSForegroundColorAttributeName:[UIColor whiteColor],
                                                                      }];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    if(IOS7)
    {
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    }
    else
    {
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    }
    self.navigationController.navigationBar.translucent = NO;
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
    [leftButton addTarget:self action:@selector(leftButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    
}

/**
 *  导航栏左按钮点击事件
 *
 *  @param sender
 */
- (void)leftButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *  生成关于我们的图片
 */
- (void)initImageView
{
    _imageView = [[UIImageView alloc] initWithFrame:(CGRect){44.0f,80.0f,232.0f,193.0f}];
    _imageView.image = [UIImage imageNamed:@"about_ririying.png"];
    [self.view addSubview:_imageView];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];

}


@end
