//
//  ShowBankCardViewController.h
//  rry
//
//  Created by Ren Guohua on 14-5-22.
//  Copyright (c) 2014年 yunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ArrayDataSource;
@class BankCard;
@interface ShowBankCardViewController : UIViewController<UITableViewDelegate>
{
    ArrayDataSource *dataSource;
    NSArray *dataArray;
}
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) BankCard *bankCard;

@end
