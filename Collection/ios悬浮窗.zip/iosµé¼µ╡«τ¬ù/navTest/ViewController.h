//
//  ViewController.h
//  navTest
//
//  Created by Lrs on 13-10-15.
//  Copyright (c) 2013年 Lrs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
